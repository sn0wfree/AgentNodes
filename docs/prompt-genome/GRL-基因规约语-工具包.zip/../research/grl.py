#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GRL —— 基因规约语（Gene-Rule Language）核心库。

设计立场：规则是一等数据，散文是它的编译产物。
本库只做四件事：
  1. 反编译：条款 JSON -> GRL Rule 对象（无损映射，缺字段记为 unspecified 而非丢弃）
  2. 规范化：把自由文本压到受控词表，得到可比较的「等位键」
  3. 引用：四种引用形态（位点 / 等位 / 精确 / 断言）的解析与求值
  4. 编译：GRL Rule -> 散文（模板由数据驱动，各家文风表在 styles 中）

反编译原则（承重判据）：能映射就映射，映射不了的部分写进 `unmapped` 而不是丢弃条款。
丢弃条款会让「语言装不下现有语料」这件事静默发生。
"""
import json
import re
import unicodedata
from collections import Counter, defaultdict

# ─────────────────────────────────────────────────────────────
# 0. 路径
# ─────────────────────────────────────────────────────────────
import os
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                    'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')

# ─────────────────────────────────────────────────────────────
# 1. 模态枚举 —— 从 5526 条真实语料反推（10 种原始取值 -> 6 档）
#    归并规则只做「同义 + 大小写」，不做语义猜测。
# ─────────────────────────────────────────────────────────────
MODALITY_MAP = {
    'must':     'must',        # must / MUST / has to / WILL
    'should':   'should',
    'may':      'may',         # may / might
    'can':      'can',         # can / can't(另记否定)
    'cannot':   'must_not',    # cannot
}
NEGATED_MODALITY = {'cannot', "can't", "won't", "must not", "shall not", "never"}

MODALITY_ORDER = ['must', 'must_not', 'should', 'may', 'can', 'unspecified']
MODALITY_LABEL = {
    'must':        '强制（必须执行）',
    'must_not':    '强制禁止',
    'should':      '建议（应当）',
    'may':         '可选',
    'can':         '许可（可为）',
    'unspecified': '未声明模态（散文）',
}

# ─────────────────────────────────────────────────────────────
# 2. 受控动词表（沿用 allele_lib 的归一化思想，这里只保留判定所需的最小集）
# ─────────────────────────────────────────────────────────────
VERB_CANON = {
    'use': 'use', 'utilize': 'use', 'apply': 'use', 'leverage': 'use',
    'provide': 'provide', 'offer': 'provide', 'give': 'provide', 'return': 'provide',
    'create': 'create', 'generate': 'create', 'make': 'create', 'build': 'create',
    'include': 'include', 'contain': 'include', 'cover': 'include',
    'search': 'search', 'browse': 'search', 'query': 'search', 'lookup': 'search',
    'ask': 'ask', 'request': 'ask', 'clarify': 'ask',
    'answer': 'answer', 'respond': 'answer', 'reply': 'answer',
    'write': 'write', 'author': 'write', 'draft': 'write',
    'cite': 'cite', 'source': 'cite', 'attribute': 'cite',
    'analyze': 'analyze', 'evaluate': 'analyze', 'assess': 'analyze',
    'refuse': 'refuse', 'decline': 'refuse',
    'suggest': 'suggest', 'recommend': 'suggest', 'propose': 'suggest',
    'follow': 'follow', 'adhere': 'follow', 'comply': 'follow', 'obey': 'follow',
    'call': 'call', 'invoke': 'call', 'access': 'call',
    'avoid': 'avoid', 'prevent': 'avoid', 'stop': 'avoid',
    'engage': 'engage', 'participate': 'engage',
    'send': 'send', 'transmit': 'send',
    'treat': 'treat', 'handle': 'treat', 'address': 'treat',
    'respect': 'respect', 'honor': 'respect',
    'assist': 'assist', 'help': 'assist', 'support': 'assist',
    'ensure': 'ensure', 'verify': 'ensure', 'check': 'ensure', 'confirm': 'ensure',
    'acknowledge': 'acknowledge',
    'redirect': 'redirect',
    'prefer': 'prefer', 'choose': 'prefer', 'select': 'prefer',
    'perform': 'perform', 'do': 'perform', 'try': 'perform',
    'mention': 'mention', 'refer': 'mention', 'name': 'mention',
    'show': 'show', 'display': 'show', 'reveal': 'show',
    'explain': 'explain', 'describe': 'explain',
    'include_all': 'include',
}
STOP = {'the', 'a', 'an', 'and', 'or', 'to', 'of', 'in', 'for', 'with', 'on', 'at',
        'it', 'its', 'this', 'that', 'these', 'those', 'as', 'by', 'from', 'be', 'is',
        'any', 'all', 'your', 'you', 'their', 'there', 'here', 'will', 'not', 'no'}

NEG_VERBS = {'avoid', 'refuse', 'decline', 'prevent', 'stop', 'omit', 'exclude',
              'withhold', 'bypass', 'suppress', 'bar'}
_NEG_SCAN = re.compile(r'\b(never|not|cannot|can\'t|don\'t|avoid|refuse to|shall not|must not)\b', re.I)
_NEG_RE = re.compile(r"^(not|never|avoid|don't|do not|doesn't|refuse to|won't)\s+", re.I)
_COND_RE = re.compile(r"^(if|unless|when|whenever|except|only if|in case|when applicable)\b", re.I)


def _norm_ws(s):
    return re.sub(r'\s+', ' ', (s or '')).strip()


def _strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFKD', s or '') if not unicodedata.combining(c))


def canon_verb(verb):
    """把动词压到受控词表；不在词表里则返回小写原形（不丢弃）。"""
    v = _norm_ws(verb).lower().strip('.,;:')
    v = re.sub(r'[^a-z0-9\' -]', '', v)
    if not v:
        return ''
    if v in VERB_CANON:
        return VERB_CANON[v]
    # 复数/第三人称回退
    for suf, repl in (( 'ies', 'y'), ('es', ''), ('s', '')):
        if v.endswith(suf) and v[:-len(suf)] + repl in VERB_CANON:
            return VERB_CANON[v[:-len(suf)] + repl]
    return v


def parse_modality(d_raw):
    """D 槽 -> (modality, negation)。空 D 槽 = unspecified（散文），不是 'may'。"""
    d = _norm_ws(d_raw)
    if not d:
        return 'unspecified', False
    low = d.lower()
    neg = low in NEGATED_MODALITY or bool(_NEG_RE.match(low))
    if low in ('cannot', "can't", "won't", 'never'):
        return 'must_not', True
    if low in MODALITY_MAP:
        return MODALITY_MAP[low], neg
    if low in ('will', 'shall', 'has to', 'have to', 'need to', 'required to'):
        return 'must', neg
    if low in ('might', 'may', 'could'):
        return 'may', neg
    if low in ('should', 'ought to', 'recommended to'):
        return 'should', neg
    if low in ('can', 'able to', 'allowed to'):
        return 'can', neg
    if low in ('must', 'must not'):
        return ('must_not' if neg else 'must'), neg
    return 'unspecified', neg


def normalize_object(obj):
    """对象归一化：去冠词、去标点、小写、词序稳定化。用于跨厂商等位比较。"""
    s = _strip_accents(_norm_ws(obj)).lower()
    s = re.sub(r"[^a-z0-9\s'-]", ' ', s)
    toks = [t for t in s.split() if t and t not in STOP]
    return ' '.join(sorted(toks)) if toks else ''


def normalize_scope(raw):
    """作用域规范化：casefold + 标点归一 + 常见同义合并。返回 (key, raw)。"""
    s = _norm_ws(raw)
    k = _strip_accents(s).lower()
    k = re.sub(r"[^a-z0-9\s]", ' ', k)
    k = re.sub(r'\s+', ' ', k).strip()
    # 同义归并：这些是语料里实测到的同义标题变体
    k = re.sub(r'\bharmful content safety\b', 'harmful-content-safety', k)
    k = re.sub(r'\bmandatory copyright requirements\b', 'copyright-requirements', k)
    k = re.sub(r'\bcritical reminders\b', 'critical-reminders', k)
    k = re.sub(r'\bcore principles\b', 'core-principles', k)
    return k, s


_SECTION_RE = re.compile(r'^Under\s+(.+?),\s*(.*)$', re.S)


def split_section(full_statement):
    """full_statement 形如 'Under <Section>, <body>'。抽 (section, body)；抽不出则 (None, 原文)。"""
    m = _SECTION_RE.match(_norm_ws(full_statement))
    if m:
        return m.group(1), m.group(2)
    return None, _norm_ws(full_statement)


# ─────────────────────────────────────────────────────────────
# 3. 反编译：条款 JSON -> Rule
# ─────────────────────────────────────────────────────────────
class Rule(object):
    __slots__ = ('id', 'locus', 'tier', 'cls', 'modality', 'negation',
                 'scope_raw', 'scope_key', 'addressee', 'verb', 'object_raw',
                 'object_key', 'condition_raw', 'anchor', 'statement', 'body',
                 'vendor', 'file', 'eval_keys', 'unmapped', 'truncated')

    def __init__(self, **kw):
        for k in self.__slots__:
            setattr(self, k, kw.get(k))

    # 等位键：存在性层之上、个体特征层之下。条件与作用域刻意不进键（exp10 结论）。
    def allele_key(self):
        return (self.cls, self.modality, self.negation,
                self.verb or '', self.object_key or '')

    def to_dict(self):
        return {
            'id': self.id, 'locus': self.locus, 'tier': self.tier, 'class': self.cls,
            'modality': self.modality, 'negation': self.negation,
            'scope': {'raw': self.scope_raw, 'key': self.scope_key},
            'addressee': self.addressee, 'verb': self.verb,
            'object': {'raw': self.object_raw, 'key': self.object_key},
            'condition': self.condition_raw,
            'anchor': self.anchor, 'statement': self.statement,
            'provenance': {'vendor': self.vendor, 'file': self.file},
            'eval': self.eval_keys, 'unmapped': self.unmapped,
            'truncated': bool(self.truncated),
        }

    def to_grl(self):
        """序列化成 GRL 文本形式（JSONC 风格，字段顺序固定）。"""
        d = self.to_dict()
        lines = ['{']
        lines.append('  "id": %s,' % json.dumps(d['id']))
        lines.append('  "locus": %s,' % json.dumps(d['locus']))
        lines.append('  "tier": %s,' % json.dumps(d['tier']))
        lines.append('  "class": %s,' % json.dumps(d['class']))
        lines.append('  "modality": %s,' % json.dumps(d['modality']))
        lines.append('  "negation": %s,' % json.dumps(d['negation']))
        lines.append('  "scope": {"key": %s, "raw": %s},' % (json.dumps(d['scope']['key'], ensure_ascii=False),
                                                             json.dumps(d['scope']['raw'], ensure_ascii=False)))
        lines.append('  "addressee": %s,' % json.dumps(d['addressee'], ensure_ascii=False))
        lines.append('  "verb": %s,' % json.dumps(d['verb'], ensure_ascii=False))
        lines.append('  "object": {"key": %s, "raw": %s},' % (json.dumps(d['object']['key'], ensure_ascii=False),
                                                              json.dumps(d['object']['raw'], ensure_ascii=False)))
        lines.append('  "condition": %s,' % json.dumps(d['condition'], ensure_ascii=False))
        lines.append('  "anchor": %s,' % json.dumps(d['anchor'], ensure_ascii=False))
        lines.append('  "statement": %s,' % json.dumps(d['statement'], ensure_ascii=False))
        lines.append('  "provenance": {"vendor": %s, "file": %s},' % (json.dumps(d['provenance']['vendor']),
                                                                    json.dumps(d['provenance']['file'])))
        lines.append('  "truncated": %s,' % json.dumps(d['truncated']))
        lines.append('  "eval": %s' % json.dumps(d['eval']))
        lines.append('}')
        return '\n'.join(lines)


def load_corpus(base=BASE):
    """加载全部条款。返回 (rules, raw_stats)。"""
    rules = []
    raw_d = Counter()
    for path in sorted(os.listdir(base)):
        vdir = os.path.join(base, path)
        if not os.path.isdir(vdir):
            continue
        vendor = path
        for fn in sorted(os.listdir(vdir)):
            if not fn.endswith('.json'):
                continue
            fpath = os.path.join(vdir, fn)
            try:
                items = json.load(open(fpath, encoding='utf-8'))
            except Exception:
                continue
            for i, it in enumerate(items):
                if not isinstance(it, dict):
                    continue
                rules.append(_rule_from_item(it, vendor, fn, i))
                rc = it.get('regulative_components')
                if rc:
                    raw_d[_norm_ws(rc.get('D'))] += 1
    stats = {
        'total': len(rules),
        'by_class': dict(Counter(r.cls for r in rules)),
        'by_modality': dict(Counter(r.modality for r in rules)),
        'raw_D_values': dict(raw_d),
        'with_scope': sum(1 for r in rules if r.scope_key),
        'with_condition': sum(1 for r in rules if r.condition_raw),
        'with_unmapped': sum(1 for r in rules if r.unmapped),
    }
    return rules, stats


def _strip_section_prefix(cond, section):
    """C 槽污染清理：上游抽取把 'Under <Section>, ' 前缀塞进了条件字段。

    实测：3334 条非空 C 槽里 864 条（25.9%）带这个前缀，且内容常被截断。
    条件字段必须与作用域字段互斥，否则同一信息占两个槽位。
    返回 (清理后的条件, 是否来自【外来 section】)。
    """
    if not cond:
        return '', False
    c = _norm_ws(cond)
    if not re.match(r'^Under\s+', c, re.I):
        return c, False
    m = re.match(r'^Under\s+(.+?)\s*,\s*(.*)$', c, re.S | re.I)
    if not m:
        # 形态二：C 槽整体就是 section 名（无逗号），条件其实不存在
        carried_only = re.sub(r'^Under\s+', '', c, flags=re.I).strip()
        cur_key = normalize_scope(section)[0] if section else ''
        co_key = normalize_scope(carried_only)[0]
        if cur_key and (cur_key == co_key or cur_key in co_key or co_key in cur_key):
            return '', False
        return c, False
    carried = m.group(1)
    rest = _norm_ws(m.group(2))
    cur_key = normalize_scope(section)[0] if section else ''
    carried_key = normalize_scope(carried)[0]
    same = (cur_key == carried_key) or (cur_key and cur_key in carried_key) or (carried_key and carried_key in cur_key)
    return rest, (not same)


def _is_truncated(cond, body):
    """检测条件字段是否在正文中被截断（后面还跟着实词而不是标点）。

    必须在 body（去掉 'Under <section>,' 前缀后的正文）里定位，
    在整句里 find 会命中前一处相同子串 -> 43% 误报。
    """
    if not cond:
        return False
    pos = body.find(cond)
    if pos < 0:
        return False
    tail = body[pos + len(cond):].lstrip(' ,;')
    if not tail:
        return False
    return not tail.startswith(('.', '!', '?', ';', ','))


def _rule_from_item(it, vendor, filename, idx):
    cls = it.get('class') or 'non-statement'
    anchor = _norm_ws(it.get('anchor'))
    statement = _norm_ws(it.get('full_statement'))
    section, body = split_section(statement)
    scope_key, scope_raw = ('', '')
    if section:
        scope_key, scope_raw = normalize_scope(section)

    addressee = verb = object_raw = object_key = condition = ''
    negation = 'no'
    modality = 'unspecified'
    unmapped = []
    truncated = False

    rc = it.get('regulative_components')
    cc = it.get('constitutive_components')
    if rc:
        addressee = _norm_ws(rc.get('A'))
        modality, neg_d = parse_modality(rc.get('D'))
        raw_i = _norm_ws(rc.get('I'))
        # I 槽可能自带否定前缀：'not do' 之类
        neg_i = False
        m = _NEG_RE.match(raw_i)
        if m:
            neg_i = True
            raw_i = raw_i[m.end():]
        verb = canon_verb(raw_i)
        object_raw = _norm_ws(rc.get('B'))
        object_key = normalize_object(object_raw)
        condition, foreign = _strip_section_prefix(_norm_ws(rc.get('C')), section)
        if foreign:
            unmapped.append('C:foreign_section')
        if condition and _is_truncated(condition, body):
            unmapped.append('C:truncated')
            truncated = True
        else:
            truncated = False
        if not verb:
            unmapped.append('I')
        if not modality or modality == 'unspecified':
            unmapped.append('D')
        # 否定判定：三态。
        #   yes  = D 槽明确否定(cannot/can't) 或 I 槽前缀否定(not X)  —— 高置信
        #   suspected = 正文里出现否定词但 D/I 未表态 —— 低置信，单列字段，不当正式否定
        # 扫描范围必须是 body（去掉 'Under <section>,' 之后的正文）：
        # 否则章节名里的 'or not search' 会被误判成否定（实测 124 条过计）。
        if neg_d or neg_i or verb in NEG_VERBS:
            negation = 'yes'
            if modality == 'must':
                modality = 'must_not'
        elif _NEG_SCAN.search((body or '').lower()):
            negation = 'suspected' 
    elif cc:
        # constitutive：E=subject F=predicate P=predicate-complement
        addressee = _norm_ws(cc.get('E'))
        verb = canon_verb(cc.get('F'))
        object_raw = _norm_ws(cc.get('P'))
        object_key = normalize_object(object_raw)
        modality = 'unspecified'
        if not verb:
            unmapped.append('F')
    else:
        unmapped.append('class=non-statement')

    rid = 'R-%s-%04d' % (vendor[:4].upper(), idx)
    return Rule(
        id=rid, locus=None, tier=None, cls=cls, modality=modality, negation=negation,
        scope_raw=scope_raw, scope_key=scope_key, addressee=addressee,
        verb=verb, object_raw=object_raw, object_key=object_key,
        condition_raw=condition, anchor=anchor, statement=statement, body=body,
        vendor=vendor, file=filename, eval_keys=[], unmapped=unmapped, truncated=truncated,
    )


# ─────────────────────────────────────────────────────────────
# 4. 引用求值：四种引用形态
# ─────────────────────────────────────────────────────────────
#   #D01              位点引用     —— 这个维度下的全部规则
#   #D01~must         等位引用     —— 这个维度下 模态=must 的规则（等位同源）
#   @R-ANTH-0031      精确引用     —— 指定的那一条
#   assert ⊇ / ⊥ / ≡  断言引用     —— 可机检的集合关系
# ─────────────────────────────────────────────────────────────
def resolve(ref, rules, by_id=None):
    """解析一个引用，返回命中的规则集合（list）。"""
    ref = _norm_ws(ref)
    if ref.startswith('@'):
        if by_id is None:
            by_id = {r.id: r for r in rules}
        r = by_id.get(ref[1:])
        return [r] if r else []
    if ref.startswith('#'):
        body = ref[1:]
        locus = None
        modality = None
        if '~' in body:
            locus, modality = body.split('~', 1)
        else:
            locus = body
        hit = []
        for r in rules:
            if locus:
                # locus 为 None 的规则不匹配任何位点引用 —— 原实现把它算进去了，
                # 导致 #D01 命中全部 5526 条（自检只查 >=1 所以没抓到）
                if (not r.locus) or r.locus.upper() != locus.upper():
                    continue
            if modality and r.modality != modality:
                continue
            hit.append(r)
        return hit
    return []


def evaluate_assertion(lhs_ref, op, rhs_ref, rules, by_id=None):
    """集合断言求值。op ∈ {'⊇','⊥','≡'}。返回 (ok, detail)。"""
    L = resolve(lhs_ref, rules, by_id)
    R = resolve(rhs_ref, rules, by_id)
    lid = {r.id for r in L}
    rid = {r.id for r in R}
    if op == '⊇':
        ok = rid.issubset(lid)
        return ok, {'missing': sorted(rid - lid), 'lhs_size': len(lid), 'rhs_size': len(rid)}
    if op == '⊥':
        ok = not (lid & rid)
        return ok, {'overlap': sorted(lid & rid), 'lhs_size': len(lid), 'rhs_size': len(rid)}
    if op == '≡':
        ok = lid == rid
        return ok, {'only_lhs': sorted(lid - rid), 'only_rhs': sorted(rid - lid)}
    return False, {'error': 'unknown op %r' % op}


# ─────────────────────────────────────────────────────────────
# 5. 编译：GRL -> 散文。模板数据驱动（各家文风表在 styles 里，不写死在代码里）
# ─────────────────────────────────────────────────────────────
DEFAULT_STYLE = {
    'name': 'default',
    'open': '',
    'close': '',
    'modality': {
        'must': 'must', 'must_not': 'must not', 'should': 'should',
        'may': 'may', 'can': 'may', 'unspecified': '',
    },
    'frame': '{body}.',
}

POLARITY_NEG = ('not', 'never', 'avoid', 'refuse', 'cannot', "can't", 'without', 'no ')


def polarity_of(text):
    """判定一句散文的极性：1=正向 0=否定 -1=未指定。

    编译器必须【极性守恒】：must 不得编译成 'never'/'must not'。
    风格表只允许改写强度词与句式包裹，不允许反转极性。
    """
    t = (text or '').lower()
    for w in ('never', 'not ', 'no ', "can't", 'cannot', 'avoid', 'refuse to'):
        if w in t:
            return 0
    for w in ('must', 'should', 'may', 'can', 'will', 'shall'):
        if w in t:
            return 1
    return -1


def compile_rule(rule, style=None):
    """把一条 Rule 渲染成散文句子。

    两条硬规则：
      (a) 空槽不得留下多余空格或粘连（第一版 'search resultsalways' 就是这么来的）；
      (b) 极性守恒：must 不得编译成 never / must not（由 check_polarity 判定）。
    """
    st = style or DEFAULT_STYLE
    mod = st['modality'].get(rule.modality, '')
    if rule.negation == 'yes' and rule.modality not in ('must_not',):
        mod = (mod + ' not').strip()
    addr = rule.addressee or 'the assistant'
    verb = rule.verb or 'do'
    obj = rule.object_raw or ''
    cond = rule.condition_raw or ''
    parts = [p for p in (addr, mod, verb, obj, cond) if p]
    body = ' '.join(parts)
    frame = st.get('frame')
    if frame:
        body = frame.format(body=body)
    else:
        tpl = st.get('tpl', '{addressee} {modality} {verb} {object} {condition}.')
        subs = {'addressee': addr, 'modality': mod, 'verb': verb, 'object': obj, 'condition': cond}
        body = tpl.format(**subs)
        body = re.sub(r'\s+([.,;])', r'\1', body)
        body = re.sub(r'\s{2,}', ' ', body).strip()
        body = re.sub(r'\s+([.,;])', r'\1', body)
    out = (st.get('open', '') + ' ' + body + ' ' + st.get('close', '')).strip()
    return re.sub(r'\s+', ' ', out)


def modality_polarity(word):
    """判定一个【模态词】的极性：1=正向 0=否定 -1=不是模态词。

    必须只判定模态词本身，绝不能扫全句 —— 条件句里的 'do not'、
    章节名里的 'or not search' 都会把整句误判成否定（实测 234 条过计）。
    """
    t = (word or '').strip().lower()
    if not t:
        return -1
    if any(w in t for w in ('never', 'not', 'cannot', "can't", 'avoid', 'refuse', 'without')):
        return 0
    if any(w in t for w in ('must', 'should', 'may', 'can', 'will', 'shall',
                            'always', 'prefer', 'typically', 'normally')):
        return 1
    return -1


# 强度等级（有序，不是布尔）。风格表映射必须保档：must 不得降级成 may。
INTENSITY_RANK = {
    'must': 3, 'must_not': 3,
    'should': 2,
    'may': 1, 'can': 1,
    'unspecified': -1,
}
INTENSITY_WORDS = {
    3: ('must', 'shall', 'will', 'always', 'never', 'required'),
    2: ('should', 'prefer', 'typically', 'normally', 'generally'),
    1: ('may', 'can', 'could', 'might', 'optionally'),
}


def intensity_rank(word):
    # 判定一个措辞的强度档位；不在受控表里返回 -1（不可判定）。
    t = (word or '').strip().lower()
    if not t:
        return -1
    for r, ws in INTENSITY_WORDS.items():
        for w in ws:
            if w in t:
                return r
    return -1


def modality_slot(rule, style=None):
    # 编译后真正写入的模态串（与 compile_rule 用同一套逻辑，保证不是两处各算一遍）。
    st = style or DEFAULT_STYLE
    mod = st['modality'].get(rule.modality, '')
    if rule.negation == 'yes' and rule.modality not in ('must_not',):
        mod = (mod + ' not').strip()
    return mod


def check_style_vocabulary(style):
    # 风格表词表自检：每个 modality 映射值必须落在受控模态词表内。
    # 风格表一旦引入不受控措辞（实测 prefer / always），
    # 编译后的强度就不可判定 —— 而「强度是结构化字段」正是这门语言的核心目标。
    bad = []
    for src, w in (style.get('modality') or {}).items():
        if src == 'unspecified' and not w:
            continue
        if modality_polarity(w) == -1:
            bad.append({'src': src, 'word': w})
    return (not bad), bad


def check_polarity(rule, style=None):
    """强度守恒判据（双检，缺一不可）。

    检 1 极性守恒：编译后写入的模态串，其否定性必须与源规则的 negation 一致。
    检 2 强度保档：编译后写入的措辞，其强度档位必须与源 modality 的档位相同。
           must 不许降级成 may；must_not 不许编译成正向词。

    两道检查必须分开：
      只查极性 => 'should not'（源 should+neg）会被误判为违规（实测 105 条误判）；
      只查档位 => 'must' 编译成 'never'（极性反转）查不出来（实测第一版风格表）。
    """
    st = style or DEFAULT_STYLE
    slot = modality_slot(rule, st)
    want_rank = INTENSITY_RANK.get(rule.modality, -1)
    # modality=unspecified 时源本身没表态强度 => 极性与档位都不做期望
    if want_rank == -1:
        want_pol = -1
    elif rule.negation == 'yes':
        want_pol = 0
    elif rule.negation == 'no':
        want_pol = 1
    else:
        want_pol = -1          # suspected：极性不可判定，只查档位
    got_rank = intensity_rank(slot)
    got_pol = modality_polarity(slot)
    detail = {
        'src_modality': rule.modality, 'src_negation': rule.negation,
        'slot': slot, 'want_rank': want_rank, 'got_rank': got_rank,
        'want_polarity': want_pol, 'got_polarity': got_pol,
    }
    ok_rank = (want_rank == -1) or (got_rank == want_rank)
    ok_pol = (want_pol == -1) or (got_pol == want_pol)
    detail['ok_rank'] = ok_rank
    detail['ok_polarity'] = ok_pol
    return (ok_rank and ok_pol), detail


if __name__ == '__main__':
    rules, stats = load_corpus()
    print('total', stats['total'])
    print('class', stats['by_class'])
    print('modality', stats['by_modality'])
    print('scope', stats['with_scope'], 'cond', stats['with_condition'])
