#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Markdown 交付物自检：以 pandoc(CommonMark/GFM) 为渲染真源，
找出「源文件里有 ** 但渲染后仍是字面量」的加粗失效点。
判定真源用 pandoc 而不是自己实现 flanking 规则——自己写错过一次。"""
import io, os, re, subprocess, sys, tempfile

def render(md_text):
    with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False, encoding="utf-8") as f:
        f.write(md_text)
        p = f.name
    html = p + ".html"
    subprocess.run(["pandoc", "-f", "gfm", "-t", "html", p, "-o", html],
                   check=True, capture_output=True)
    h = io.open(html, encoding="utf-8").read()
    os.unlink(p); os.unlink(html)
    return h

def strip_code(html_text):
    """把 <code>…</code> 与 <pre>…</pre> 换成等长空格（这些里的 ** 是字面量，正确）"""
    def blank(m):
        return re.sub(r"[^\n]", " ", m.group(0))
    out = re.sub(r"<code>.*?</code>", blank, html_text, flags=re.S)
    out = re.sub(r"<pre>.*?</pre>", blank, out, flags=re.S)
    return out

def check(path):
    src = io.open(path, encoding="utf-8").read()
    html = strip_code(render(src))
    leftovers = [m.start() for m in re.finditer(r"\*\*", html)]
    # 把残留位置映射回上下文
    ctxs = []
    for p in leftovers:
        ctxs.append(re.sub(r"\s+", " ", html[max(0, p - 90):p + 60]).strip())
    # 表格列数（忽略转义竖线）
    def npipe(l):
        return len(re.findall(r"(?<!\\)\|", l))
    lines = src.split("\n"); bad = []; i = 0; ntab = 0
    while i < len(lines):
        if lines[i].startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s\-:|]+\|$", lines[i + 1]):
            ntab += 1; ncol = npipe(lines[i]); j = i + 1
            while j < len(lines) and lines[j].startswith("|"):
                if npipe(lines[j]) != ncol:
                    bad.append((j + 1, npipe(lines[j]), ncol))
                j += 1
            i = j
        else:
            i += 1
    return {
        "file": os.path.basename(path),
        "bytes": len(src.encode()),
        "tables": ntab,
        "table_col_mismatch": bad,
        "bold_leftover": len(leftovers),
        "contexts": ctxs,
    }

if __name__ == "__main__":
    targets = sys.argv[1:]
    allok = True
    for t in targets:
        r = check(t)
        ok = r["bold_leftover"] == 0 and not r["table_col_mismatch"]
        allok = allok and ok
        print(f"[{'PASS' if ok else 'FAIL'}] {r['file']}  {r['bytes']}B  表 {r['tables']}  "
              f"加粗失效 {r['bold_leftover']}  表列不一致 {len(r['table_col_mismatch'])}")
        for c in r["contexts"][:8]:
            print("      ", c)
        for b in r["table_col_mismatch"][:8]:
            print("       列数不一致 行", b)
    print("\nVERDICT:", "PASS" if allok else "FAIL")
