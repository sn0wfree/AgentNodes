#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GRL 自检：把语言规范里的每条判据做成机器可判的检查。

用法：python3 grl_check.py
输出：逐条判据 PASS/FAIL + 末行字面判决词；退出码非 0 即 FAIL。

判据设计纪律：
  - 每条判据都能被「注入违规」证伪（C14 就是专门干这个的）；
  - 判据对着能力，不对着名字；
  - 数字带口径（分子/分母都写出来）。
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import grl

RESULTS = []


def check(cid, name, ok, detail=''):
    RESULTS.append({'id': cid, 'name': name, 'ok': bool(ok), 'detail': detail})
    return ok


RULES, STATS = grl.load_corpus()
REG = [r for r in RULES if r.cls == 'regulative']
CON = [r for r in RULES if r.cls == 'constitutive']
by_vendor = defaultdict(list)
for r in RULES:
    by_vendor[r.vendor].append(r)

# ── C1 反编译不丢条款 ─────────────────────────────────────
raw_reg = sum(1 for r in RULES if r.cls == 'regulative')
check('C1', '反编译不丢条款（regulative 条数守恒）',
      len(REG) == raw_reg == 4237,
      '语料 regulative=%d，反编译后=%d' % (raw_reg, len(REG)))

# ── C2 核心槽位填充率 ─────────────────────────────────────
vb = sum(1 for r in REG if r.verb) / max(1, len(REG))
ob = sum(1 for r in REG if r.object_key) / max(1, len(REG))
sc = sum(1 for r in REG if r.scope_key) / max(1, len(REG))
check('C2', '核心槽位填充率（动词/对象/作用域）',
      vb >= 0.99 and ob >= 0.95 and sc >= 0.60,
      'verb=%.1f%% object=%.1f%% scope=%.1f%%' % (vb * 100, ob * 100, sc * 100))

# ── C3 槽位保真度：编译不丢信息 ──────────────────────────
def norm_tokens(s):
    return set(t for t in re.findall(r"[a-z0-9']+", (s or '').lower()) if len(t) > 2)


kept = 0
for r in REG:
    comp = grl.compile_rule(r)
    ct = norm_tokens(comp)
    ok = True
    ot = norm_tokens(r.object_raw)
    ctoks = norm_tokens(r.condition_raw)
    if ot and not (ot & ct):
        ok = False
    if ctoks and not (ctoks & ct):
        ok = False
    if r.verb and r.verb.lower() not in comp.lower():
        ok = False
    at = norm_tokens(r.addressee)
    if at and not (at & ct):
        ok = False
    if ok:
        kept += 1
kr = kept / max(1, len(REG))
check('C3', '槽位保真度（GRL→散文 不丢任何槽位内容）', kr >= 0.999,
      '%d/%d = %.1f%%' % (kept, len(REG), kr * 100))

# ── C4 强度守恒（极性 + 保档）────────────────────────────
STYLES = {
    'xai_policy': {'name': 'xai_policy', 'open': '<policy>', 'close': '</policy>',
                   'modality': {'must': 'MUST', 'must_not': 'MUST NOT', 'should': 'SHOULD',
                                'may': 'MAY', 'can': 'MAY', 'unspecified': ''},
                   'frame': '{body}.'},
    'openai_plain': {'name': 'openai_plain', 'open': '', 'close': '',
                     'modality': {'must': 'must', 'must_not': 'must not', 'should': 'should',
                                  'may': 'may', 'can': 'may', 'unspecified': 'should'},
                     'frame': '{body}.'},
    'anthropic_effect': {'name': 'anthropic_effect', 'open': '', 'close': '',
                          'modality': {'must': 'always', 'must_not': 'never', 'should': 'prefer',
                                       'may': 'may', 'can': 'may', 'unspecified': ''},
                          'frame': '{body}, because it directly affects the user.'},
}
viol = 0
nchk = 0
for r in REG:
    for st in STYLES.values():
        ok, d = grl.check_polarity(r, st)
        nchk += 1
        if not ok:
            viol += 1
check('C4', '强度守恒（极性守恒 + 强度保档）', viol == 0,
      '检查 %d 次，违规 %d 次' % (nchk, viol))

# ── C5 风格可替换：同一规则多种文风 ──────────────────────
outs = defaultdict(set)
for r in REG:
    outs[r.id] = tuple(grl.compile_rule(r, st) for st in STYLES.values())
dist = Counter(len(set(v)) for v in outs.values())
check('C5', '风格可替换（同规则 × 多文风 ⇒ 多输出）',
      dist.get(3, 0) / max(1, len(outs)) >= 0.99,
      '输出变体数分布 %s（共 %d 条规则）' % (dict(dist), len(outs)))

# ── C6 风格表词表封闭 ─────────────────────────────────────
bad_styles = []
for name, st in STYLES.items():
    ok, bad = grl.check_style_vocabulary(st)
    if not ok:
        bad_styles.append((name, bad))
check('C6', '风格表词表封闭（映射值必须落在受控强度词表内）',
      not bad_styles, '违规风格表：%s' % (bad_styles or '无'))

# ── C7 模态枚举封闭 ───────────────────────────────────────
mods = set(r.modality for r in REG)
allowed = set(grl.MODALITY_ORDER)
check('C7', '模态枚举封闭（只有 6 个取值）',
      mods.issubset(allowed) and len(mods) == 6,
      '实测取值 %s' % sorted(mods))

# ── C8 四种引用形态 ───────────────────────────────────────
by_id = {r.id: r for r in RULES}
sample = [r for r in REG if r.scope_key][:50]
for r in sample[:5]:
    r.locus = 'D01'
ref_locus = grl.resolve('#D01', RULES, by_id)
ref_allele = grl.resolve('#D01~must', RULES, by_id)
ref_exact = grl.resolve('@' + sample[0].id, RULES, by_id)
check('C8a', '引用形态：位点引用 #D01（且不能把 locus=None 的规则算进去）',
      1 <= len(ref_locus) < len(RULES) // 2,
      '命中 %d 条（全集 %d 条）—— 上限检查是必须的：原实现返回 5526=全集仍被判 PASS'
      % (len(ref_locus), len(RULES)))
check('C8b', '引用形态：等位引用 #D01~must', len(ref_allele) >= 0 and
      all(r.modality == 'must' for r in ref_allele),
      '命中 %d 条，且全部 modality=must' % len(ref_allele))
check('C8c', '引用形态：精确引用 @ID', len(ref_exact) == 1 and ref_exact[0].id == sample[0].id,
      '命中 %d 条' % len(ref_exact))
check('C8d', '引用形态：位点+等位收窄（⊆ 关系成立）',
      len(ref_allele) <= len(ref_locus),
      '等位 %d ≤ 位点 %d' % (len(ref_allele), len(ref_locus)))

# ── C9 断言求值（含反例）─────────────────────────────────
ok1, d1 = grl.evaluate_assertion('@' + sample[0].id, '⊇', '@' + sample[0].id, RULES, by_id)
ok2, d2 = grl.evaluate_assertion('@' + sample[0].id, '⊥', '@' + sample[0].id, RULES, by_id)
ok3, d3 = grl.evaluate_assertion('@' + sample[0].id, '≡', '@' + sample[0].id, RULES, by_id)
check('C9', '断言求值 ⊇/⊥/≡ 对同一对象给出互补结论',
      ok1 and not ok2 and ok3,
      '⊇=%s ⊥=%s ≡=%s（同一对象必须 ⊇真 ⊥假 ≡真）' % (ok1, ok2, ok3))

# ── C10 否定三态完备 ─────────────────────────────────────
neg = Counter(r.negation for r in REG)
check('C10', '否定三态完备（yes/no/suspected 三者互斥且穷尽）',
      set(neg) == {'yes', 'no', 'suspected'} and sum(neg.values()) == len(REG),
      'yes=%d no=%d suspected=%d，合计=%d' % (neg['yes'], neg['no'], neg['suspected'], sum(neg.values())))

# ── C11 上游污染被检出（检测器在工作）────────────────────
trunc = sum(1 for r in RULES if r.truncated)
foreign = sum(1 for r in RULES if 'C:foreign_section' in r.unmapped)
# 自证：造一条污染条款，看检测器抓不抓得到
_probe = grl._rule_from_item({
    'anchor': 'x',
    'full_statement': 'Under Foo Section, when the bar is baz, you must do the thing.',
    'class': 'regulative',
    'regulative_components': {'A': 'you', 'D': 'must', 'I': 'do', 'B': 'the thing',
                              'C': 'Under Foo Section, when the bar is baz'},
}, 'PROBE', 'probe.json', 0)
_probe_ok = (not _probe.condition_raw.lower().startswith('under ')) and _probe.truncated
check('C11', '上游数据污染被显式标记（截断/外来 section），且检测器自证有效',
      trunc > 0 and _probe_ok,
      '语料中条件截断 %d 条；自证探针：污染条款被剥离并标记截断=%s' % (trunc, _probe_ok))

# ── C12 作用域规范化确实发生归并 ─────────────────────────
raw_secs = set(r.scope_raw for r in RULES if r.scope_raw)
norm_secs = set(r.scope_key for r in RULES if r.scope_key)
check('C12', '作用域规范化产生真实归并（原文保留 + 键归一）',
      len(norm_secs) < len(raw_secs) and len(raw_secs) >= 250,
      '原始 %d 个 → 规范化 %d 个（保留原文，键归一）' % (len(raw_secs), len(norm_secs)))

# ── C13 等位键分辨率单调性：L2 共享量必须 > L1 且 > L3 ──
def keys_of(rules, level):
    out = set()
    for r in rules:
        if r.cls != 'regulative':
            continue
        if level == 'L1':
            out.add((r.scope_key, r.modality))
        elif level == 'L2':
            out.add((r.scope_key, r.modality, r.negation, r.verb))
        elif level == 'L3':
            out.add((r.scope_key, r.modality, r.negation, r.verb, r.object_key))
    return out


PAIRS = [('ANTHROPIC', 'OPENAI'), ('ANTHROPIC', 'XAI'), ('HUME', 'MISTRAL'),
         ('META', 'GOOGLE'), ('DIA', 'CLUELY')]
l2_best = 0
tot = 0
for a, b in PAIRS:
    if a not in by_vendor or b not in by_vendor:
        continue
    tot += 1
    sh = {lv: len(keys_of(by_vendor[a], lv) & keys_of(by_vendor[b], lv)) for lv in ('L1', 'L2', 'L3')}
    if sh['L2'] >= sh['L1'] and sh['L2'] >= sh['L3']:
        l2_best += 1
check('C13', '等位键最优分辨率可复算（L2 = scope+模态+否定+动词 共享量最大）',
      tot > 0 and l2_best / tot >= 0.6,
      '%d/%d 组厂商对满足 L2 最优' % (l2_best, tot))

# ── C14 ★ 自证靶子：注入违规必须被抓住 ──────────────────
BAD_STYLE = {'name': 'bad', 'open': '', 'close': '',
             'modality': {'must': 'never', 'must_not': 'must', 'should': 'should',
                          'may': 'may', 'can': 'may', 'unspecified': ''},
             'frame': '{body}.'}
caught = 0
for r in REG[:200]:
    ok, d = grl.check_polarity(r, BAD_STYLE)
    if not ok:
        caught += 1
check('C14', '★ 自证靶子：故意把 must 映射成 never，判据必须报错',
      caught > 0, '200 条里被抓出 %d 条（判据不是摆设）' % caught)

# ── C15 反编译→编译 幂等：同规则两次编译必须逐字一致 ─────
r0 = REG[0]
c1 = grl.compile_rule(r0)
c2 = grl.compile_rule(r0)
check('C15', '编译器幂等（同输入两次编译逐字一致）', c1 == c2,
      'len=%d' % len(c1))

# ── 汇总 ──────────────────────────────────────────────────
npass = sum(1 for x in RESULTS if x['ok'])
ntot = len(RESULTS)
print('GRL 自检 · %d 条判据\n' % ntot)
for x in RESULTS:
    print('  [%s] %-4s %-46s %s' % ('PASS' if x['ok'] else 'FAIL', x['id'], x['name'], x['detail']))
print()
if npass == ntot:
    print('VERDICT: PASS（%d/%d 条判据全过）' % (npass, ntot))
    sys.exit(0)
else:
    print('VERDICT: FAIL（%d/%d 条判据通过，失败：%s）'
          % (npass, ntot, [x['id'] for x in RESULTS if not x['ok']]))
    sys.exit(1)
