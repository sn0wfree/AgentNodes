#!/usr/bin/env bash
# 一键复算：把本仓库的数字从零跑出来。
#
# 纪律：
#   - 幂等：重复跑不改变结果
#   - 不静默降级：拉不到语料就明说并给出替代指引，不假装跑通了
#   - 每步报 PASS/FAIL，末行给字面判决词
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WORK="${ROOT}/.work"
SRC="${ROOT}/src"
DATA="${ROOT}/data"
FIG="${ROOT}/figures"

CLONE="${CL4R1T4S_DIR}"
SPD="${WORK}/spd"
CLASS="${SPD}/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification"

PASS=0; FAIL=0
step() { printf '\n\033[1m▸ %s\033[0m\n' "$1"; }
ok()   { printf '  \033[32m[PASS]\033[0m %s\n' "$1"; PASS=$((PASS+1)); }
bad()  { printf '  \033[31m[FAIL]\033[0m %s\n' "$1"; FAIL=$((FAIL+1)); }
note() { printf '  \033[33m[NOTE]\033[0m %s\n' "$1"; }

mkdir -p "$WORK"

# 数据目录通过环境变量传给脚本 —— 脚本里不再有硬编码绝对路径
export GRL_CLASSIFICATION_DIR="${GRL_CLASSIFICATION_DIR:-$WORK/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification}"
export CL4R1T4S_DIR="${CL4R1T4S_DIR:-$WORK/CL4R1T4S-main}"

# ── 1. 语料 ────────────────────────────────────────────────
step "1/5 准备语料（只读拉取，不入库）"
if [ -d "$CLONE" ] && [ -n "$(ls -A "$CLONE" 2>/dev/null)" ]; then
  ok "CL4R1T4S 语料已就位：$CLONE"
else
  note "拉取 CL4R1T4S（AGPL-3.0，含厂商专有内容 —— 见 NOTICE.md 的授权说明）"
  for U in \
    "https://codeload.github.com/elder-plinius/CL4R1T4S/tar.gz/refs/heads/main" \
    "https://ghfast.top/https://github.com/elder-plinius/CL4R1T4S/archive/refs/heads/main.tar.gz"; do
    if curl -sL --max-time 180 "$U" -o "$WORK/cl.tgz" && tar tzf "$WORK/cl.tgz" >/dev/null 2>&1; then
      mkdir -p "$WORK/cl"; tar xzf "$WORK/cl.tgz" -C "$WORK/cl"
      mv "$WORK/cl"/*/ "$CLONE" 2>/dev/null && rmdir "$WORK/cl" 2>/dev/null
      ok "CL4R1T4S 拉取成功（$U）"; break
    fi
  done
  [ -d "$CLONE" ] && [ -n "$(ls -A "$CLONE" 2>/dev/null)" ] || bad "CL4R1T4S 拉取失败 —— 存在性层实验将跳过（不会伪造结果）"
fi

if [ -d "$CLASS" ]; then
  ok "条款级数据已就位：$CLASS"
else
  note "拉取 SystemPromptDeconstruction（条款级抽取产物）"
  if git clone --depth 1 https://github.com/mytkom/SystemPromptDeconstruction.git "$SPD" 2>/dev/null \
     || git clone --depth 1 https://ghfast.top/https://github.com/mytkom/SystemPromptDeconstruction.git "$SPD" 2>/dev/null; then
    ok "SystemPromptDeconstruction 拉取成功"
  else
    bad "条款级数据拉取失败 —— GRL 实验将跳过（不会伪造结果）"
  fi
fi

# ── 2. 依赖 ────────────────────────────────────────────────
step "2/5 检查依赖"
python3 - <<'PY'
import importlib, sys
need = {'numpy':'numpy','scipy':'scipy','pandas':'pandas','matplotlib':'matplotlib'}
miss = [v for k, v in need.items() if not importlib.util.find_spec(k)]
print('  [PASS] 核心依赖齐全' if not miss else '  [NOTE] 缺少: %s（仅影响绘图）' % ', '.join(miss))
PY

# ── 3a. 重建派生数据（存在性层 → 维度层）───────────────────
step "3/5a 重建派生数据（从语料到 data/）"
cd "$SRC"
if [ -d "$CLONE" ]; then
  for E in report_data.py dimspec.py final2.py; do
    if python3 "$E" >/dev/null 2>&1; then ok "$E"; else bad "$E"; fi
  done
else
  bad "缺少语料，派生数据重建跳过"
fi

# ── 3. 分析实验 ────────────────────────────────────────────
step "3/5 跑分析实验"
cd "$SRC"
if [ -d "$CLONE" ]; then
  for E in exp1_loci.py exp2_crossval.py exp3_loci_schema.py exp4_family_null.py \
           exp5_family_structure.py exp6_presence_vs_allele.py exp7_null_fixed.py \
           exp8_size_controlled.py exp9_allele_separates.py exp10_allele_granularity.py \
           exp11_allele_axis.py; do
    [ -f "$E" ] || continue
    if python3 "$E" >/dev/null 2>&1; then ok "$E"; else bad "$E"; fi
  done
else
  bad "缺少语料，存在性层/等位层实验全部跳过"
fi

# ── 4. GRL 实验 + 自检 ─────────────────────────────────────
step "4/5 跑 GRL 实验与自检"
if [ -d "$CLASS" ]; then
  for E in grl_exp.py grl_exp2.py grl_demo_ownership.py; do
    if python3 "$E" >/dev/null 2>&1; then ok "$E"; else bad "$E"; fi
  done
  if python3 grl_check.py >/tmp/grl_check.log 2>&1; then
    ok "grl_check.py —— $(tail -1 /tmp/grl_check.log)"
  else
    bad "grl_check.py —— $(tail -1 /tmp/grl_check.log)"
  fi
  if python3 sanitize.py --check >/dev/null 2>&1; then ok "sanitize.py --check（数据脱敏）"; else bad "sanitize.py --check"; fi
else
  bad "缺少条款级数据，GRL 实验与自检全部跳过"
fi

# ── 5. 页面 + Markdown 审计 ────────────────────────────────
step "5/5 重新生成可视化页并审计 Markdown"
cd "$SRC"
for E in mkgen.py mkpage.py mkdims.py mk_grl_page.py mk_overview.py; do
  if python3 "$E" >/dev/null 2>&1; then ok "$E"; else bad "$E"; fi
done
for E in check_page.py check_dims.py check_gen.py check_grl_page.py; do
  [ -f "$E" ] || continue
  if python3 "$E" >/tmp/$(basename $E).log 2>&1; then
    ok "$E —— $(tail -1 /tmp/$(basename $E).log)"
  else
    bad "$E —— $(tail -1 /tmp/$(basename $E).log)"
  fi
done
if python3 audit_numbers.py >/tmp/audit_numbers.log 2>&1; then
  ok "audit_numbers.py —— $(tail -1 /tmp/audit_numbers.log)"
else
  bad "audit_numbers.py —— $(tail -1 /tmp/audit_numbers.log)"
fi
if python3 md_audit.py "$ROOT"/docs/*.md >/tmp/md_audit.log 2>&1; then
  ok "md_audit.py —— $(tail -1 /tmp/md_audit.log)"
else
  bad "md_audit.py —— $(tail -1 /tmp/md_audit.log)"
fi

printf '\n────────────────────────────────────────\n'
if [ "$FAIL" -eq 0 ]; then
  printf 'VERDICT: PASS（%d 项全过）\n' "$PASS"
  exit 0
else
  printf 'VERDICT: FAIL（%d 项通过，%d 项失败）\n' "$PASS" "$FAIL"
  exit 1
fi
