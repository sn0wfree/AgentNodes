#!/usr/bin/env bash
# 推送到 GitHub。
#
# 需要一个具备 repo 权限的 GitHub token，通过环境变量传入：
#   export GITHUB_TOKEN=ghp_xxx
# 或用 secret 工具存入后由运行环境注入 ${GITHUB_TOKEN}
#
# 用法：bash scripts/push.sh [owner] [repo]
set -euo pipefail

OWNER="${1:-sn0wfree}"
REPO="${2:-prompt-genome}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ -z "${GITHUB_TOKEN:-}" ]; then
  echo "缺少 GITHUB_TOKEN 环境变量。"
  echo "  export GITHUB_TOKEN=ghp_xxx   # 需要 repo 权限"
  exit 1
fi

cd "$ROOT"

# 提交前自检：数据必须已脱敏
python3 src/sanitize.py --check >/dev/null || {
  echo "数据未脱敏，拒绝推送。"; exit 1; }

git add -A
git -c user.name="$(git config user.name || echo sn0wfree)" \
    -c user.email="$(git config user.email || echo sn0wfree@users.noreply.github.com)" \
    commit -m "${1:-chore}: update prompt-genome research archive" || echo "(无新变更)"

REMOTE="https://x-access-token:${GITHUB_TOKEN}@github.com/${OWNER}/${REPO}.git"
git remote remove origin 2>/dev/null || true
git remote add origin "$REMOTE"
git push -u origin HEAD --tags
echo "已推送：https://github.com/${OWNER}/${REPO}"
