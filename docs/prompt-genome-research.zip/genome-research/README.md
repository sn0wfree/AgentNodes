# prompt-genome · 提示词基因研究

> **Prompt Genome Research** —— 把 26 家厂商的系统提示词，从「一堆散文」变成「可比较、可判定、可挂评测分数的基因序列」，并为此造一门专用规则语言（GRL）。

这个仓库是 **9 份研究报告 + 全部可复算脚本 + 5 张可视化页**的存档。
所有数字都可以自己跑出来。

---

## 一句话结论

**没有直接先例，但零件全都齐了** —— 业界有 46 个相邻先例（DelvePO / PromptGenome / SEPO / CFG / phenome / PhyloLM / ARCCS / IFEval / Instruction Hierarchy …），但**没有一套是为「跨厂商系统提示词」设计的**：位点集自动发现、跨 prompt 逐位点对齐 + 共识序 + 家族聚类这三处，是被检索证实的空白。

于是我们自研了一条链路：

```
存在性层    「这个位点写没写」        23 位点 × 26 家 → 23 种图案
   ↓
等位层      「用哪种说法写」          模态 · 否定 · 受控动词 · 对象 → 趋同比值
   ↓
编码层      GRL 基因规约语            规则的一等数据，散文是编译产物
```

## 九份报告

| # | 文档 | 一句话结论 |
|---|---|---|
| 1 | [`docs/00-项目评估`](docs/CL4R1T4S-项目评估-20261117.md) | CL4R1T4S：内容可用，但 **AGPL-3.0 覆盖厂商专有提示词 ⇒ 维护者无权授予该许可**；README 含提示注入（已识别拒绝执行） |
| 2 | [`docs/01-共性原则`](docs/提示词共性原则-20261117.md) | 22 个语义桶、六层原则模型；**「人人都在写」≠「人人当成一条规则」** |
| 3 | [`docs/02-基因粗序列`](docs/提示词基因粗序列-20261117.md) | 23 位点 × 26 家 = 598 组合 → **23 种存在性图案**；全局唯一组合只有 3 个，全属 ANTHROPIC |
| 4 | [`docs/03-维度写作规范`](docs/提示词核心维度-写作规范-20261117.md) | D01–D23；**覆盖广度 × 约束强度**两轴；强制措辞必须**按章节判定**不按行 |
| 5 | [`docs/04-业界先例调研`](docs/提示词基因框架-业界先例调研-20261117.md) | 46 个先例逐一拆解 + 可执行的否定证明（arXiv 全库四组关键词检索 0 命中）；**同时推翻 6 条流传说法** |
| 6 | [`docs/05-机制实测修订v2`](docs/提示词基因机制-实测修订-v2-20261118.md) | 等位轴第三条轴（趋同比值）成立；**「Tier 0 没写全」不是缺陷是定制化的必然结果** |
| 7 | [`docs/06-GRL基因规约语`](docs/GRL-基因规约语-20261118.md) | 5526 条条款上跑通反编译→编译闭环；**19 条机检判据全过** |
| 8 | [`docs/07-Fable52核实与对接`](docs/Fable52提示指南-一手源核实与研究线对接-20261120.md) | 核实 Anthropic 官方 Fable 5.2 指南：**23 条断言 6 处偏差**；并接回三个此前缺实测支撑的结论 |
| 9 | [`docs/08-讨论总纲`](docs/提示词基因组研究线-讨论总纲-20261118.md) | **接续讨论的入口**：结论速查 · 唯一数字源 · 已被推翻的结论 · Q1–Q13 未决问题 |

## 关键数字（口径见各报告）

| | 数字 | 口径 |
|---|---|---|
| 存在性图案 | **23 种**（26 家） | DEVIN/MANUS/SAMEDEV 三合一、OPENAI/ZCode 二合一 |
| 全局唯一组合 | **3 个** | 598 组合里唯一，全属 ANTHROPIC |
| 强度 | 身份锚定 96% 覆盖 / **8% 强制** | 注入防御 23% 覆盖 / **33% 强制** |
| 等位趋同比值 | **0.926**（≈随机） | 解析期望法；平均私有等位 71.9% |
| T0 底线维度 | **5 个全部 100% 互斥** | 零例外 |
| 条款未写模态 | **68.2%** | 2888 / 4237 ⇒ 只读模态槽对三分之二条款无信息 |
| GRL 槽位保真度 | **100%** | 4237 / 4237，编译回散文不丢任何槽位 |
| 强度守恒 | **0 违规** | 12711 次检查 × 3 套文风 |
| 授权型身份锚定覆盖 | **0 / 26 家** | 而官方实测其把合并重复代码从 <10% 推到 ~75% |

## 目录

```
docs/          九份报告（Markdown）
figures/       五张可视化页（单文件自包含 HTML，可直接打开）
src/           全部脚本（分析 + 实验 + 页面生成 + 自检）
data/          脱敏后的聚合数据（见下方「授权边界」）
scripts/
  bootstrap.sh 一键复算：从零跑出全部数字
  push.sh      推送到 GitHub
```

## 怎么复算

```bash
git clone <repo> && cd prompt-genome
bash scripts/bootstrap.sh
```

`bootstrap.sh` 会：拉语料 → 装依赖 → 跑 11 个存在性/等位实验 → 跑 2 轮 GRL 实验 →
重新生成 5 张可视化页 → 跑全部自检（19 条机检判据 + 双视口页面检查 + Markdown 审计）。

单跑某一步：

```bash
cd src
python3 grl_check.py          # GRL 19 条判据，末行字面判决词，退出码即结论
python3 grl_exp.py            # 反编译覆盖 / 模态枚举 / 断言求值
python3 grl_exp2.py           # 多分辨率等位键 / 槽位保真 / 风格可替换
python3 grl_demo_ownership.py # GRL 表达力检验 + 语料零覆盖对照
python3 sanitize.py --check   # 数据脱敏自检（CI 用）
python3 md_audit.py ../docs/*.md
```

## ⚠ 授权边界（请先读这段）

本仓库**不包含**任何厂商系统提示词的完整正文。原因是明确的：

- 源语料 CL4R1T4S 用 **AGPL-3.0** 覆盖了 Anthropic / OpenAI / xAI 等厂商的**专有提示词**，
  而**维护者不拥有著作权，无权授予该许可**；AGPL 的网络 Copyleft 还会把风险传染给二次分发者。
- 因此本仓库只发布三样东西：
  1. **我们自己的分析产出**（脚本、聚合统计、原创结论）；
  2. **学术引用级的短片段**（报告里每处都带出处标注，合计约 2600 字符）；
  3. **脱敏后的条款级导出**（原文替换为 sha256 锚点，见 `data/anchors.json`）。

- **原始语料请自行获取**（`elder-plinius/CL4R1T4S`，AGPL-3.0），并注意它的授权瑕疵。
  `scripts/bootstrap.sh` 只做**只读拉取**用于复算，不会把它提交进本仓库。
- 报告里引用的第三方材料（含 Anthropic 官方公开文档）均标注出处，各归其作者。

本仓库自身的代码与原创分析采用 **MIT**；第三方引用不在此授权范围内，详见 [`NOTICE.md`](NOTICE.md)。

## 引用的外部材料

| 材料 | 用途 | 授权 |
|---|---|---|
| [`elder-plinius/CL4R1T4S`](https://github.com/elder-plinius/CL4R1T4S) | 原始语料（26 家 / 82 文件） | AGPL-3.0（**含厂商专有内容 ⇒ 授权瑕疵，见上**） |
| SPDeconstruction（条款级抽取产物） | 5526 条规约/构成条款 | 上游研究产物；**生成模型为 gemini-flash-3.5 一次生成，非黄金标准** |
| Anthropic 官方文档 `platform.claude.com` | ownership 提示的官方实测 | 公开文档；引用仅限短片段 |
| arXiv / 论文 46 篇 | 业界先例 | 各自作者 |

## 复算需要的外部依赖

```bash
pip install numpy scipy pandas python-docx python-pptx pypdf matplotlib reportlab
pip install playwright && playwright install chromium   # 页面自检需要
```

沙箱备注：`raw.githubusercontent.com` 直连 TLS 可能被掐断，走 `ghfast.top` 代理；
`huggingface.co` 在某些网络不可达。`platform.claude.com/docs/...` 会有区域屏蔽，
取官方文档正文请用 `https://platform.claude.com/llms-full.txt`。

## License

MIT —— 见 [`LICENSE`](LICENSE)。第三方引用见 [`NOTICE.md`](NOTICE.md)。
