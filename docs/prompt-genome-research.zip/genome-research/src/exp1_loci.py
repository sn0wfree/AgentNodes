#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E1：用 SPDeconstruction 的 5526 条条款，检验「位点集能否自动长出来、
不同厂商能否落到同一批位点上」。

只用它已有的 5 槽（regulative: A/D/I/B/C；constitutive: E/F/P），不引入外部先验。
"""
import os
import json, glob, os, re, collections, sys

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')

def norm(s):
    if not s: return ""
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)
    s = s.strip(" .,:;!?\"'`()[]")
    return s

def load():
    by_vendor = {}
    files = sorted(glob.glob(os.path.join(ROOT, "*", "*.json")))
    for f in files:
        vendor = os.path.basename(os.path.dirname(f))
        items = json.load(open(f, encoding="utf-8"))
        name = os.path.basename(f)[:-5]
        by_vendor.setdefault(vendor, []).append((name, items))
    return by_vendor

def main():
    by_vendor = load()
    vendors = sorted(by_vendor)
    print(f"厂商 {len(vendors)} 个：{vendors}")

    # ---------- 1. 三分类 × 厂商 ----------
    print("\n=== 1. 条款类型分布（这是 SPDeconstruction 已有的粗粒度位点） ===")
    print(f"{'厂商':<12}{'文件':>4}{'条款':>7}{'regul':>8}{'const':>7}{'nonstmt':>9}{'regul%':>8}")
    tot = collections.Counter()
    for v in vendors:
        c = collections.Counter(); n = 0
        for name, items in by_vendor[v]:
            for it in items:
                c[it.get("class")] += 1; n += 1
        tot.update(c)
        rp = c["regulative"] / n * 100 if n else 0
        print(f"{v:<12}{len(by_vendor[v]):>4}{n:>7}{c['regulative']:>8}{c['constitutive']:>7}"
              f"{c['non-statement']:>9}{rp:>7.1f}%")
    N = sum(tot.values())
    print(f"{'合计':<12}{'':>4}{N:>7}{tot['regulative']:>8}{tot['constitutive']:>7}{tot['non-statement']:>9}"
          f"{tot['regulative']/N*100:>7.1f}%")

    # ---------- 2. Deontic（模态/强度）× 厂商 ----------
    print("\n=== 2. 模态字段 D 的取值分布 × 厂商（我们的「强度」字段是否真有信号） ===")
    print("— 空值表示「显式模态缺失」= 散文/隐含规范 —")
    dvals = collections.Counter()
    perv = collections.defaultdict(collections.Counter)
    for v in vendors:
        for name, items in by_vendor[v]:
            for it in items:
                if it.get("class") != "regulative": continue
                rc = it.get("regulative_components") or {}
                d = norm(rc.get("D"))
                dvals[d] += 1
                perv[v][d] += 1
    top = [d for d, _ in dvals.most_common(12)]
    for d in top:
        dvals[d] = dvals[d]
    hdr = "".join(f"{d[:9] if d else '(空)':>11}" for d in top)
    print(f"{'厂商':<12}{'条款':>6}{hdr}")
    for v in vendors:
        row = perv[v]
        cells = "".join(f"{row[d]/max(1,sum(row.values()))*100:>10.1f}%" for d in top)
        print(f"{v:<12}{sum(row.values()):>6}{cells}")

    # ---------- 3. Aim 词表：能否聚出稳定共享位点 ----------
    print("\n=== 3. 位点候选：从 Aim(I) 归一化后的取值分布 ===")
    aim = collections.Counter()
    aim_v = collections.defaultdict(set)
    for v in vendors:
        for name, items in by_vendor[v]:
            for it in items:
                if it.get("class") != "regulative": continue
                rc = it.get("regulative_components") or {}
                a = norm(rc.get("I"))
                if not a: continue
                aim[a] += 1
                aim_v[a].add(v)
    total = sum(aim.values())
    print(f"Aim 取值总数 {len(aim)}，覆盖条款 {total}")
    cum = 0; k = 0
    for a, c in aim.most_common():
        cum += c; k += 1
        if k in (20, 50, 100, 200, 500, 1000, len(aim)):
            print(f"  top {k:>5} 取值覆盖 {cum}/{total} = {cum/total*100:5.1f}%")
    print("\n  覆盖 ≥3 家厂商的 Aim 取值数：",
          sum(1 for a, vs in aim_v.items() if len(vs) >= 3),
          f"（占比 {sum(aim[a] for a,vs in aim_v.items() if len(vs)>=3)/total*100:.1f}% 的条款）")
    print("  top 30 Aim（带覆盖厂商数）：")
    for a, c in aim.most_common(30):
        print(f"    {c:>5}  {len(aim_v[a]):>2}家  {a[:60]}")

    # ---------- 4. 存在集 Jaccard：厂商间「共有位点比例」 ----------
    print("\n=== 4. 厂商间共有位点（存在集 Jaccard）—— 家族聚类的距离口径 ===")
    sets = {v: set() for v in vendors}
    for v in vendors:
        for name, items in by_vendor[v]:
            for it in items:
                if it.get("class") != "regulative": continue
                rc = it.get("regulative_components") or {}
                a = norm(rc.get("I"))
                if a: sets[v].add(a)
    print("各家 Aim 取值集合大小：", {v: len(sets[v]) for v in vendors})
    pairs = []
    for i, a in enumerate(vendors):
        for b in vendors[i+1:]:
            u = len(sets[a] | sets[b]); inter = len(sets[a] & sets[b])
            j = inter / u if u else 0
            pairs.append((j, a, b, inter, u))
    pairs.sort(reverse=True)
    print("最相似的 10 对：")
    for j, a, b, inter, u in pairs[:10]:
        print(f"    J={j:.3f}  {a} ∩ {b} = {inter}/{u}")
    print("最不相似的 5 对：")
    for j, a, b, inter, u in pairs[-5:]:
        print(f"    J={j:.3f}  {a} ∩ {b} = {inter}/{u}")
    js = [p[0] for p in pairs]
    print(f"  Jaccard 均值 {sum(js)/len(js):.3f}  中位 {sorted(js)[len(js)//2]:.3f}  "
          f"max {max(js):.3f}  min {min(js):.3f}")

    # ---------- 5. 共有位点：共识序的候选 ----------
    print("\n=== 5. 共有位点（≥K 家同时出现）—— 共识序的候选锚 ===")
    by_k = collections.Counter()
    for a, vs in aim_v.items():
        by_k[len(vs)] += 1
    for k in sorted(by_k, reverse=True):
        if k >= 2:
            print(f"    ≥{k:>2} 家共有：{by_k[k]:>5} 个 Aim")
    # 全 15 家都有的
    common_all = [a for a, vs in aim_v.items() if len(vs) == len(vendors)]
    print(f"    全部 {len(vendors)} 家都有的 Aim：{len(common_all)} 个 → {common_all[:12]}")
    # 覆盖 ≥8 家的
    c8 = sorted([(len(vs), a, aim[a]) for a, vs in aim_v.items() if len(vs) >= 8],
                reverse=True)
    print(f"    ≥8 家共有的 Aim（前 20，按总次数）：")
    for nv, a, c in sorted(c8, key=lambda x: -x[2])[:20]:
        print(f"      {c:>5}次 {nv:>2}家  {a[:58]}")

if __name__ == "__main__":
    main()
