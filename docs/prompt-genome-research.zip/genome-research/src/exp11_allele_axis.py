#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E11：逐维度的「等位趋同比值」——第三条轴。

★ 为什么不用抽样 null：抽样 null 从「该维全局等位池」重抽，
  池里高频等位占比高 ⇒ 抽出的集合天然高度重叠 ⇒ null 被高估
  （E10 抽样 null 0.077 vs 实测 0.020，误导成「厂商刻意互斥」）。
  解析期望无此偏差：同一维度上把所有厂商的等位并成词表 V_d，
  两家共享等位的期望 = |A|·|B|/|V_d|。

比值 = 实测共享 / 期望共享
  ≈1    该维等位在厂商间既不趋同也不互斥（整体接近随机）
  >1    趋同型：厂商在这维上用同一批等位（套话）
  <1    互斥型：厂商在这维上刻意用不同的等位（法律立场 / 产品定位定制）

这个系数直接决定「在这一维上做跨厂商等位比较有没有意义」。
"""
import os
import json, glob, os, collections, itertools, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from allele_lib import canon_verb, modality, is_negated
from genome_lib import LOCI, RX

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'allele_axis.json')

EX = collections.defaultdict(set)
REC = collections.defaultdict(list)
for f in sorted(glob.glob(os.path.join(ROOT, "*", "*.json"))):
    v = os.path.basename(os.path.dirname(f))
    for it in json.load(open(f, encoding="utf-8")):
        rc = it.get("regulative_components") or {}
        t = ((it.get("full_statement") or "") + " " + (it.get("anchor") or "")).lower()
        aim = (rc.get("I") or "").strip().lower()
        dm = (rc.get("D") or "").strip().lower()
        c = bool((rc.get("C") or "").strip())
        for d in LOCI:
            if RX[d].search(t):
                EX[v].add(d)
                REC[v].append((d, aim, dm, c))

V = sorted(EX); DIMS = list(LOCI)

def key(a, m, c):
    return f"{canon_verb(a)}|{'N' if is_negated(a) else 'P'}|{modality(m) or '-'}"

AL = collections.defaultdict(lambda: collections.defaultdict(set))
for v in V:
    for (d, aim, dm, c) in REC[v]:
        k = key(aim, dm, c)
        if k.strip("|-"):
            AL[v][d].add(k)

rows = []
for d in DIMS:
    have = [v for v in V if AL[v].get(d)]
    if len(have) < 2:
        continue
    vocab = set().union(*[AL[v][d] for v in have])
    U = len(vocab)
    obs = sum(len(AL[a][d] & AL[b][d]) for a, b in itertools.combinations(have, 2))
    exp = sum(len(AL[a][d]) * len(AL[b][d]) / U for a, b in itertools.combinations(have, 2))
    cnt = collections.Counter()
    for v in have:
        for a in AL[v][d]:
            cnt[a] += 1
    priv = sum(1 for v in have for a in AL[v][d] if cnt[a] == 1) / max(1, sum(len(AL[v][d]) for v in have))
    ratio = obs / exp if exp else 0.0
    kind = "互斥型" if ratio < 0.75 else ("趋同型" if ratio > 1.25 else "中性")
    rows.append(dict(dim=d, vendors=len(have), vocab=U, observed=obs,
                      expected=round(exp, 1), ratio=round(ratio, 2),
                      private_ratio=round(priv, 2), kind=kind))

rows.sort(key=lambda r: r["ratio"])
tot_o = sum(r["observed"] for r in rows)
tot_e = sum(r["expected"] for r in rows)
print(f"厂商 {len(V)} 家 ｜ 维度 {len(rows)} 个可比较")
print(f"合计：实测共享 {tot_o}  期望 {tot_e:.1f}  整体比值 {tot_o/tot_e:.2f}")
print(f"平均私有等位占比 {sum(r['private_ratio'] for r in rows)/len(rows)*100:.0f}%\n")
print(f"{'维度':<16}{'厂商':>4}{'词表':>6}{'实测':>7}{'期望':>8}{'比值':>7}{'私有率':>8}  判定")
for r in rows:
    print(f"{r['dim']:<16}{r['vendors']:>4}{r['vocab']:>6}{r['observed']:>7}{r['expected']:>8}"
          f"{r['ratio']:>7.2f}{r['private_ratio']*100:>7.0f}%  {r['kind']}")

json.dump({"vendors": V, "dims": rows, "overall_ratio": round(tot_o/tot_e, 3),
           "mean_private_ratio": round(sum(r["private_ratio"] for r in rows)/len(rows), 3),
           "threshold": {"互斥型": "<0.75", "中性": "0.75-1.25", "趋同型": ">1.25"}},
          open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"\n写入 {OUT}")
