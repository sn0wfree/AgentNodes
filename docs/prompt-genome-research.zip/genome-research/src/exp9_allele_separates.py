#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E9 · 修正版：等位编码能不能分开「存在性分不开」的厂商？

★ 修掉前几版 null 的同一个 bug：相似度函数闭包引用了真实数据，
  null 里重抽了样本却没传进去 ⇒ null 恒等于实测。本版所有相似度函数
  **显式接收数据结构**，null 与实测走完全相同的调用路径。

null 设计：逐 (厂商, 维度) 单元，把等位集按**同样大小**从该维的全局等位池重抽
         ⇒ 保住「每单元等位数」与「每维全局等位频次」两个边际，只打散共现。
"""
import os
import json, glob, os, collections, itertools, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from allele_lib import allele_key
from genome_lib import LOCI, RX

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')

# ---------- 载入 ----------
EX = collections.defaultdict(set)
AL = collections.defaultdict(lambda: collections.defaultdict(set))
for f in sorted(glob.glob(os.path.join(ROOT, "*", "*.json"))):
    v = os.path.basename(os.path.dirname(f))
    for it in json.load(open(f, encoding="utf-8")):
        rc = it.get("regulative_components") or {}
        txt = (it.get("full_statement") or "") + " " + (it.get("anchor") or "")
        t = txt.lower()
        for d in LOCI:
            if not RX[d].search(t):
                continue
            EX[v].add(d)
            ak = allele_key(rc.get("I") or "", rc.get("D") or "", (rc.get("C") or "").strip())
            if ak.strip("|-"):
                AL[v][d].add(ak)
V = sorted(EX)
DIMS = list(LOCI)

def jac(a, b):
    u = len(a | b)
    return len(a & b) / u if u else 0.0

def ex_sim(EXD, a, b):
    """存在性相似度：两家在多少个维度上都有（23 维平均）"""
    return len(EXD[a] & EXD[b]) / len(DIMS)

def al_sim(ALD, a, b):
    """等位相似度：逐维等位集 Jaccard 的平均"""
    s = 0.0
    for d in DIMS:
        A, B = ALD[a].get(d, set()), ALD[b].get(d, set())
        if A or B:
            s += jac(A, B)
    return s / len(DIMS)

def null_ex(rounds=300, seed=20261118):
    rng = random.Random(seed)
    pool = []
    for v in V:
        pool.extend(EX[v])
    out = []
    for _ in range(rounds):
        S2 = {v: set(rng.sample(pool, len(EX[v]))) for v in V}   # 有放回池，元素可能重复 → 用 set 后可能变小
        # 保证大小：不足则补齐（从池里再抽），避免 null 天然更稀
        for v in V:
            while len(S2[v]) < len(EX[v]):
                S2[v].add(rng.choice(pool))
        out.append(sum(ex_sim(S2, a, b) for a, b in itertools.combinations(V, 2)) / len(list(itertools.combinations(V, 2))))
    out.sort(); return out

def null_al(rounds=300, seed=20261118):
    rng = random.Random(seed)
    pools = {}
    for d in DIMS:
        p = []
        for v in V:
            p.extend(AL[v].get(d, set()))
        pools[d] = p
    pairs = list(itertools.combinations(V, 2))
    out = []
    for _ in range(rounds):
        S2 = collections.defaultdict(dict)
        for v in V:
            for d in DIMS:
                cell = AL[v].get(d, set())
                if not cell: continue
                pool = pools[d]
                if len(pool) >= len(cell):
                    S2[v][d] = set(rng.sample(pool, len(cell)))
                else:
                    S2[v][d] = set(pool)
        out.append(sum(al_sim(S2, a, b) for a, b in pairs) / len(pairs))
    out.sort(); return out

pairs = list(itertools.combinations(V, 2))
print(f"厂商 {len(V)} 家，维度 {len(DIMS)} 个，厂商对 {len(pairs)}")

print("\n=== A. 实测 vs null（各走同一条调用路径） ===")
obs_e = sum(ex_sim(EX, a, b) for a, b in pairs) / len(pairs)
ne = null_ex()
obs_a = sum(al_sim(AL, a, b) for a, b in pairs) / len(pairs)
na = null_al()
for label, obs, nulls in [("存在性相似度", obs_e, ne), ("等位相似度", obs_a, na)]:
    p = sum(1 for x in nulls if x >= obs) / len(nulls)
    print(f"  {label:<12} 实测 {obs:.4f}   null 中位 {nulls[len(nulls)//2]:.4f}   "
          f"null95 {nulls[int(.95*len(nulls))]:.4f}   p(超基线)={p:.3f}"
          f"{'   ★ 超基线' if p <= 0.05 else ''}")

print("\n=== B. 存在性最接近的厂商对，等位能不能分开？ ===")
srt = sorted(pairs, key=lambda p: -ex_sim(EX, p[0], p[1]))
print(f"  {'厂商对':<28}{'存在性J':>9}{'等位J':>9}{'等位差异位点数':>15}")
for a, b in srt[:12]:
    da = AL[a].get("", set())
    diff = [d for d in DIMS if AL[a].get(d, set()) != AL[b].get(d, set())]
    print(f"  {a+' ~ '+b:<28}{ex_sim(EX,a,b):>9.3f}{al_sim(AL,a,b):>9.3f}{len(diff):>15}")
print("  …")
for a, b in srt[-4:]:
    diff = [d for d in DIMS if AL[a].get(d, set()) != AL[b].get(d, set())]
    print(f"  {a+' ~ '+b:<28}{ex_sim(EX,a,b):>9.3f}{al_sim(AL,a,b):>9.3f}{len(diff):>15}")

print("\n=== C. 等位能否区分「存在性完全相同」的组合 ===")
bypat = collections.defaultdict(list)
for v in V: bypat[frozenset(EX[v])].append(v)
hit = 0
for pat, vs in bypat.items():
    if len(vs) < 2: continue
    hit += 1
    for a, b in itertools.combinations(vs, 2):
        diff = [d for d in DIMS if AL[a].get(d, set()) != AL[b].get(d, set())]
        print(f"  {a} ~ {b}: 存在集相同（{len(pat)} 维），等位不同的维度 {len(diff)} 个 → {diff}")
if not hit:
    print("  （15 家里无完全相同的存在集）")
    # 退而求其次：存在性差 1 维的对里，等位差多少
    print("  存在性差 ≤1 维的对，等位差异维度数分布：")
    import collections as C
    c = C.Counter()
    for a, b in pairs:
        k = abs(len(EX[a] ^ EX[b]))
        if k <= 2:
            diff = [d for d in DIMS if AL[a].get(d, set()) != AL[b].get(d, set())]
            c[(k, len(diff))] += 1
    for (k, dn), n in sorted(c.items()):
        print(f"    存在性差 {k} 维 → 等位差 {dn} 个维度：{n} 对")
