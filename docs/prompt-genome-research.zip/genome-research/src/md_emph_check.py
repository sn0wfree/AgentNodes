#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""按 CommonMark/GFM 的 flanking 规则扫描 Markdown 里的 ** 强强调配对，
找出「不会被解析成加粗」的片段。纯诊断工具，不改文件。"""
import io, re, sys, unicodedata

def is_ws(ch):
    return ch == "" or ch.isspace()

def is_punct(ch):
    if ch == "":
        return False
    if ch.isascii():
        return not (ch.isalnum())
    cat = unicodedata.category(ch)
    return cat.startswith(("P", "S"))

def flank_ok(prev, nxt):
    """返回 (left_flanking, right_flanking)"""
    lf = (not is_ws(nxt)) and ((not is_punct(nxt)) or is_ws(prev) or is_punct(prev))
    rf = (not is_ws(prev)) and ((not is_punct(prev)) or is_ws(nxt) or is_punct(nxt))
    return lf, rf

def strong_ok(prev, nxt):
    """** 的 open / close 资格。
    CommonMark Rule 8/9：左贴可开、右贴可闭。**没有** `_` 那个
    「不能同时右贴」的额外限制（那只适用于下划线）。"""
    lf, rf = flank_ok(prev, nxt)
    return lf, rf

def scan(text):
    """返回无法成对解析的 ** 位置列表"""
    positions = [m.start() for m in re.finditer(r"\*\*(?!\*)", text)]
    flags = []
    for p in positions:
        prev = text[p - 1] if p > 0 else ""
        nxt = text[p + 2] if p + 2 < len(text) else ""
        co, cc = strong_ok(prev, nxt)
        flags.append((p, co, cc))
    problems = []
    # 贪心配对：栈式匹配 opener/closer
    stack = []
    for idx, (p, co, cc) in enumerate(flags):
        if cc and stack:
            # 尝试与栈顶 opener 配对
            op_idx = stack.pop()
            op_p, op_co, _ = flags[op_idx]
            if not op_co:
                problems.append((op_p, p, "opener 不可用", text[op_p:p+2]))
        elif co:
            stack.append(idx)
        else:
            problems.append((p, p, "既不能开也不能闭", text[max(0,p-30):p+32]))
    for idx in stack:
        p = flags[idx][0]
        problems.append((p, p, "没有配对的闭合标记", text[max(0,p-30):p+32]))
    return problems, len(positions)

if __name__ == "__main__":
    path = sys.argv[1]
    s = io.open(path, encoding="utf-8").read()
    # 去掉行内代码与围栏代码，避免误报
    def blank(m):
        return "".join(" " if ch == "*" else ch for ch in m.group(0))
    stripped = re.sub(r"```.*?```", blank, s, flags=re.S)
    stripped = re.sub(r"`[^`\n]*`", blank, stripped)
    probs, total = scan(stripped)
    print(f"文件：{path}")
    print(f"** 出现 {total} 次；不可解析 {len(probs)} 处")
    for a, b, why, ctx in probs:
        print(f"  @{a} {why}")
        print(f"      {ctx.replace(chr(10), '⏎')}")
