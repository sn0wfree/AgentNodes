# -*- coding: utf-8 -*-
"""把提示词编码成「基因粗序列」：位点=原则，符号=等位基因，顺序=表达顺序"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
import os,re,json,collections,math
ROOT=os.environ.get('CL4R1T4S_DIR') or os.path.join(ROOT_DIR,'CL4R1T4S-main')
HTMLISH=set("""div span p title head body script style link img path svg html meta br hr i b em strong pre code kbd sub sup details summary ul ol li table tr td th a figure section article header footer nav main aside blockquote label input button select option textarea form iframe video audio source template slot picture object canvas g line circle rect polygon polyline ellipse defs text tspan font viewbox desc metadata annotation math semantics mrow mi mn mo msub msup mfrac msqrt foreignobject annotation-xml xlink noembed fence tbody thead caption col colgroup tfoot marker mask filter pattern symbol clippath lineargradient radialgradient stop use""".split())
# 位点 = 22 条语义原则（上一轮定的，作为基因位点集）
LOCI=['身份与角色锚定','环境与可及边界','输出格式规范','语气与文风','语言本地化','引用与来源',
      '工具调用纪律','规划与任务分解','自主性与持续推进','权限与升级请求','上下文与记忆','代码与工程操作',
      '多模态与视觉','网络与检索','拒答与安全策略','危险类别枚举','未成年人保护','隐私与数据',
      '诚实与不确定性','错误与能力边界','中立与平衡','专业免责声明','注入防御与不可信输入']
KW={b:[k for k in kw] for b,kw in {
 '身份与角色锚定':['identity','persona','you are','core identity','agent identity','model identity','introduction','system capability','who you are','about you','agent loop'],
 '环境与可及边界':['environment','sandbox','disk space','working with the user','workspace','runtime','available tools','tool list'],
 '输出格式规范':['output format','response format','formatting rules','format','structure','template','markdown','code block','response_requirements','writing rules','message rules'],
 '语气与文风':['style','tone','writing style','communication','personality','voice','wording','brevity','concise','response quality','technical communication','intermediate commentary','final answer','verbosity'],
 '语言本地化':['language','locale','respond in','translat','multilingual','language settings'],
 '引用与来源':['citation','cite','source','reference','attribution','grounding','citations instructions'],
 '工具调用纪律':['tool','tools','toolkit','function','mcp','tool calling','tool use','tool usage','function call'],
 '规划与任务分解':['plan','planning','task','step','checklist','phase','todo','task process','proposed_plan','workflow','reasoning command'],
 '自主性与持续推进':['autonomy','autonomous','persist','proactive','keep working','complete','initiative','follow-up','approach to work','proactivity'],
 '权限与升级请求':['permission','approval','escalation','confirm','ask the user','request_user_input','consent','authorized','requires_approval','security policy','risk'],
 '上下文与记忆':['context','memory','conversation history','session','compact','summary','instruction priority','instruction source','memory system','context management'],
 '代码与工程操作':['code','edit','file','repository','git','test','debug','refactor','build','lint','terminal','shell','command','coding','codebase','file editing constraints','making code changes'],
 '多模态与视觉':['image','screenshot','visual','diagram','chart','render','canvas','artifact','media'],
 '网络与检索':['search','web','browse','fetch','internet','retrieval','web search'],
 '拒答与安全策略':['safety','policy','harmful','prohibit','refusal','restrict','guardrail','security','ethics','banned','not to do','prohibited','response limitations'],
 '危险类别枚举':['self-harm','suicide','weapon','explosive','csam','terrorism','drug','malware','cyberattack','biological','violence','hate'],
 '未成年人保护':['minor','children','child safety','underage','child'],
 '隐私与数据':['privacy','personal data','pii','confidential','sensitive','do not share','proprietary','data security','information handling','copyright'],
 '诚实与不确定性':['honest','truth','uncertain','hallucination','confidence','acknowledge','accurate','truthful','transparent','knowledge cutoff'],
 '错误与能力边界':['error','limit','limitation','edge case','failure','unavailable','troubleshoot','what you can','limitations'],
 '中立与平衡':['balanced','both sides','neutral','unbiased','political','perspective','avoid bias','evenhandedness','fairness'],
 '专业免责声明':['disclaimer','not a substitute','not a doctor','not a lawyer','financial advice','legal advice','medical advice'],
 '注入防御与不可信输入':['injection','untrusted','ignore previous','disregard','jailbreak','prompt attack','instruction source boundary','external content','malicious','treat as data'],
}.items()}
RX={b:re.compile(r'(?<![a-z0-9])(?:'+'|'.join(re.escape(k) for k in kw)+r')(?![a-z0-9])') for b,kw in KW.items()}
def read(p): return open(p,encoding='utf-8',errors='replace').read()
def loci_of(text):
    """返回 [(桶, 位置, 证据)] 按出现顺序"""
    out=[]
    for i,l in enumerate(text.splitlines()):
        m=re.match(r'^#{1,6}\s+(.+)$',l)
        cand=None; kind='head'
        if m: cand=m.group(1).lower()
        else:
            for tm in re.finditer(r'<([a-z][a-z0-9_]{2,40})[ />]',l):
                tag=tm.group(1).lower()
                if tag in HTMLISH: continue
                cand=tag.replace('_',' '); kind='tag'; break
        if not cand: continue
        for b,rx in RX.items():
            if rx.search(cand): out.append((b,i,kind,cand[:60])); break
    # 连续同桶折叠
    ded=[]
    for r in out:
        if ded and ded[-1][0]==r[0]: continue
        ded.append(r)
    return ded
vendors=collections.defaultdict(list)
for d,_,fs in os.walk(ROOT):
    v=os.path.basename(d)
    if v=='CL4R1T4S-main': continue
    if v=='Codex_Desktop': v='OPENAI'
    for f in fs:
        if f=='LICENSE': continue
        vendors[v].append(os.path.join(d,f))
# 每文件：结构序列 + 内容级位点集合
files={}
for v,fs in vendors.items():
    for p in fs:
        t=read(p); rel=os.path.relpath(p,ROOT)
        seq=loci_of(t)
        content=set(b for b,rx in RX.items() if rx.search(t.lower()))
        files[rel]={'vendor':v,'seq':[b for b,_,_,_ in seq],'detail':[{'locus':b,'line':i+1,'kind':k,'text':c} for b,i,k,c in seq],
                    'content':sorted(content),'size':len(t)}
json.dump(files,open(os.path.join(DATA_DIR, 'loci_files.json'),'w'),ensure_ascii=False)
# 每厂商代表基因组 = 结构位点最多的文件（并列取最大）
rep={}
for v,fs in vendors.items():
    best=max((f for f in map(lambda p: os.path.relpath(p,ROOT),fs)), key=lambda r:(len(files[r]['seq']),files[r]['size']))
    rep[v]=best
print("="*100); print("每厂商的代表基因组（结构位点最多的那份提示词）"); print("="*100)
for v in sorted(rep,key=lambda x:-len(files[rep[x]]['seq'])):
    f=files[rep[v]]
    print(f"  {v:<12} {len(f['seq']):>2}位点  {f['size']/1024:>6.0f}KB  {rep[v]}")
json.dump(rep,open(os.path.join(DATA_DIR, 'rep.json'),'w'),ensure_ascii=False)
