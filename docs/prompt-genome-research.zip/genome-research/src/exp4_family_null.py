#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E4：上一轮的家族聚类是真的，还是「覆盖广度大小效应」造出来的伪结构？

核心怀疑：存在集 Jaccard 的期望值只取决于「集合大小」与「宇宙大小」，
            与「共享了哪些位点」几乎无关 ⇒ 按它聚类 = 按「谁写得全」聚类。
验三件事：
  (1) 上一轮 D 矩阵与「覆盖广度」的相关性
  (2) D 的 null 对照（打乱厂商标签，保留边际）
  (3) 换用「只算高支持位点」的重叠后，结构是否恢复（并配 null 树）
"""
import json, collections, itertools, random, math, os

RD = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding="utf-8"))
LOCI = RD["LOCI"]
G = RD["genome"]
D = RD["D"]
V = sorted(G.keys())
random.seed(20261118)

def jac(a, b):
    u = len(a | b)
    return len(a & b) / u if u else 0.0

sets = {v: {d for d in LOCI if G[v].get(d, "absent") != "absent"} for v in V}
sizes = {v: len(sets[v]) for v in V}
print(f"厂商 {len(V)} 家，位点 {len(LOCI)} 个")
print("覆盖广度（present 维度数）：", dict(sorted(sizes.items(), key=lambda x: -x[1])))

# ---------- (1) D 与覆盖广度的关系 ----------
pairs = [(a, b, D[a][b]) for a, b in itertools.combinations(V, 2)]
def pearson(x, y):
    n = len(x); mx, my = sum(x)/n, sum(y)/n
    num = sum((x[i]-mx)*(y[i]-my) for i in range(n))
    den = math.sqrt(sum((x[i]-mx)**2 for i in range(n))*sum((y[i]-my)**2 for i in range(n)))
    return num/den if den else 0.0
def spearman(x, y):
    def rk(a):
        idx = sorted(range(len(a)), key=lambda i: a[i]); r=[0.0]*len(a); i=0
        while i < len(idx):
            j=i
            while j+1 < len(idx) and a[idx[j+1]] == a[idx[i]]: j+=1
            avg=(i+j)/2+1
            for k in range(i,j+1): r[idx[k]]=avg
            i=j+1
        return r
    rx, ry = rk(x), rk(y); n=len(x); mx,my=sum(rx)/n,sum(ry)/n
    num=sum((rx[i]-mx)*(ry[i]-my) for i in range(n))
    den=math.sqrt(sum((rx[i]-mx)**2 for i in range(n))*sum((ry[i]-my)**2 for i in range(n)))
    return num/den if den else 0.0

size_prod = [sizes[a]*sizes[b] for a, b, _ in pairs]
size_min  = [min(sizes[a], sizes[b]) for a, b, _ in pairs]
dv = [d for _, _, d in pairs]
print(f"\n=== (1) D（存在集 Jaccard）与覆盖广度的关系 ===")
print(f"  Spearman ρ(D, |A|·|B|)  = {spearman(dv, size_prod):+.3f}")
print(f"  Spearman ρ(D, min|A|,|B|) = {spearman(dv, size_min):+.3f}")
print(f"  Pearson  r(D, |A|·|B|)  = {pearson(dv, size_prod):+.3f}")
# 纯解析预期
U = len(LOCI)
exp_j = [(sizes[a]*sizes[b]/U) / (sizes[a]+sizes[b]-sizes[a]*sizes[b]/U) for a, b, _ in pairs]
print(f"  Spearman ρ(D, 解析期望 J) = {spearman(dv, exp_j):+.3f}   ← 越接近 1，说明 D 几乎就是「大小决定」")
print(f"  解析期望 J 的范围：{min(exp_j):.3f} ~ {max(exp_j):.3f}（实测 D：{min(dv):.3f} ~ {max(dv):.3f}）")

# ---------- (2) D 的 null 对照 ----------
nulls = []
for _ in range(400):
    perm = V[:]; random.shuffle(perm)
    s2 = {v: sets[perm[i]] for i, v in enumerate(V)}
    nulls.append(sum(jac(s2[a], s2[b]) for a, b, _ in pairs)/len(pairs))
nulls.sort()
obs = sum(dv)/len(pairs)
p = sum(1 for n in nulls if n >= obs)/len(nulls)
print(f"\n=== (2) null 对照（打乱厂商标签 400 次） ===")
print(f"  实测平均 D = {obs:.4f}   null 中位 = {nulls[len(nulls)//2]:.4f}   "
      f"null 95 分位 = {nulls[int(.95*len(nulls))]:.4f}   p = {p:.3f}")
print(f"  ⇒ 实测 {'高于' if obs > nulls[int(.95*len(nulls))] else '不高于'} null 95 分位")

# ---------- (3) 只算高支持位点的重叠 ----------
print("\n=== (3) 限制在高支持位点上重新度量 ===")
support = collections.Counter()
for v in V:
    for d in sets[v]: support[d] += 1
for thr in (3, 5, 8, 10, 12):
    core = {d for d in LOCI if support[d] >= thr}
    if not core: continue
    js = []
    for a, b in itertools.combinations(V, 2):
        A = sets[a] & core; B = sets[b] & core
        js.append(jac(A, B))
    nulls2 = []
    for _ in range(200):
        perm = V[:]; random.shuffle(perm)
        s2 = {v: (sets[perm[i]] & core) for i, v in enumerate(V)}
        nulls2.append(sum(jac(s2[a], s2[b]) for a, b, _ in pairs)/len(js))
    nulls2.sort()
    obs2 = sum(js)/len(js)
    p2 = sum(1 for n in nulls2 if n >= obs2)/len(nulls2)
    print(f"  支持度≥{thr:>2} 的位点 {len(core):>2} 个：实测平均 J = {obs2:.4f}  "
          f"null 中位 = {nulls2[len(nulls2)//2]:.4f}  p = {p2:.3f}"
          f"{'   ★ 超基线' if p2 <= 0.05 else ''}")

# ---------- (4) 位点支持度曲线 ----------
print("\n=== (4) 23 个位点的跨厂商支持度（这才是可对齐性的直接度量） ===")
rows = sorted(((support[d], d) for d in LOCI), reverse=True)
for s, d in rows:
    have = [v for v in V if d in sets[v]]
    print(f"  {s:>2}/{len(V)} 家  {d:<16} {', '.join(have[:8])}{' …' if len(have) > 8 else ''}")

# ---------- (5) 用「支持度画像」重做厂商相似度，看是否还有家族结构 ----------
print("\n=== (5) 换一种相似度：只看「谁有、谁没有」的模式向量（忽略位点身份） ===")
# 每个厂商一个 23 维 0/1 向量 → 用余弦（仍带大小） vs 用「支持度加权 Jaccard」
def cos(a, b):
    dot = len(sets[a] & sets[b]); na = math.sqrt(len(sets[a])); nb = math.sqrt(len(sets[b]))
    return dot/(na*nb) if na and nb else 0.0
cs = [cos(sets[a], sets[b]) for a, b, _ in pairs]
print(f"  余弦相似度均值 {sum(cs)/len(cs):.3f}   （与 D 的 Spearman ρ = {spearman(dv, cs):+.3f}）")
print("  ⇒ 若 ρ 高，说明上一轮的 D 与余弦几乎等价，聚类结果其实是在按覆盖广度分组。")

# 高支持子集上的余弦
core = {d for d in LOCI if support[d] >= 8}
cs2 = []
for a, b, _ in pairs:
    A = sets[a] & core; B = sets[b] & core
    dot = len(A & B); na = math.sqrt(len(A)); nb = math.sqrt(len(B))
    cs2.append(dot/(na*nb) if na and nb else 0.0)
print(f"  只用支持度≥8 的 {len(core)} 个位点：余弦均值 {sum(cs2)/len(cs2):.3f}  "
      f"与 D 的 Spearman ρ = {spearman(dv, cs2):+.3f}")
