#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GRL 可视化页自检：双视口 + 溢出 + 控制台 + 残留标记 + 结构深度。

沿用既有纪律：
  - 两个视口各测一次 scrollWidth vs clientWidth（只看桌面会漏）
  - 渲染后 innerText 不得出现 ** 与反引号
  - 结构深度逐 token 累加，断言任何时刻 depth>=0 且末尾 depth=0
    （只数总数会被「一处早开一处晚闭」骗过）
"""
import os
import sys
from playwright.sync_api import sync_playwright

PAGE = 'file://' + os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'figures', '05-grl-language', 'index.html')
FAILS = []


def rec(name, ok, detail=''):
    print('  [%s] %-34s %s' % ('PASS' if ok else 'FAIL', name, detail))
    if not ok:
        FAILS.append(name)


with sync_playwright() as pw:
    browser = pw.chromium.launch(args=['--no-sandbox'])
    for vw, vh in ((1440, 900), (390, 844)):
        ctx = browser.new_context(viewport={'width': vw, 'height': vh})
        page = ctx.new_page()
        errs, cons = [], []
        page.on('pageerror', lambda e: errs.append(str(e)))
        page.on('console', lambda m: cons.append('%s:%s' % (m.type, m.text)) if m.type in ('error', 'warning') else None)
        page.goto(PAGE)
        page.wait_for_timeout(500)

        m = page.evaluate("""() => ({
          sw: document.documentElement.scrollWidth,
          cw: document.documentElement.clientWidth,
          inner: document.body.innerText,
          bw: document.body.scrollWidth,
          bcw: document.body.clientWidth,
        })""")
        tag = '%dpx' % vw
        rec('%s 页面无横向溢出' % tag, m['sw'] <= m['cw'] + 1,
            'scrollWidth=%d clientWidth=%d' % (m['sw'], m['cw']))
        rec('%s body 无横向溢出' % tag, m['bw'] <= m['bcw'] + 1,
            'scrollWidth=%d clientWidth=%d' % (m['bw'], m['bcw']))
        rec('%s 无 pageerror' % tag, not errs, str(errs[:2]))
        rec('%s 控制台干净' % tag, not cons, str(cons[:2]))
        rec('%s 渲染后无 ** 残留' % tag, '**' not in m['inner'],
            '出现次数=%d' % m['inner'].count('**'))
        rec('%s 渲染后无反引号残留' % tag, '`' not in m['inner'],
            '出现次数=%d' % m['inner'].count('`'))

        depth = page.evaluate("""() => {
          const toks = document.body.innerHTML.match(/<\\/?div\\b[^>]*>/gi) || [];
          let d = 0, min = 0;
          for (const t of toks) {
            if (t[1] === '/') d--; else d++;
            if (d < min) min = d;
          }
          return {final: d, min: min, n: toks.length};
        }""")
        rec('%s div 深度配平' % tag, depth['final'] == 0 and depth['min'] >= 0,
            'final=%d min=%d n=%d' % (depth['final'], depth['min'], depth['n']))

        need = ['VERDICT: PASS', '5526', '68.2%', 'L2', '18/18', '基因规约语']
        miss = [x for x in need if x not in m['inner']]
        rec('%s 关键内容齐全' % tag, not miss, '缺：%s' % (miss or '无'))

        ncards = page.evaluate("document.querySelectorAll('.card').length")
        nrows = page.evaluate("document.querySelectorAll('tbody tr').length")
        rec('%s 组件数量正常' % tag, ncards >= 12 and nrows >= 10,
            'card=%d rows=%d' % (ncards, nrows))
        ctx.close()
    browser.close()

print()
if FAILS:
    print('VERDICT: FAIL（失败项：%s）' % FAILS)
    sys.exit(1)
print('VERDICT: PASS（双视口全部通过）')
