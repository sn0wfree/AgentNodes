# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
import os,re,json,collections,math,itertools,statistics
exec(open(os.path.join(HERE,'genome_lib.py')).read())
ROOT=os.environ.get('CL4R1T4S_DIR') or os.path.join(ROOT_DIR,'CL4R1T4S-main')
F=json.load(open(os.path.join(DATA_DIR, 'loci_files.json'))); REP=json.load(open(os.path.join(DATA_DIR, 'rep.json')))
G=json.load(open(os.path.join(DATA_DIR, 'genome.json')))
V=sorted(REP)
for rel,d in F.items():
    seen=[]
    for b in d['seq']:
        if b not in seen: seen.append(b)
    d['order']=seen
# ── Tier 归属（我的翻译，判据见报告 §2）──
T0=['拒答与安全策略','危险类别枚举','未成年人保护','隐私与数据','注入防御与不可信输入']
T2=['自主性与持续推进','权限与升级请求']
T1=[b for b in LOCI if b not in T0 and b not in T2]
# ── 顺序：Tier0 带 → Tier1 带（数据驱动共识序）→ Tier2 带 ──
cons=G['core']; weak=G['weak']
t1ord=[b for b in cons+weak if b in T1]
ORDER=T0+t1ord+T2
assert sorted(ORDER)==sorted(LOCI), set(LOCI)^set(ORDER)
AL={'struct':'█','content':'▄','absent':'·'}
seqs={};allele={}
for v in V:
    d=F[REP[v]]; so=set(d['order']); co=set(d['content'])
    allele[v]={b:('struct' if b in so else 'content' if b in co else 'absent') for b in LOCI}
    seqs[v]=''.join(AL[allele[v][b]] for b in ORDER)
# ── 强制构造审计（精确短语，文件级）──
PHR={'最高优先':['highest priority','highest-priority'],
     '指令源边界':['only from the user','valid instructions','instruction source'],
     '数据非命令':['data, not commands','not commands','treat as data','as data, not'],
     '无条件例外':['regardless of','under no circumstances','no exceptions','even if the user'],
     '硬禁止':['must never','MUST NOT','never reveal','shall not','cannot be overridden','inviolable']}
ENF={}
for v in V:
    t=open(os.path.join(ROOT,REP[v]),encoding='utf-8',errors='replace').read().lower()
    hits={k:sum(t.count(p.lower()) for p in ps) for k,ps in PHR.items()}
    ENF[v]={k:n for k,n in hits.items() if n>0}
    ENF[v]['_any']=int(len(ENF[v])>0)
    ENF[v]['_total']=sum(n for k,n in ENF[v].items() if k!='_any')
# ── 统计：保守度 / 多态 / 距离 / 聚类 ──
consv={};divs={};alld={}
for b in LOCI:
    c=collections.Counter(seqs[v][ORDER.index(b)] for v in V); n=len(V)
    alld[b]=dict(c); consv[b]=c.most_common(1)[0][1]/n
    divs[b]=-(sum((x/n)*math.log(x/n) for x in c.values() if x))
W={('█','▄'):1,('█','·'):1,('▄','·'):0.5}
def wm(a,b): return sum(W.get((x,y),W.get((y,x),0)) for x,y in zip(a,b))/len(ORDER)
D={a:{b:wm(seqs[a],seqs[b]) for b in V} for a in V}
def cluster(D):
    act={v:{v} for v in D}; cd={a:{b:D[a][b] for b in D if a!=b} for a in D}
    while len(act)>1:
        best=None
        for a,b in itertools.combinations(sorted(act),2):
            val=sum(D[x][y] for x in act[a] for y in act[b])/(len(act[a])*len(act[b]))
            if best is None or val<best[0]: best=(val,a,b)
        _,a,b=best; na,nb_=act[a],act[b]
        for o in list(act):
            if o in (a,b): continue
            cd[a][o]=sum(D[x][y] for x in na for y in act[o])/(len(na)*len(act[o])); cd[o][a]=cd[a][o]
        cd[a][a]=0; act[a]=na|nb_; del act[b]; del cd[b]
    return [sorted(c) for c in act.values()]
CL=cluster(D)
# ── 不变量带缺位审计 ──
INV={}
for b in T0:
    have_struct=[v for v in V if allele[v][b]=='struct']
    have_content=[v for v in V if allele[v][b]=='content']
    INV[b]={'struct':have_struct,'content':have_content,'absent':[v for v in V if allele[v][b]=='absent'],
           'n_struct':len(have_struct),'n_any':len(have_struct)+len(have_content)}
# ── 新颖性门：全局唯一组合 ──
uniq=[]
for b in LOCI:
    for v in V:
        s=allele[v][b]
        if s=='absent': continue
        others=[u for u in V if u!=v and allele[u][b]==s]
        if not others: uniq.append((v,b,s))
# ── 位点共现（模块）与移植优先级 ──
CO=collections.Counter()
for v in V:
    st=[b for b in LOCI if allele[v][b]=='struct']
    for a,b in itertools.combinations(st,2): CO[(a,b)]+=1
def jacc(a,b):
    A={b for b in LOCI if allele[a][b]!='absent'}; B={b for b in LOCI if allele[b][b_]!='absent'} if False else {x for x in LOCI if allele[b][x]!='absent'}
    return len(A&B)/len(A|B)
PRIO=[]
for b in LOCI:
    st=[v for v in V if allele[v][b]=='struct']
    ab=[v for v in V if allele[v][b]=='absent']
    co=max([CO[(b,x)] for x in LOCI if x!=b and CO[(b,x)]] or [0])
    PRIO.append({'locus':b,'tier':'T0' if b in T0 else ('T2' if b in T2 else 'T1'),
                 'n_struct':len(st),'n_absent':len(ab),'impl':st,'gap':ab,
                 'coverage':consv[b],'priority':len(ab)*(len(st)),'max_cooccur':co})
PRIO.sort(key=lambda x:-x['priority'])
# ── 强制构造样本 ──
def quote(v,b,n=1):
    t=open(os.path.join(ROOT,REP[v]),encoding='utf-8',errors='replace').read().splitlines()
    rx=RX[b]; out=[]
    for i,ln in enumerate(t,1):
        s=ln.strip()
        if s and rx.search(s.lower()) and len(s)>40: out.append((i,s[:300]))
        if len(out)>=n: break
    return out
ANCH={}
for b in T0:
    ANCH[b]={v:quote(v,b,1) for v in INV[b]['struct'][:6]}
json.dump({'LOCI':LOCI,'T0':T0,'T1':T1,'T2':T2,'ORDER':ORDER,'seqs':seqs,'allele':allele,
           'consv':consv,'divs':divs,'alld':alld,'D':D,'clusters':CL,'INV':INV,'ENF':ENF,
           'uniq':uniq,'PRIO':PRIO,'rep':REP,'anchors':ANCH,'core':G['core'],'weak':G['weak'],
           'cooccur':{f"{a}||{b}":n for (a,b),n in CO.items()}},
          open(os.path.join(DATA_DIR, 'final_genome.json'),'w'),ensure_ascii=False)
print("="*104); print(f"粗序列（{len(ORDER)} 位点）｜█独立成节 ▄仅正文 ·缺位｜三带：Tier0不变量 {len(T0)} + Tier1行为工件 {len(T1)} + Tier2自调 {len(T2)}"); print("="*104)
print("  "+" "*13+"".join(str(i%10) for i in range(len(ORDER)))+"    带")
for i,b in enumerate(ORDER):
    pass
band=[('T0' if b in T0 else 'T1' if b in T1 else 'T2') for b in ORDER]
for v in sorted(V,key=lambda x:sum(1 for b in ORDER if allele[x][b]!='absent'),reverse=True):
    print(f"  {v:<12}{seqs[v]}  "+"".join({'T0':'0','T1':'1','T2':'2'}[band[ORDER.index(b)]] for b in ORDER))
print("\n位点顺序：")
for i,(b,bd) in enumerate(zip(ORDER,band),1): print(f"  {i:>2}. [{bd}] {b}")
print("\n"+"="*104); print("Tier 0 不变量带缺位审计"); print("="*104)
for b in T0:
    i=INV[b]; print(f"\n  【{b}】 独立成节 {i['n_struct']}/26 ｜ 仅正文 {len(i['content'])}/26 ｜ 缺位 {len(i['absent'])}/26")
    print(f"     成节: {', '.join(i['struct']) if i['struct'] else '（无）'}")
    print(f"     缺位: {', '.join(i['absent'])}")
print("\n"+"="*104); print("强制构造审计（文件级，精确短语）"); print("="*104)
for v in V:
    e=ENF[v]; print(f"  {v:<12} {'强制结构命中 '+str(e['_total'])+' 次' if e['_any'] else '无强制构造':<16} {({k:n for k,n in e.items() if not k.startswith('_')})}")
print("\n"+"="*104); print("移植优先级（提案池排序：缺口×已有实现）"); print("="*104)
for p in PRIO[:12]:
    print(f"  [{p['tier']}] {p['locus']:<22} 成节{p['n_struct']:>2}家 缺位{p['n_absent']:>2}家 优先级分 {p['priority']:>3}  实现方: {', '.join(p['impl'][:8])}{'…' if len(p['impl'])>8 else ''}")
print("\n"+"="*104); print("家族聚类"); print("="*104)
for i,c in enumerate(sorted(CL,key=len,reverse=True),1):
    sd=statistics.mean([sum(1 for b in ORDER if allele[v][b]=='struct')/max(1,sum(1 for b in ORDER if allele[v][b]!='absent')) for v in c])
    print(f"  F{i} (n={len(c)}, 结构化密度{sd:.2f}): "+", ".join(c))
print("\n唯一组合（新颖性候选）：",len(uniq))
for v,b,s in uniq[:20]: print(f"   {v} / {b} / {s}")
