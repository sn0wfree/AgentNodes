#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E6：编码「存在性」还是编码「等位」？

存在性编码（上一轮粗序列）：每家每维一个 0/1/强度档
等位编码（本轮）：每家每维取该维条款上的具体属性（显式模态率、条件率、动作集合…）

判据：厂商两两相似度的**分布方差**是否超过 null（打乱厂商标签）。
上一轮已证明「存在性 Jaccard」的方差 96% 由集合大小决定 ⇒ 无结构。
这里测等位编码能否突破。
"""
import os
import json, glob, os, re, collections, itertools, random, math

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')
RD = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding="utf-8"))
from genome_lib import LOCI, RX
random.seed(20261118)

def dim_hits(text):
    t = text.lower()
    return {d for d in LOCI if RX[d].search(t)}

# 载入
clauses = collections.defaultdict(list)   # vendor -> list of clause dict
for f in sorted(glob.glob(os.path.join(ROOT, "*", "*.json"))):
    v = os.path.basename(os.path.dirname(f))
    for it in json.load(open(f, encoding="utf-8")):
        rc = it.get("regulative_components") or {}
        txt = (it.get("full_statement") or "") + " " + (it.get("anchor") or "")
        clauses[v].append({
            "class": it.get("class"),
            "D": (rc.get("D") or "").strip().lower(),
            "C": (rc.get("C") or "").strip(),
            "I": (rc.get("I") or "").strip().lower(),
            "B": (rc.get("B") or "").strip().lower(),
            "stmt": txt,
            "dims": dim_hits(txt),
        })
V = sorted(clauses)
print(f"厂商 {len(V)} 家，条款 {sum(len(c) for c in clauses.values())} 条\n")

# ---- 每家每维的「等位特征」 ----
def profile(v):
    """23 维 × 4 个等位特征"""
    by = {d: [] for d in LOCI}
    for it in clauses[v]:
        for d in it["dims"]:
            by[d].append(it)
    P = {}
    for d in LOCI:
        cs = by[d]
        n = len(cs)
        if n == 0:
            P[d] = (0.0, 0.0, 0.0, 0.0); continue
        reg = [c for c in cs if c["class"] == "regulative"]
        expl = sum(1 for c in reg if c["D"]) / max(1, len(reg))
        cond = sum(1 for c in cs if c["C"]) / n
        ndist = len({c["I"] for c in cs if c["I"]}) / n      # 动作多样性
        ln = sum(len(c["stmt"].split()) for c in cs) / n     # 平均条款长度
        P[d] = (expl, cond, ndist, ln)
    return P

PROF = {v: profile(v) for v in V}

def feat_vec(v, keys):
    """把 23 维展平成向量（缺位=0）"""
    out = []
    for d in LOCI:
        for k in keys:
            out.append(PROF[v][d][k])
    return out

def cos_dist(x, y):
    dot = sum(a*b for a, b in zip(x, y))
    nx = math.sqrt(sum(a*a for a in x)); ny = math.sqrt(sum(b*b for b in y))
    if nx == 0 or ny == 0: return 1.0
    return 1 - dot/(nx*ny)

def var(vals):
    m = sum(vals)/len(vals); return sum((x-m)**2 for x in vals)/len(vals)

def null_test(dist_fn, label, rounds=300):
    obs = [dist_fn(a, b) for a, b in itertools.combinations(V, 2)]
    nv = []
    for _ in range(rounds):
        perm = V[:]; random.shuffle(perm)
        nv.append(var([dist_fn(perm[i], perm[j])
                       for i in range(len(V)) for j in range(i+1, len(V))]))
    nv.sort()
    o = var(obs)
    p = sum(1 for x in nv if x >= o)/rounds
    print(f"  {label:<46} 实测方差 {o:.6f}  null 中位 {nv[len(nv)//2]:.6f}  "
          f"null95 {nv[int(.95*rounds)]:.6f}  p={p:.3f}"
          f"{'   ★ 超基线' if p <= 0.05 else ''}")
    return o, p

print("=== A. 存在性编码（上一轮口径） ===")
def jac(a, b):
    u = len(a | b); return len(a & b)/u if u else 0.0
sets = {v: {d for d in LOCI if RD["genome"].get(v, {}).get(d, "absent") != "absent"} for v in V}
def d_exist(a, b): return 1 - jac(sets[a], sets[b])
null_test(d_exist, "存在性 Jaccard 距离（26→15 家子集）")

print("\n=== B. 等位编码（每维的 4 个属性） ===")
KEYS = [(0,), (1,), (2,), (3,), (0, 1), (0, 1, 2), (0, 1, 2, 3)]
FN = {0: "显式模态率", 1: "条件率", 2: "动作多样性", 3: "平均条款长度"}
FV = {k: {v: feat_vec(v, k) for v in V} for k in KEYS}
for k in KEYS:
    lbl = "＋".join(FN[i] for i in k)
    null_test(lambda a, b, k=k: cos_dist(FV[k][a], FV[k][b]), f"余弦距离 · {lbl}")

print("\n=== C. 等位编码 + 存在性 联合 ===")
def d_joint(a, b):
    x = cos_dist(FV[(0,1,2)][a], FV[(0,1,2)][b])
    y = 1 - jac(sets[a], sets[b])
    return 0.5*x + 0.5*y
null_test(d_joint, "0.5×等位余弦 + 0.5×存在性 Jaccard")

print("\n=== D. 分维度看：哪些维度的等位特征最有区分力 ===")
print("  （每维单独算 15 家两两余弦距离的方差，与 null 比）")
rows = []
for d in LOCI:
    vec = {v: PROF[v][d] for v in V}
    def f(a, b, vec=vec):
        x, y = vec[a], vec[b]
        if max(x) == 0 and max(y) == 0: return 1.0
        return cos_dist(list(x), list(y))
    obs = [f(a, b) for a, b in itertools.combinations(V, 2)]
    nv = []
    for _ in range(120):
        perm = V[:]; random.shuffle(perm)
        nv.append(var([f(perm[i], perm[j]) for i in range(len(V)) for j in range(i+1, len(V))]))
    nv.sort(); o = var(obs); p = sum(1 for x in nv if x >= o)/120
    rows.append((o, p, d, len([v for v in V if max(PROF[v][d]) > 0])))
rows.sort(reverse=True)
for o, p, d, nv_ in rows:
    star = " ★" if p <= 0.05 else ""
    print(f"    方差 {o:.6f}  p={p:.3f}{star:<4} {d:<16} 有该维的厂商 {nv_}/{len(V)}")
