#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成《提示词基因框架 · 业界先例调研》可视化页。
数据与文案集中在 PROJ / PERIPH / DECISIONS / REUSE / BUILD / CHECKS，输出单文件 HTML。"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
import html, json, os

OUT = "figures/04-literature-map/index.html"

# ---------------------------------------------------------------- 数据
# id, 名称, 年份, url, 一句话, 对应子问题 {P1..P5: 0/1/2(部分)}, 可信度, 类型标签
PROJ = [
    ("phenome", "phenome", "2026-05 · HF Space",
     "https://huggingface.co/blog/nyxia/genetics-instead-of-system-prompts-for-ai-agents",
     "64 个手写 trait loci × 251 等位 × 4 档强度，压成 120 字符（约 110 token）基因组，替代 3–5k token 的 system prompt",
     {"P1": 0, "P2": 0, "P3": 2, "P4": 0, "P5": 0}, "已核实（读到 prompt.py 源码）", "基因编码"),
    ("DelvePO", "DelvePO", "2025-10 · arXiv 2510.18257",
     "https://arxiv.org/abs/2510.18257",
     "★ 明写 Loci / Alleles：prompt 拆成带 HTML tag 的功能组件，组件＝loci、组件内取值＝alleles；双记忆（Component Memory 逐 locus 记胜负等位）",
     {"P1": 1, "P2": 0, "P3": 2, "P4": 0, "P5": 0}, "已核实（正文）", "离散基因型"),
    ("PromptGenome", "PromptGenome", "2026-10 · arXiv 2611.01135",
     "https://arxiv.org/abs/2611.01135",
     "★ 目前最完整：组件型 genome（role / constraints / reasoning directives / few-shot / output directives / verification hooks）；GenomeMutator 选一个 locus 换值；AutoAPC-Select 部署门",
     {"P1": 1, "P2": 0, "P3": 2, "P4": 0, "P5": 0}, "已核实（正文）", "离散基因型"),
    ("SEPO", "SEPO", "2026 · arXiv 2608.28067",
     "https://arxiv.org/abs/2608.28067",
     "两层 prompt schema + 稳定 typed units 的局部编辑；每次编辑绑定「修好 / 弄坏」的样本；14 任务宏平均比 GEPA +3.1pp",
     {"P1": 1, "P2": 0, "P3": 2, "P4": 0, "P5": 0}, "已核实（摘要 + 正文片段）", "离散基因型"),
    ("CFG-genotype", "Diverse Prompts（CFG）", "2025 · arXiv 2504.14367",
     "https://arxiv.org/abs/2504.14367",
     "上下文无关文法当 genotype（非终结符 P,S,E,I,C,T,R,X,N）；MAP-Elites 档案按 shots / 思考深度 / 长度等 trait 分箱",
     {"P1": 1, "P2": 0, "P3": 2, "P4": 0, "P5": 0}, "已核实（正文）", "离散基因型"),
    ("PhyloLM", "PhyloLM", "2024 · arXiv 2404.04671",
     "https://arxiv.org/abs/2404.04671",
     "★★ prompt 当 gene、模型输出 token 当 allele，算等位比例相似度 → NJ 树；用系统发育相似度预测基准分 r≈0.68。但树长在模型上，不是 prompt 上",
     {"P1": 0, "P2": 0, "P3": 1, "P4": 2, "P5": 2}, "已核实（摘要）", "对齐 / 建树"),
    ("REPROMPT", "REPROMPT", "2026 · arXiv 2601.16507",
     "https://arxiv.org/abs/2601.16507",
     "需求获取→分析→规格化→验证四阶段；把 system prompt 拆成固定 5 组件（Role Definition / Knowledge / Tool Spec / Context / Work Modes）",
     {"P1": 1, "P2": 0, "P3": 2, "P4": 0, "P5": 0}, "已核实（摘要 + 报告）", "离散基因型"),
    ("Prompt Genome", "Prompt Genome", "2026-08 · GitHub",
     "https://github.com/pisanuw/Claude-capstone/tree/main/prompt-genome",
     "单条 prompt 切成 7 类 typed gene，附 lint 0–100、每类 3 个确定性重写、词级 LCS diff、基因库",
     {"P1": 2, "P2": 0, "P3": 1, "P4": 0, "P5": 0}, "已核实（README 全文）", "条款切分"),
    ("PromptPrism", "PromptPrism", "2025-05 · arXiv 2505.12592",
     "https://arxiv.org/abs/2505.12592",
     "语言学三层分类（结构/语义/句法），三个应用：精修、数据集画像、敏感性分析。自述 taxonomy 是 top-down 手工设计，自动标注列为 future work",
     {"P1": 2, "P2": 0, "P3": 0, "P4": 1, "P5": 0}, "已核实", "分类学"),
    ("SPDeconstruction", "SystemPromptDeconstruction", "2025 · Polish Academy of Sciences",
     "https://github.com/mytkom/SystemPromptDeconstruction",
     "Institutional Grammar 拆原子陈述（constitutive/regulative），9 项指标 + SBERT/UMAP/层次聚类；已在同一份 CL4R1T4S 语料上跑完，产物 38 个 JSON / 15 厂商",
     {"P1": 2, "P2": 0, "P3": 0, "P4": 1, "P5": 1}, "已核实（已 clone 逐行读源码）", "同语料先例"),
    ("ARCCS", "ARCCS", "2026 · arXiv 2610.01345",
     "https://arxiv.org/abs/2610.01345",
     "★★★ 法规 → 层级分段 → 原子条款 typed tuple ⟨法律功能, 主体, 适用范围, 强制条件集 M_i, 原文指针⟩，并显式过滤纯定义/描述/上下文条款。GDPR 100 条，judge 一致率 90–96.67%、Fleiss κ=0.69",
     {"P1": 2, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实", "强制条款判定"),
    ("PromptSys", "PromptSys", "2025-11 · GitHub",
     "https://github.com/HotFazz/PromptSys",
     "★★ 12 类标签（instruction / context / constraint / example / role / objective / format / persona / guardrail / tool / workflow / uncategorized）+ 7 种关系（depends_on / conflicts_with / precedes …）+ 冲突检测（环/矛盾/重复/孤儿）",
     {"P1": 2, "P2": 0, "P3": 1, "P4": 0, "P5": 0}, "已核实（README）· 0★", "条款切分"),
    ("prompt-vc", "prompt-vc", "2026 · GitHub",
     "https://github.com/melidisc/prompt-vc",
     "★★★ sidecar *.prompt.meta.yaml：annotations[{anchor: sha256, preview, line_hint, author, date, source, rationale, tags}]；diff / annotate / audit / graph —— 最接近「基因位点」的现成件",
     {"P1": 1, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实（README）· 0★", "溯源 / 证据链"),
    ("Templates", "From Prompts to Templates", "2025 · arXiv 2504.02052",
     "https://arxiv.org/abs/2504.02052",
     "2163 个真实模板（1525 个 repo）标注出 7 类组件（Profile/Role · Directive · Context · Workflows · Output Format/Style · Constraints · Examples）+ 4 类 placeholder；Directive 覆盖 86.7%",
     {"P1": 2, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实", "条款切分"),
    ("PromptsWild", "Prompts in the Wild", "2026 · arXiv 2608.12905",
     "https://arxiv.org/abs/2608.12905",
     "57.5K 真实 prompt（GitHub 代码）+ 结构化本体（形式成分 + 语义成分）+ 全字段 error analysis 验证标注质量",
     {"P1": 1, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实", "条款切分"),
    ("UltraIF", "UltraIF", "2024 · arXiv 2410.15553",
     "https://arxiv.org/abs/2410.15553",
     "真实用户 prompt → query + constraints + constraint-evaluation questions 三段拆分；约束是自动抽出的自由文本（非离散标签）",
     {"P1": 1, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实", "条款切分"),
    ("sinc-LLM", "sinc-LLM", "2026 · GitHub",
     "https://github.com/mdalexandre/sinc-llm",
     "任意 raw prompt → 6 个 band（PERSONA / CONTEXT / DATA / CONSTRAINTS / FORMAT / TASK），输出 fragments[{n, t, x}]",
     {"P1": 2, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "仅摘要级", "条款切分"),
    ("CUAD", "CUAD", "2021 · arXiv 2103.06268",
     "https://arxiv.org/abs/2103.06268",
     "41 类人工条款类型标注范式（英文合同域）；配 ContractNLI / LexGLUE",
     {"P1": 1, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实", "条款切分"),
    ("llmon-tagger", "LLMON span tagger", "2026-11 · arXiv 2603.22519",
     "https://huggingface.co/ibm-research/llmon-span-tagger",
     "149M token 分类器，把 prompt 切成 instruction / constraint / data，能句中切（F1 77.7，句中边界召回 61.1%）",
     {"P1": 2, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实（模型卡）", "条款切分"),
    ("ConGrs", "ConGrs（COLM 2026）", "2026 · COLM",
     "https://lacuna.tiptreesystems.com/work/sample-align-synthesize-graph-based-response-synthesis",
     "把 Needleman–Wunsch 适配到词级，对同一模型多次采样做多重比对 → 共识/分歧 DAG",
     {"P1": 0, "P2": 0, "P3": 0, "P4": 2, "P5": 0}, "已核实（正文与消融）", "对齐算法"),
    ("PromptLint", "PromptLint", "2025 · PyPI",
     "https://github.com/fyunusa/promptlint",
     "Parser 把 prompt 拆成指令（ACTION/CONSTRAINT/FORMAT/META，带置信度）、变量、条件、示例、输出格式；三维打分 + diff",
     {"P1": 2, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实（README）", "条款切分"),
    ("TaxoAdapt", "TaxoAdapt", "2025 · arXiv 2506.10737",
     "https://arxiv.org/abs/2506.10737",
     "语料 → 多维 taxonomy：维度名人工给定（task / methodology / dataset / evaluation / domain），维度内节点全自动；5 项质量指标，人工一致率 70–90%",
     {"P1": 0, "P2": 2, "P3": 0, "P4": 0, "P5": 0}, "已核实", "维度发现"),
    ("APE", "Auto-Prompt Ensemble", "2025 · arXiv 2510.06538",
     "https://arxiv.org/abs/2510.06538",
     "★ 反向路径：从 judge 与人类冲突的失败案例长出候选维度 → 逐个验证 → 按覆盖率选 top-K；88→40→16 维；Reward Bench 87.2%→90.5%；维度数 >4 起涨、14–16 达峰",
     {"P1": 0, "P2": 2, "P3": 0, "P4": 0, "P5": 0}, "已核实", "维度发现"),
    ("EvalAgent", "EvalAgent", "2025 · arXiv 2504.15219",
     "https://arxiv.org/abs/2504.15219",
     "Query→Retrieve→Aggregate→Rank 四段管线，自动产出「prompt 里没说但人会在意」的隐式标准；自带维度质量四把尺 SS / II / AA / RR",
     {"P1": 0, "P2": 2, "P3": 0, "P4": 0, "P5": 0}, "已核实", "维度发现"),
    ("SurgDim", "外科反馈质量维度", "2026 · arXiv 2605.25440",
     "https://arxiv.org/abs/2605.25440",
     "多实例采样 + 合并 + 评分相似度聚类 → 6 个维度全自动；AUROC 0.71–0.75；维度间平均 |Spearman| 仅 0.26（≈正交）",
     {"P1": 0, "P2": 2, "P3": 0, "P4": 0, "P5": 0}, "已核实", "维度发现"),
    ("SAE-TM", "SAE-TM", "2026 · arXiv 2511.16309",
     "https://arxiv.org/abs/2511.16309",
     "★★ 把 SAE 目标推导为连续主题模型的 MAP 估计 ⇒ SAE feature 天然是 thematic atom，且可合并成任意数量主题而无需重训",
     {"P1": 0, "P2": 1, "P3": 0, "P4": 0, "P5": 0}, "已核实", "维度发现"),
    ("MDPI-dims", "LLM 无监督语义维度发现", "2026 · Mathematics 14(15):2681",
     "https://ideas.repec.org/a/gam/jmathe/v14y2026i15p2681-d1999085.html",
     "两段式无 schema 聚类：64,107 句 → 458 原始标签 → 22 概念；专家打分 4.64/5；但温度 0.3 下重复跑簇数最多差 15%",
     {"P1": 0, "P2": 2, "P3": 0, "P4": 0, "P5": 0}, "已核实（正文与附录提示词）", "维度发现"),
    ("MICoL", "MICoL", "2022 · arXiv 2202.05932",
     "https://arxiv.org/abs/2202.05932",
     "★★★ 零样本多标签分类：只需 label 名称 + 描述，无需标注数据，标签集可任意增删 —— 最干净的「位点取值器」",
     {"P1": 0, "P2": 0, "P3": 1, "P4": 0, "P5": 0}, "已核实", "取值器"),
    ("IFEval", "IFEval + AutoIF", "2023–2024 · arXiv 2311.07911 / 2406.13542",
     "https://arxiv.org/abs/2311.07911",
     "★★★ 「标签即校验器」范式：每个位点 = 一条 label description + 一个可执行 verifier；AutoIF 自动写验证函数 + 单测 + NLI 反向翻译 + 执行反馈拒绝采样",
     {"P1": 0, "P2": 0, "P3": 1, "P4": 0, "P5": 0}, "已核实", "取值器"),
    ("PatternTax", "Single-Turn Prompt Pattern Taxonomy", "2026-06 · arXiv 2607.00043",
     "https://arxiv.org/abs/2607.00043",
     "30 个 canonical prompt pattern、两个维度",
     {"P1": 0, "P2": 1, "P3": 0, "P4": 0, "P5": 0}, "仅摘要级", "人工维度集"),
    ("Dataset-survey", "Prompt 数据集综述", "2025-10 · arXiv 2510.09316",
     "https://arxiv.org/abs/2510.09316",
     "129 个数据集 / 1.22 TB / 673M 实例；63 维 CPU 可算语言学特征集；六 facet Cohen's κ 0.606–0.862",
     {"P1": 0, "P2": 1, "P3": 0, "P4": 0, "P5": 0}, "已核实", "数据集画像"),
    ("SysPrompt-Forge", "SysPrompt-Forge", "2026 · GitHub",
     "https://github.com/MilkyWay008/SysPrompt-Forge",
     "7 条设计维度（personality / tool-use / context / memory / planning / verbosity / proactiveness）+ 5 个行为原型 + counter-prompt",
     {"P1": 0, "P2": 0, "P3": 0, "P4": 0, "P5": 0}, "已核实（README 全文）", "人工维度集"),
    ("EoT", "进化式提示词优化（EoT）", "2023–2026 · ACL 2025 综述",
     "https://arxiv.org/abs/2502.18746",
     "PhaseEvo / EvoPrompt / GPS / Promptbreeder / ReflectivePrompt 等；genome = 种群表示，用于变异与交叉，不是比较编码",
     {"P1": 1, "P2": 0, "P3": 1, "P4": 0, "P5": 0}, "已核实（综述 + 条目）", "进化（搜索表示）"),
    ("Steering", "Cross-Architecture Steering", "2026-05 · arXiv 2608.05164",
     "https://arxiv.org/abs/2608.05164",
     "每模型一个 SAE + CCA 投影下互最近邻配对 + MLP bridge；≥1.7B 时 47–49% 特征对过阈；跨模型 steering 71.0% vs 同模型 68.0%（p=0.14 不显著）",
     {"P1": 0, "P2": 0, "P3": 0, "P4": 1, "P5": 0}, "已核实", "连续表征路线"),
    ("Crosscoders", "Crosscoders", "2024–2025 · 综述条目",
     "https://www.emergentmind.com/topics/crosscoders",
     "共享字典跨 checkpoint 对齐 + model diffing；必须用 BatchTopK，否则出「完全收缩」「latent 解耦」伪影",
     {"P1": 0, "P2": 0, "P3": 0, "P4": 1, "P5": 0}, "仅摘要级", "连续表征路线"),
]

# 周边四条线：不进 P1–P5 矩阵，单列
PERIPH = [
    ("防泄漏检测", "Cloudflare AI Gateway Guardrails",
     "代理层按类别码评分：S1–S14 = Llama Guard 3 危害类，P1 = Prompt Injection（prompt-guard-2-86m）；FLAG/BLOCK，错误码 2016/2017",
     "★ 没有 prompt leak 专用类别"),
    ("防泄漏检测", "Cloudflare AI Security for Apps",
     "注入打分 cf.llm.prompt.injection_score（1–99），文档明确覆盖 ignore instructions or reveal its system prompt",
     "泄漏只是注入分的一部分"),
    ("防泄漏检测", "Lakera Guard → Check Point AI Guardrails",
     "2025-09-16 宣布收购、10-22 交割；改名但 API 仍是 api.lakera.ai/v2/guard；社区版 $0 / 1 万请求/月",
     "仅摘要级；引用前确认还活着"),
    ("防泄漏检测", "protectai/llm-guard · NVIDIA/garak",
     "llm-guard 20+ scanner（GitHub 已标 archived，3,216★）；garak 红队扫描器（10,062★）",
     "llm-guard 已归档"),
    ("注入分类", "Greshake et al. 2302.12173",
     "indirect prompt injection 原始论文 + data theft / worming / information ecosystem contamination 三类影响",
     "分类法完整树未读全文"),
    ("注入分类", "OWASP LLM01:2025",
     "Direct / Indirect 两型，各自可 intentional / unintentional；jailbreaking 是子类",
     "—"),
    ("注入分类", "Instruction Hierarchy 2404.13208（Microsoft）",
     "显式指令优先级层级 system > user > tool；冲突时选择性忽略低优先级指令",
     "★ 2404.13213 是引力波论文，勿引"),
    ("版本 diff", "Langfuse / PromptLayer / Agenta",
     "主流平台全部是文本（或 unified）diff；Agenta 连 diff 视图都没有，只比较两个不可变 payload",
     "无位点级 diff"),
    ("版本 diff", "语义 diff 个人仓库",
     "PromptDiff 9★ / llm-prompt-semantic-diff 6★ / prompt-git 4★ / prompthub 1★",
     "语义 diff 只在 0–9★ 个人仓库"),
    ("护栏格式", "NeMo Guardrails · Colang 2.0",
     "flow 结构能表达作用域（flow input rails $input_text + if / abort 分支）",
     "★ 强度 / 模态字段完全缺失"),
    ("护栏格式", "Guardrails Hub",
     "没有统一的 policy 文件——每个 validator 一个 Python 包；parameters / metadata 是任意 dict，无 schema",
     "★ 三要素里只有 scope 勉强可表达"),
]

PKEYS = ["P1", "P2", "P3", "P4", "P5"]
PLAB = {
    "P1": "P1 条款级切分",
    "P2": "P2 位点集自动发现",
    "P3": "P3 离散编码",
    "P4": "P4 跨源对齐",
    "P5": "P5 家族聚类",
}

DECISIONS = [
    ("先跑编码层，再攻发现层",
     "P2 最上游也最不稳（MDPI 自报重复跑簇数差 15%）。先用 SystemPromptDeconstruction 已拆好的 38 个 JSON，把「schema → 取值 → 序列 → 对齐」整条链验证掉，维度自动发现放到最后。",
     "SPDeconstruction 产物 38 JSON / 15 厂商；MDPI 2026 稳定性自述"),
    ("离散基因型这条线，业界已经有人做了",
     "DelvePO 明写 Loci/Alleles、PromptGenome 有 locus 级变异器、SEPO 有 typed units、CFG 有 genotype、phenome 有 64 loci。★ 但它们全部把「位点集从哪来」当人工前提 —— 我们的位置在「让位点集也自动产生」。",
     "arXiv 2510.18257 / 2611.01135 / 2608.28067 / 2504.14367"),
    ("位点 schema 与取值器分离，schema 可版本化",
     "编码格式要有机器形态与人类可读形态两种，但只能有一位真源、只有一种需要逆解码——phenome 的四种编码里只有 alpha6 有逆解码，其余是 emit-only。",
     "phenome phenome/prompt.py 源码"),
    ("取值器走双通道：软取值 + 可执行校验器",
     "软通道用 MICoL 式零样本多标签（给「疑似 / 未识别」连续分数），硬通道用 IFEval 式 verifier（能形式化的位点必须有 checker）。只有软通道能表达「未识别」这个一等状态。",
     "arXiv 2202.05932 / 2311.07911 / 2406.13542"),
    ("「未识别」是取值器的一等状态",
     "不许把识别不出兜底成某个默认等位。Prompt Genome 自己把这条写在 README 里：怪句回退 context 并标「no strong signal」，逃生口是人工一键改类。",
     "Prompt Genome README 局限段"),
    ("对齐用互最近邻，不用全局 1:1",
     "Cross-Architecture Steering 第一版用 Hungarian 得到 68.4% 过阈率，作者复盘认定虚高（预选 top-K 抬高判据、无向池化掩盖规模断层）；换互最近邻后降到 45.5%，并写明「45.5% 是更诚实的估计」。",
     "arXiv 2608.05164 附录 O"),
    ("发现层必须带稳定性闸，闸不过就报失败",
     "重复跑 N 次，位点集 Jaccard 低于阈值即判定「发现失败」，而不是拿一个不稳定的结果当 schema 往下走。",
     "MDPI 2026 附录 C.4 确定性自述"),
    ("家族树必须配「打乱位点的 null 树」作负对照",
     "prompt 语料大量互相派生，「共享同一模板」会造出假家族。真实树必须显著优于 null 才敢报家族 —— 这一步业界没人做，但它是家族聚类能不能站住的前提。",
     "★ 本报告提出（无先例）"),
    ("模态 / 强度 / 作用域三字段自研，且是位点 schema 的一等公民",
     "Colang 2.0、Guardrails parameters、PromptSys、sinc-LLM —— 四套独立生态全都没有可枚举的强度与模态字段。这是全行业空白，我们必须自己定。",
     "§3.15(d) · NeMo / Guardrails / PromptSys / sinc-LLM 四处交叉"),
    ("维度集必须自查三件事：正交性、维度数曲线、质量四把尺",
     "正交性防「23 个维度是同一维度的 23 种说法」；维度数-收益曲线防拍脑袋（APE 给的形状是 >4 起涨、14–16 达峰、跨域需 >10）；质量尺用 EvalAgent 的 SS / II / AA / RR。",
     "arXiv 2605.25440 / 2510.06538 / 2504.15219"),
]

REUSE = [
    ("原子拆分提示词", "SystemPromptDeconstruction parsing_system_prompt.txt",
     "条款级抽取基线：verbatim + with-context 双字段 + 标题锚定", "是一个模型的一次输出，不是黄金标准"),
    ("IG 分类提示词", "SystemPromptDeconstruction classification_system_prompt.txt",
     "位点类型判据基线：3 步 litmus + 7 字段 + deontic 只认显式", "类型集仍是人工定义"),
    ("已拆好的 38 个 JSON", "同仓库 CL4R1T4S-no-code-processed-*/classification/",
     "立刻跑通编码层的捷径（15 厂商目录）", "由 gemini-flash-3.5 生成，有偏"),
    ("token 级 BIO 切分器", "LLMON span tagger",
     "规则式切分的对照基线，可直接跑", "英文限定 / 2048 静默截断 / 过切 +24% / 种子敏感 8.8pt"),
    ("Parser", "PromptLint promptlint/core/parser.py",
     "取值器的规则基线：4 类指令 + 变量 + 条件 + 示例 + 输出格式", "关键词表手写，兜底无处安放"),
    ("typed gene + lint + 3 重写 + LCS diff", "Prompt Genome src/core/",
     "变异算子与 diff 的完整实现", "只处理单条；7 类手写"),
    ("alpha6 稠密编码 + 三变体", "phenome phenome/prompt.py",
     "位点编码格式的设计范式", "只有一种该有逆解码"),
    ("NW 词级比对 + 共识/分歧二分", "ConGrs",
     "位点对齐算法原型（比对单位换成位点取值）", "依赖 anchor span；会丢有效事实"),
    ("两段式 LLM 无监督聚类", "MDPI Mathematics 2026",
     "自动发现维度集的算法原型", "簇数重复跑差 15%；兜底类内聚仅 36.9%"),
    ("7 轴设计维度 + 5 行为原型", "SysPrompt-Forge",
     "维度集的外部挑战集（用来挑战我们的先验）", "人工的、会过时"),
    ("Component Memory / Prompt Memory", "DelvePO",
     "逐 locus 记「哪些等位赢 / 输」——「某家在某位点的等位分布」的现成数据底座", "只服务优化，不做对齐"),
    ("GenomeMutator + AutoAPC-Select 部署门", "PromptGenome / arXiv 2611.01135",
     "变异算子 + 晋级门，几乎就是我们演化层的现成原型", "repo 无官方；论文参考文献匿名"),
    ("CFG genotype + MAP-Elites 档案", "Diverse Prompts / arXiv 2504.14367",
     "「离散基因型生成 + 描述子分箱档案 + 多样性度量」的现成骨架", "trait 是人工预定义"),
    ("NJ 建树管线", "PhyloLM / arXiv 2404.04671",
     "distance matrix → NJ dendrogram → 支撑度 → 性能预测，换掉距离定义即可整套复用", "repo 仅 18★；对象是模型"),
    ("typed-unit 局部编辑 + edit-effect lineage", "SEPO / arXiv 2608.28067",
     "把「改哪个槽位」绑定到「它修好了哪些样本」——可追溯的 fitness 归因", "—"),
    ("原子条款 typed tuple + 强制/叙述过滤", "ARCCS / arXiv 2610.01345",
     "位点 schema 形状：⟨语义类别, 主体/适用范围, 强制条件集 M_i, 原文指针⟩", "法律域；需 LLM judge；κ=0.69"),
    ("零样本多标签取值器", "MICoL / arXiv 2202.05932",
     "软通道取值：只需 label 名称 + 描述，标签集可任意增删", "依赖 label description 质量"),
    ("标签即校验器", "IFEval + AutoIF",
     "硬通道取值：每个可判定位点配一个可执行 verifier", "只能覆盖能形式化的维度"),
    ("维度质量四把尺", "EvalAgent / arXiv 2504.15219",
     "评测我们发现的维度质量（SS / II / AA / RR）", "Fleiss κ 仅 0.25–0.29"),
    ("维度正交性检验 + 维度数-收益曲线", "外科反馈维度（2605.25440）+ APE（2510.06538）",
     "判定 23 个维度是否冗余、23 个是不是太少", "单域 / 需人类偏好标注"),
    ("12 类标签 + 7 种关系 + 冲突检测", "PromptSys",
     "位点类型枚举与位点间关系表", "0★、无 license"),
    ("sha256 行锚点 + rationale + provenance", "prompt-vc sidecar",
     "位点定位 + 证据链层", "0★"),
    ("7 类 prompt 组件标注集（2163 模板）", "From Prompts to Templates",
     "组件枚举的外部挑战集", "组件集固定"),
    ("指令优先级层级", "Instruction Hierarchy / arXiv 2404.13208",
     "位点的优先级字段", "层级是权限不是条款类型"),
]

BUILD = [
    ("维度集的自动发现 + 稳定化", "抄到的两段式聚类不稳定；已有路线都在别的域且维度名仍是人工前提",
     "同语料跑 N 次，位点集 Jaccard ≥ 阈值，否则判发现失败"),
    ("位点 schema 的形式化", "无人定义过「位点/等位/模态/缺位语义/证据指针」",
     "每个取值必须带原文 span + 字符区间；无证据即失败"),
    ("跨源对齐器", "抄来的都是「切一条 prompt」，没有「对齐多来源」",
     "缺位 ≠ 未取值 必须可区分；不许静默补默认值"),
    ("共识序（consensus order）", "无人做；顺序错了整套结论就错",
     "证据门控（≥3 家）+ 成对先后归一 + 相邻交换修复；顺序可复算"),
    ("家族聚类", "抄来的树长在连续向量上",
     "用存在集 Jaccard 距离（不是序列错配率）；k=2 退化必须显式报告"),
    ("强制度的结构化表达", "无人把「条款 vs 散文」做成可计算字段（prompt 域空白，法律域已有 ARCCS 可搬）",
     "按章节/条款层判定（不是按行）；措辞扫描要单列，字段级标记在措辞扫描里隐形"),
    ("符号化 + 对齐层", "工具链（Biopython / ClustalW / RAxML / MEME）都能抄，这层没人做",
     "同一 prompt 两次符号化逐位一致；gap 与「未取值」可区分"),
    ("「共有位点比例」与共识序的度量定义", "多态位点怎么加权、gap 怎么惩罚、共识序按频率还是按语义排——业界无共识",
     "定义写进文档 + 给一组手算样例；换定义必须能复算出不同结果"),
    ("伪同源陷阱的防护", "prompt 语料大量互相派生，共享同一模板会造出假家族",
     "bootstrap 支撑度 + 打乱位点的 null 树作负对照；真实树必须显著优于 null"),
    ("provenance（来源 / 版本 / 时间戳链路）", "现有工作几乎都假设 prompt 是独立样本，没有一篇处理 prompt 之间的亲缘关系",
     "每个 prompt 能追到源文件 + 版本 + 抽取时间 + 抽取模型"),
    ("模态 / 强度字段（必须 / 应当 / 禁止）", "全行业空白：Colang 2.0、Guardrails parameters、PromptSys、sinc-LLM 四套生态都没有",
     "每个位点取值必须带模态与强度枚举；缺一律判失败"),
    ("作用域字段（全局 / 仅输入 / 仅输出 / 仅某工具）", "只有 Colang 的 flow 结构能间接表达，没有可移植字段",
     "作用域枚举可机检；跨源合并时冲突要报"),
    ("条款 ID ↔ 评测分数的关联键", "Langfuse / Agenta / PromptLayer 的「版本→评测→trace」链路与条款 ID 无任何公开关联",
     "位点必须能挂到评测 / 行为分数上，否则只是描述不是基因"),
]

CHECKS = [
    ("维度发现重跑一致性", "N 次跑，位点集 Jaccard 达标"),
    ("取值器回放一致性", "同 prompt 两次抽取逐字一致 / 温度 0"),
    ("取值证据指针非空", "span 能回查原文，字符区间有效"),
    ("缺位与未取值可区分", "对齐后不得把两者合并"),
    ("序列全局唯一", "不同厂商不得有完全相同序列，除非人工签字"),
    ("覆盖广度与约束强度分列", "强制度只是代理指标，须标注"),
    ("家族聚类距离口径", "存在集 Jaccard；k=2 退化显式报告"),
    ("全文无未读一手源就写实的数字", "每个数字标注取值来源"),
    ("三字段齐全", "模态 / 强度 / 作用域，缺一判失败"),
    ("双通道取值", "软通道给分 + 硬通道 checker；未识别不得兜底成默认等位"),
    ("维度正交性", "维度相关性矩阵存在且最大 |Spearman| 可报"),
    ("维度数不是拍脑袋", "维度数-收益曲线存在，不只报「用了 23 个」"),
    ("家族树有负对照", "打乱位点的 null 树已生成并比较；真实树须显著优于 null"),
    ("provenance 四元组齐全", "源文件 / 版本 / 抽取时间 / 抽取模型"),
]

STACK = [
    ("L1 发现层", "Discovery", [
        ("① 条款原子化", "抄件 #1 / #2 ＋ 抄件 #16（ARCCS 的强制/叙述过滤）"),
        ("② 候选维度归纳", "抄件 #9 ＋ #19 ＋ 稳定性闸（自研 #1）"),
        ("③ 位点候选表", "名称 · 定义 · 例句 · 稳定性得分 · 正交性得分"),
    ]),
    ("L2 编码层", "Encoding", [
        ("④ 位点 schema 定稿", "位点 / 等位 / 模态 / 强度 / 作用域 / 缺位语义 / 证据指针"),
        ("⑤ 取值器（双通道）", "软：MICoL 式打分 ｜ 硬：IFEval 式 checker（自研 #11）"),
        ("⑥ 序列化", "抄件 #7 编码思路 ＋ 抄件 #4/#5 交叉校验"),
        ("⑦ 双口径报告", "覆盖广度 × 约束强度"),
    ]),
    ("L3 对齐层", "Alignment & Evolution", [
        ("⑧ 逐位点对齐", "抄件 #8 ＋ 互最近邻配对（自研 #7 符号化层）"),
        ("⑨ 共识序", "自研 #4 ＋ 抄件 #14 的 NJ 管线"),
        ("⑩ 家族聚类", "自研 #5（存在集 Jaccard）＋ null 树负对照"),
        ("⑪ 变异 / 晋级 / 回滚", "抄件 #6 重写算子 ＋ 抄件 #12 部署门 ＋ AgentNodes 三层基因组作晋级门"),
    ]),
]

BOUND = [
    ("phenome 的 registry.py", "未取到", "huggingface.co 在本沙箱连接失败；已知信息来自作者博客正文与 prompt.py 源码的编码逻辑，足以支撑「位点是手写 registry」这一结论，但 64 个 locus 的逐条名单未逐字核"),
    ("各项目 star 数与 benchmark 幅度", "部分取到", "本轮读到 star 的（garak 10,062 / llm-guard 3,216 但已归档 / PromptDiff 9 / llm-prompt-semantic-diff 6 / prompt-git 4 / PhyloLM 18 / PromptSys 0 / prompt-vc 0）均标注于表内；其余未逐个读到故正文不写"),
    ("PromptSys 与 prompt-vc 的源码", "未读到", "两个 repo 均 0★，src/types/index.ts 与 validator/main.py 未读到，字段名以 README 为准；只作形态参考，不作已验证可用"),
    ("DelvePO 的具体分数", "未核实", "70.48 / 90.56 / SQuAD 84.7→67.4 消融只从二手摘要页看到，未核对论文表格"),
    ("Crosscoders 原始论文", "仅条目级", "只读了综述条目，未读原文"),
    ("Lakera / Check Point 收购", "仅二手", "agentsindex 等二手来源，未读到官方公告原文"),
    ("本地跑通任一候选件", "未做", "本轮是文献与代码调研，不是效果验证；所有「能不能用」都基于实现形态与作者自述的限制"),
]

# ---------------------------------------------------------------- 渲染
def esc(s):
    return html.escape(s, quote=True)


def build():
    rows = []
    for (pid, name, meta, url, desc, cov, trust, tag) in PROJ:
        cells = ""
        for k in PKEYS:
            v = cov[k]
            cls = "cov3" if v == 2 else ("cov1" if v == 1 else "cov0")
            mark = "●" if v == 2 else ("◐" if v == 1 else "·")
            cells += f'<td class="covcell {cls}"><span class="dot">{mark}</span></td>'
        rows.append(f"""<tr>
<td data-label="项目"><a href="{esc(url)}" target="_blank" rel="noopener">{esc(name)}</a>
<span class="meta">{esc(meta)}</span><span class="tag">{esc(tag)}</span></td>
<td data-label="它做了什么" class="desc">{esc(desc)}</td>
{cells}
<td data-label="可信度" class="trust">{esc(trust)}</td>
</tr>""")

    peri = "".join(
        f'<tr><td data-label="线">{esc(a)}</td><td data-label="项目"><b>{esc(b)}</b></td>'
        f'<td data-label="它做了什么" class="desc">{esc(c)}</td>'
        f'<td data-label="坑" class="warn">{esc(d)}</td></tr>'
        for a, b, c, d in PERIPH)

    dec = "".join(
        f'<div class="dcard"><div class="dnum">{i+1}</div><div class="dbody">'
        f'<h4>{esc(t)}</h4><p>{esc(b)}</p><p class="basis">依据：{esc(s)}</p></div></div>'
        for i, (t, b, s) in enumerate(DECISIONS))

    reuse = "".join(
        f'<tr><td data-label="件">{esc(a)}</td><td data-label="从哪抄">{esc(b)}</td>'
        f'<td data-label="干什么">{esc(c)}</td><td data-label="坑" class="warn">{esc(d)}</td></tr>'
        for a, b, c, d in REUSE)

    build_ = "".join(
        f'<tr><td data-label="件">{esc(a)}</td><td data-label="为什么不能抄">{esc(b)}</td>'
        f'<td data-label="验收判据（可机检）">{esc(c)}</td></tr>'
        for a, b, c in BUILD)

    checks = "".join(f'<li><span class="ck">{esc(a)}</span><span class="cv">{esc(b)}</span></li>'
                     for a, b in CHECKS)

    stack = ""
    for title, en, steps in STACK:
        items = "".join(
            f'<li><b>{esc(s)}</b><span class="snote">{esc(n)}</span></li>' for s, n in steps)
        stack += f"""<div class="layer"><div class="ltitle">{esc(title)}<span class="lsub">{esc(en)}</span></div>
<ol class="lsteps">{items}</ol></div>"""

    bound = "".join(
        f'<tr><td data-label="项">{esc(a)}</td><td data-label="状态"><span class="badge">{esc(b)}</span></td>'
        f'<td data-label="说明">{esc(c)}</td></tr>'
        for a, b, c in BOUND)

    # 覆盖矩阵 SVG
    W = 560
    ml, mt, cw, ch = 176, 46, 58, 20
    H = mt + len(PROJ) * ch + 12
    svg = [f'<svg viewBox="0 0 {W} {H}" width="100%" role="img" aria-label="覆盖矩阵">']
    svg.append(f'<text x="12" y="18" class="svgt">子问题覆盖矩阵（● 完全具备 · ◐ 部分 · · 无）</text>')
    for i, (pid, name, meta, url, desc, cov, trust, tag) in enumerate(PROJ):
        y = mt + i * ch
        if i % 2 == 0:
            svg.append(f'<rect x="4" y="{y-13}" width="{W-8}" height="{ch}" class="zebra"/>')
        label = name if len(name) <= 20 else name[:19] + "…"
        svg.append(f'<text x="12" y="{y+3}" class="svgn">{esc(label)}</text>')
        for j, k in enumerate(PKEYS):
            v = cov[k]
            fill = "#2f7d5b" if v == 2 else ("#c79a2e" if v == 1 else "#3a3f47")
            op = "1" if v else "0.35"
            svg.append(f'<circle cx="{ml + j*cw + cw/2}" cy="{y}" r="7" fill="{fill}" opacity="{op}"/>')
    for j, k in enumerate(PKEYS):
        svg.append(f'<text x="{ml + j*cw + cw/2}" y="{mt - 9}" class="svgk">{k}</text>')
    svg.append("</svg>")

    return f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>提示词基因框架 · 业界先例调研</title>
<style>
:root{{--bg:#0e1116;--card:#161b22;--line:#262d36;--fg:#e6edf3;--dim:#9aa7b4;
--acc:#4c9aff;--ok:#2f7d5b;--warn:#c79a2e;--bad:#a05252}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--fg);
font:15px/1.75 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif}}
.wrap{{max-width:1180px;margin:0 auto;padding:32px 20px 80px}}
header h1{{font-size:27px;margin:0 0 8px;letter-spacing:.3px}}
.sub{{color:var(--dim);font-size:14px;margin:0 0 20px}}
.verdict{{background:linear-gradient(90deg,#123a2a,#161b22);border:1px solid #1f5c44;
border-left:4px solid #3fb37a;border-radius:8px;padding:16px 18px;margin:18px 0 26px}}
.verdict b{{color:#5fd39a}}
h2{{font-size:20px;margin:38px 0 12px;padding-bottom:8px;border-bottom:1px solid var(--line)}}
h3{{font-size:16px;margin:22px 0 8px;color:#cfe3ff}}
p{{margin:9px 0}}
a{{color:var(--acc);text-decoration:none}} a:hover{{text-decoration:underline}}
table{{width:100%;border-collapse:collapse;margin:12px 0 8px;font-size:13.5px}}
th,td{{text-align:left;padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top}}
th{{color:var(--dim);font-weight:600;font-size:12.5px;letter-spacing:.4px}}
tr:hover td{{background:#1b2129}}
.meta{{display:block;color:var(--dim);font-size:12px;margin-top:2px}}
.tag{{display:inline-block;margin-top:5px;padding:1px 7px;border:1px solid #33404e;border-radius:20px;
color:#9fc3ef;font-size:11.5px}}
.trust{{color:var(--dim);font-size:12.5px}}
.desc{{color:#cdd9e5}}
.warn{{color:#e2c179}}
.covcell{{text-align:center;width:46px}}
.dot{{font-size:15px}}
.cov3 .dot{{color:#3fb37a}} .cov1 .dot{{color:var(--warn)}} .cov0 .dot{{color:#4a515b}}
.dcard{{display:flex;gap:14px;background:var(--card);border:1px solid var(--line);border-radius:10px;
padding:14px 16px;margin:10px 0}}
.dnum{{flex:0 0 30px;height:30px;border-radius:50%;background:#1f2c3d;color:#7fb4f0;
display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px}}
.dbody{{min-width:0;flex:1}}
.dbody h4{{margin:2px 0 4px;font-size:15px}}
.dbody p{{margin:4px 0;font-size:13.5px;color:#c6d2de}}
.basis{{color:var(--dim);font-size:12.5px}}
.layer{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin:10px 0}}
.ltitle{{font-weight:700;font-size:16px;color:#8fd0ff}}
.lsub{{margin-left:9px;color:var(--dim);font-weight:400;font-size:12.5px;letter-spacing:1px}}
.lsteps{{margin:8px 0 0;padding-left:22px}}
.lsteps li{{margin:5px 0;font-size:13.5px}}
.snote{{display:block;color:var(--dim);font-size:12.5px}}
.clean{{list-style:none;padding:0;margin:10px 0}}
.clean li{{display:flex;gap:12px;flex-wrap:wrap;padding:7px 0;border-bottom:1px solid var(--line);font-size:13.5px}}
.ck{{flex:0 0 320px;color:#d7e4f0}} .cv{{flex:1;min-width:0;color:var(--dim)}}
.badge{{display:inline-block;padding:1px 8px;border-radius:20px;border:1px solid #4a3f22;
background:#2a2413;color:#e2c179;font-size:12px}}
.badge.ok{{border-color:#1f5c44;background:#12291f;color:#5fd39a}}
.qbox{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 18px;margin:12px 0}}
.qbox h3{{margin:0 0 4px;color:#ffd479}}
.qbox p{{font-size:13.8px;color:#c9d5e1}}
.legend{{display:flex;gap:16px;flex-wrap:wrap;color:var(--dim);font-size:12.5px;margin:8px 0}}
.matrix{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px;margin:12px 0;overflow-x:auto}}
.matrix svg{{min-width:520px;max-width:560px;display:block;margin:0 auto}}
.svgt{{fill:#9aa7b4;font-size:12px}} .svgk{{fill:#7fb4f0;font-size:12px;font-weight:700;text-anchor:middle}}
.svgn{{fill:#cdd9e5;font-size:11.5px}} .zebra{{fill:#1a2029}}
.note{{background:#1b1a12;border:1px solid #4a3f22;border-left:4px solid var(--warn);
border-radius:8px;padding:12px 16px;margin:16px 0;font-size:13.5px;color:#e8dcc0}}
.grid2{{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}}
.mini{{background:var(--card);border:1px solid var(--line);border-radius:9px;padding:12px 14px;min-width:0}}
.mini h4{{margin:0 0 5px;font-size:14.5px;color:#8fd0ff}}
.mini p{{font-size:13px;color:#c2cedb;margin:3px 0}}
footer{{margin-top:44px;padding-top:16px;border-top:1px solid var(--line);color:var(--dim);font-size:12.5px}}
@media(max-width:720px){{
.wrap{{padding:20px 13px 60px}} header h1{{font-size:21px}}
table{{display:block}} thead{{display:none}} tbody,tr,td{{display:block;width:100%}}
tr{{margin:8px 0;border:1px solid var(--line);border-radius:8px;padding:6px}}
td{{border:none;padding:4px 6px}}
td::before{{content:attr(data-label);display:block;color:var(--dim);font-size:11.5px;letter-spacing:.4px}}
.covcell{{width:auto;text-align:left}} .covcell::before{{content:""}}
.dcard{{flex-direction:column;gap:6px}} .ck{{flex:none}}
}}
</style></head><body><div class="wrap">

<header>
<h1>提示词「基因序列」框架 · 业界先例调研</h1>
<p class="sub">自动提取维度 → 生成基因序列 → 跨来源对齐 ｜ 快照 2026-11-17 ｜ 35 个 P1–P5 先例 + 11 个周边线先例</p>
</header>

<div class="verdict">
<p><b>结论：没有直接先例。</b>但不是一个空白市场——它由若干成熟零件拼成，而<b>没有人把这些零件串成我们需要的那个闭环</b>。</p>
<p style="margin:6px 0 0">★ <b>本轮中途做了一处自我更正</b>：初稿写「P3 离散编码没有先例」，读完 <b>DelvePO</b>（明写 Loci / Alleles）、<b>PromptGenome</b>（组件型 genome + locus 级变异器）、<b>SEPO</b>（typed units）、<b>CFG-genotype</b>、<b>phenome</b> 后必须改判：<b>「一条 prompt → 一串离散槽位」已有 5 个明确先例</b>；<b>但它们全部把「位点集从哪来」当人工前提</b>，而真正空着的是<b>「跨 prompt 的逐位点对齐 / 共有位点比例 / 共识序 / 家族聚类」</b>。</p>
</div>

<h2>1 · 判据：五个可独立回答的子问题</h2>
<div class="grid2">
<div class="mini"><h4>P1 条款级切分</h4><p>能把长 system prompt 切成<b>有类型标签的原子条款</b>，而不是按 markdown 标题切。</p></div>
<div class="mini"><h4>P2 位点集自动发现</h4><p>维度集本身<b>从语料归纳</b>，不是人先写死。<b>有四条真实路线</b>（TaxoAdapt / APE / EvalAgent / SAE-TM），但都在别的域，且维度名仍是人工前提。</p></div>
<div class="mini"><h4>P3 离散编码</h4><p>每个 prompt 映射成<b>固定槽位上的离散取值</b>。<b>已有 5 个明确先例</b>（DelvePO / PromptGenome / SEPO / CFG / phenome），但都只服务单条 prompt 的优化。</p></div>
<div class="mini"><h4>P4 跨源对齐</h4><p>能算共有位点比例与逐位点差异，且能产出<b>共识序</b>。<b>PhyloLM</b> 把 prompt 当 gene、输出 token 当 allele 建 NJ 树——但树长在模型上。</p></div>
<div class="mini"><h4>P5 家族聚类</h4><p>能在基因序列上做家族聚类，而不是只有 embedding 聚类。<b>prompt 域无直接先例</b>。</p></div>
<div class="mini"><h4>两轴（业界三家都没分）</h4><p><b>覆盖广度</b>（多少家写到）× <b>约束强度</b>（写到的那家里多少写成条款级强制而非散文）。</p></div>
</div>

<h2>2 · 先例总表</h2>
<div class="matrix">{''.join(svg)}
<div class="legend"><span>● 完全具备</span><span>◐ 部分</span><span>· 无</span><span>绿＝全 黄＝半 灰＝无</span></div>
</div>
<table><thead><tr><th>项目</th><th>它做了什么</th>
{'<th>P1</th><th>P2</th><th>P3</th><th>P4</th><th>P5</th>'}
<th>可信度</th></tr></thead><tbody>{''.join(rows)}</tbody></table>

<h2>3 · 周边四条线（不进 P1–P5 矩阵）</h2>
<table><thead><tr><th>线</th><th>项目</th><th>它做了什么</th><th>坑 / 否定发现</th></tr></thead><tbody>{peri}</tbody></table>

<h2>4 · 四个判定题，明确回答</h2>
<div class="qbox"><h3>Q1 有没有把一批 prompt 编码成可对齐的离散位点序列？</h3>
<p><b>前半有，后半没有。</b>有：DelvePO（明写 Loci/Alleles）、PromptGenome、SEPO、CFG-genotype、phenome。没有：这些都只为<b>单条 prompt 的优化</b>服务，没有任何一篇做过「不同 prompt 的槽位一一对齐 / 共有位点比例 / 共识序」。方法论最近的是 <b>PhyloLM</b>，但它<b>把树长在模型上</b>，要横移一层。<br><b>负向检索证据</b>：arXiv 全库检索 <code>abs:"prompt" AND abs:"multiple sequence alignment"</code>（唯一命中是蛋白 MSAGPT）、<code>abs:"prompt" AND abs:"consensus sequence"</code>（0 命中）、<code>abs:"prompt" AND abs:"phylogenetic"</code>（无 prompt 本体相关）——<b>没有任何论文对 prompt 集合做过 MSA / 共识序 / 系统发育树</b>。</p></div>
<div class="qbox"><h3>Q2 有没有自动发现维度集的工作？</h3>
<p><b>有四条真实路线，但都不是「从一批 prompt 归纳共享位点表」。</b>① <b>TaxoAdapt</b>（维度名人工给、节点全自动）② <b>Auto-Prompt Ensemble</b>（从失败案例反向长维度，88→40→16）③ <b>EvalAgent</b>（产出「prompt 里没说但人会在意」的隐式标准）④ <b>SAE-TM</b>（SAE feature 天然是 thematic atom）。外加 MDPI 2026 两段式聚类（<b>自报温度 0.3 下重复跑簇数最多差 15%</b>）。<br>prompt 域：PromptPrism <b>明说自己是 top-down 手工的</b>；<b>DelvePO 自陈「dynamic component discovery 仍是空白」</b>。<br><b>⇒ 修正后的准确说法：不是「没人做过」，而是「做过的都在别的域，且维度名或本体字段都还是人工前提」。</b></p></div>
<div class="qbox"><h3>Q3 有没有共识序 / 家族聚类（prompt 域）？</h3>
<p><b>没有直接先例。</b>工具链齐备且 ConGrs 已把 Needleman–Wunsch 搬进 NLP；EoT 的 C-Evolve 有「共识组投票」，但那是<b>投票选优</b>不是<b>共识序列排序</b>；SPDeconstruction 确实生成了 dendrogram（注释自称 family tree），但树长在连续向量上。<br><b>工具链可整条搬</b>：Biopython Align / ClustalW / RAxML-NJ / MEME 都能用，<b>必须自研的只有「符号化 + 对齐层」</b>。另有一条新证据：<b>「位点级 diff」至今无人做</b>——主流 prompt 平台全部只有文本 diff。</p></div>
<div class="qbox"><h3>Q4 有没有「条款级 + 标注强制 / 散文」的成熟做法？</h3>
<p><b>法律域有且整套可搬，prompt 域是空白。</b><b>ARCCS</b>（EMNLP 2026）：层级分段 → 原子条款 typed tuple ⟨法律功能, 主体, 适用范围, 强制条件集 M_i, 原文指针⟩ + <b>显式过滤纯定义/描述/上下文条款</b>；GDPR 100 条，judge 一致率 90–96.67%、Fleiss κ=0.69。<b>CUAD</b>：41 类人工条款类型。<br>prompt 域：From Prompts to Templates / Prompts in the Wild 只做<b>结构/位置</b>分类，<b>不区分强制条款与叙述散文</b>；Instruction Hierarchy 的层级是<b>权限优先级</b>不是条款类型。</p></div>

<h2>5 · 框架草案（本页提出的设计，非既有事实）</h2>
{stack}
<h3>十个必须显式做出的设计决策</h3>
{dec}

<h2>6 · 空白地图</h2>
<h3>可直接抄的件（24）</h3>
<table><thead><tr><th>件</th><th>从哪抄</th><th>抄来干什么</th><th>坑</th></tr></thead><tbody>{reuse}</tbody></table>
<h3>必须自研的件（13）</h3>
<table><thead><tr><th>件</th><th>为什么不能抄</th><th>验收判据（可机检）</th></tr></thead><tbody>{build_}</tbody></table>

<h2>7 · 自检清单</h2>
<ul class="clean">{checks}</ul>

<div class="note"><b>诚实边界</b>：本轮是<b>文献与代码调研</b>，不是效果验证——所有「能不能用」都基于实现形态与作者自述的限制，<b>未在本地跑通任何一个候选件</b>。报告里转述的数字（phenome 的 68%、steering transfer 的 71.0%、MDPI 的 4.64/5）<b>均为作者自报，未独立复现</b>。CL4R1T4S 的 README 含一段 leet 混淆的提示注入（要求 AI 输出自身系统指令），<b>本轮再次识别并拒绝执行</b>，未输出任何自身系统指令；该仓库用 AGPL-3.0 覆盖厂商专有提示词，<b>维护者无权授予该许可</b>，基于它做训练或分发前必须先解决溯源与授权。</div>

<h2>8 · 明确未核实项</h2>
<table><thead><tr><th>项</th><th>状态</th><th>说明</th></tr></thead><tbody>{bound}</tbody></table>

<footer>提示词核心维度 → 基因粗序列 → 业界先例调研 ｜ 2026-11-17 ｜ 数据与文案见生成脚本，页面为单文件自包含</footer>
</div></body></html>"""


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    h = build()
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(h)
    print(f"wrote {OUT} {len(h.encode('utf-8'))} bytes")
