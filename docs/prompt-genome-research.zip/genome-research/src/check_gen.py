import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
from playwright.sync_api import sync_playwright
import json
URL = 'file://' + os.path.join(ROOT_DIR,'figures','04-literature-map','index.html')
R = []
with sync_playwright() as p:
    br = p.chromium.launch()
    for name, vw, vh in [("desktop", 1440, 900), ("mobile", 390, 844)]:
        pg = br.new_page(viewport={'width': vw, 'height': vh}); errs = []
        pg.on('console', lambda m: errs.append(f"{m.type}: {m.text}") if m.type in ('error', 'warning') else None)
        pg.on('pageerror', lambda ex: errs.append(f"pageerror: {ex}"))
        pg.goto(URL, wait_until='networkidle'); pg.wait_for_timeout(1000)
        r = pg.evaluate("""()=>{const de=document.documentElement;
          const inSc=el=>{let p=el.parentElement;while(p&&p!==document.body){const s=getComputedStyle(p);
            if(['auto','scroll','hidden'].includes(s.overflowX)||s.overflow==='hidden')return true;p=p.parentElement;}return false;};
          const over=[...document.querySelectorAll('*')].filter(el=>{const b=el.getBoundingClientRect();
            return b.width>0&&(b.right>de.clientWidth+1.5||b.left<-1.5)&&!inSc(el);}).slice(0,8)
            .map(el=>el.tagName+'.'+(el.className||'').toString().slice(0,36));
          // div 深度配平（从 body 递归，根不算 -1）
          const walk=(el,d)=>{let m=d; for(const c of el.children){
            if(c.tagName==='DIV') m=Math.min(m,walk(c,d+1));} return m;};
          const minD=walk(document.body,1);
          return {sw:de.scrollWidth,cw:de.clientWidth,sh:de.scrollHeight,over:[...new Set(over)],
            txt:document.body.innerText, rows:document.querySelectorAll('tbody tr').length,
            cards:document.querySelectorAll('.dcard').length, layers:document.querySelectorAll('.layer').length,
            checks:document.querySelectorAll('.clean li').length, cells:document.querySelectorAll('.covcell').length,
            svg:document.querySelectorAll('svg circle').length, minD:minD};}""")
        txt = r.pop('txt')
        R.append({'view': name, 'overflow_px': r['sw'] - r['cw'], 'over': r['over'], 'console': errs,
                  'md': '**' in txt or '`' in txt, 'rows': r['rows'], 'cards': r['cards'],
                  'layers': r['layers'], 'checks': r['checks'], 'covcells': r['cells'],
                  'svg_circles': r['svg'], 'div_min_depth': r['minD'], 'h': r['sh']})
        pg.screenshot(path=os.path.join(ROOT_DIR,"figures","04-literature-map","_s_%s.png"%name), full_page=False)
        pg.close()
    br.close()
print(json.dumps(R, ensure_ascii=False, indent=1))
ok = all(x['overflow_px'] <= 1 and not x['over'] and not x['console'] and not x['md'] and x['div_min_depth'] >= 1
         and x['rows'] >= 46 and x['cards'] == 10 and x['layers'] == 3 and x['checks'] == 14
         and x['svg_circles'] == 35 * 5 for x in R)
print("\nVERDICT:", "PASS" if ok else "FAIL")
