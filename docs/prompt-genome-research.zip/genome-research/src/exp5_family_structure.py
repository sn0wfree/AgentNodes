#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E5：家族结构到底存不存在？—— 用合法统计量重测。

E4 的教训：平均两两 Jaccard 不能检验聚类结构（真实结构让分布变双峰，平均反而更低）。
本脚本改用：
  (1) 方差检验（结构 ⇒ 分布更分散）
  (2) 1-NN 检验（结构 ⇒ 每家都有一个异常相似的伙伴）
  (3) 聚类后组内离散度 vs null 树
  (4) 只用「有区分力的低位点」再聚一次（高位点人人都有，不提供区分力）
"""
import json, collections, itertools, random, math

RD = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding="utf-8"))
LOCI = RD["LOCI"]; G = RD["genome"]; V = sorted(G.keys())
random.seed(20261118)
def jac(a, b):
    u = len(a | b); return len(a & b) / u if u else 0.0
sets = {v: {d for d in LOCI if G[v].get(d, "absent") != "absent"} for v in V}
support = collections.Counter()
for v in V:
    for d in sets[v]: support[d] += 1

def pair_js(S):
    return {frozenset((a, b)): jac(S[a], S[b]) for a, b in itertools.combinations(V, 2)}

def stats(js):
    vals = list(js.values())
    n = len(vals); m = sum(vals) / n
    var = sum((x - m) ** 2 for x in vals) / n
    return m, var, max(vals), min(vals)

def nn_sims(S):
    """每家最相似伙伴的相似度"""
    out = {}
    for v in V:
        out[v] = max(jac(S[v], S[u]) for u in V if u != v)
    return out

def kmeans_1d(vecs, k, iters=200):
    """对每家的相似度向量做 k-means（每家一个点，坐标=它与各家的相似度）"""
    cent = random.sample(vecs, k)
    for _ in range(iters):
        lab = [min(range(k), key=lambda c: sum((vecs[i][j] - cent[c][j]) ** 2 for j in range(len(vecs[i]))))
               for i in range(len(vecs))]
        newc = []
        for c in range(k):
            mem = [vecs[i] for i in range(len(vecs)) if lab[i] == c]
            if mem:
                newc.append([sum(m[j] for m in mem) / len(mem) for j in range(len(mem[0]))])
            else:
                newc.append(cent[c])
        if newc == cent: break
        cent = newc
    wss = sum(sum((vecs[i][j] - cent[lab[i]][j]) ** 2 for j in range(len(vecs[i])))
              for i in range(len(vecs)))
    return lab, wss

def build_vectors(S, idx):
    """每家一个向量：与各家的相似度"""
    return [[jac(S[v], S[u]) for u in idx] for v in idx]

print(f"厂商 {len(V)} 家，位点 {len(LOCI)} 个\n")
J_obs = pair_js(sets)
m, var, mx, mn = stats(J_obs)
print(f"=== 实测两两相似度分布 ===")
print(f"  均值 {m:.4f}  方差 {var:.5f}  max {mx:.3f}  min {mn:.3f}")

# ---- null：打乱厂商标签（保留每家的集合大小与全部内容，只打乱「谁是谁」）----
null_var = []; null_nn_mean = []; null_max = []
for _ in range(300):
    perm = V[:]; random.shuffle(perm)
    S2 = {v: sets[perm[i]] for i, v in enumerate(V)}
    J2 = pair_js(S2)
    m2, v2, mx2, _ = stats(J2)
    null_var.append(v2); null_max.append(mx2)
    nn = nn_sims(S2); null_nn_mean.append(sum(nn.values()) / len(nn))
null_var.sort(); null_max.sort()
obs_nn = nn_sims(sets); obs_nn_mean = sum(obs_nn.values()) / len(obs_nn)
print(f"\n=== (1)(2) null 对照（打乱厂商标签 300 次） ===")
print(f"  方差：实测 {var:.5f}  null 中位 {null_var[len(null_var)//2]:.5f}  "
      f"null 95 分位 {null_var[int(.95*len(null_var))]:.5f}  "
      f"p={sum(1 for x in null_var if x >= var)/300:.3f}")
print(f"  最大相似度：实测 {mx:.3f}  null 中位 {null_max[len(null_max)//2]:.3f}  "
      f"null 95 分位 {null_max[int(.95*len(null_max))]:.3f}  "
      f"p={sum(1 for x in null_max if x >= mx)/300:.3f}")
print(f"  1-NN 相似度均值：实测 {obs_nn_mean:.4f}  null 中位 {sorted(null_nn_mean)[150]:.4f}")
p95 = sorted(null_nn_mean)[int(.95*300)]
hot = [v for v in V if obs_nn[v] >= p95]
print(f"  1-NN 相似度 ≥ null95 分位（{p95:.4f}）的厂商：{len(hot)}/{len(V)}  {hot}")

# ---- (3) 聚类组内离散度 vs null 树 ----
print(f"\n=== (3) 聚类结构 vs null 树（k=2 / k=3） ===")
idx = V[:]
vecs_obs = build_vectors(sets, idx)
for k in (2, 3, 4):
    lab, wss = kmeans_1d(vecs_obs, k)
    nulls = []
    for _ in range(30):
        perm = V[:]; random.shuffle(perm)
        S2 = {v: sets[perm[i]] for i, v in enumerate(V)}
        v2 = build_vectors(S2, idx)
        random.shuffle(v2)  # 打乱行序＝打乱「谁是谁」
        _, w2 = kmeans_1d(v2, k)
        nulls.append(w2)
    nulls.sort()
    p = sum(1 for x in nulls if x <= wss) / len(nulls)
    sizes = collections.Counter(lab).most_common()
    print(f"  k={k}: 组内离散 WSS = {wss:.4f}  null 中位 {nulls[len(nulls)//2]:.4f}  "
          f"null 5 分位 {nulls[int(.05*len(nulls))]:.4f}  p(更紧)={p:.3f}  组大小 {sizes}")

# ---- (4) 只用有区分力的低位点 ----
print(f"\n=== (4) 只用「有区分力的低位点」重测（高位点人人都有，不提供区分力） ===")
for thr in (20, 16, 12, 10):
    core = {d for d in LOCI if support[d] >= thr}
    disc = {d for d in LOCI if support[d] < thr}
    if len(disc) < 3: continue
    S_core = {v: sets[v] & core for v in V}
    S_disc = {v: sets[v] & disc for v in V}
    jc = pair_js(S_core); jd = pair_js(S_disc)
    mc, vc, mxc, _ = stats(jc); md, vd, mxd, _ = stats(jd)
    nullv = []
    for _ in range(200):
        perm = V[:]; random.shuffle(perm)
        S2 = {v: sets[perm[i]] for i, v in enumerate(V)}
        J2 = pair_js({v: S2[v] & disc for v in V})
        _, v2, _, _ = stats(J2); nullv.append(v2)
    nullv.sort()
    p = sum(1 for x in nullv if x >= vd) / len(nullv)
    print(f"  区分性位点 {len(disc):>2} 个（support<{thr}）：实测方差 {vd:.5f}  "
          f"null 中位 {nullv[len(nullv)//2]:.5f}  p={p:.3f}"
          f"{'  ★ 超基线' if p<=0.05 else ''}")
    print(f"       其中位点: {', '.join(disc)}")

# ---- (4b) J 是不是 (|A|,|B|) 的纯函数？----
print(f"\n=== (4b) 关键检验：存在集 Jaccard 是不是「只由两个集合大小决定」？ ===")
grp = collections.defaultdict(list)
for a, b in itertools.combinations(V, 2):
    grp[(len(sets[a]), len(sets[b]))].append(jac(sets[a], sets[b]))
sizes_seen = sorted(grp)
tot_w = 0.0; tot_v = 0.0; within = []
for kk, vals in grp.items():
    if len(vals) < 2: continue
    m = sum(vals)/len(vals)
    vv = sum((x-m)**2 for x in vals)/len(vals)
    within.append(vv)
    tot_w += len(vals); tot_v += len(vals)*vv
print(f"  按 (|A|,|B|) 分组后，组内 J 的平均方差 = {tot_v/max(1,tot_w):.6f}")
print(f"  组内方差为 0 的组占比 = {sum(1 for v in within if v < 1e-12)}/{len(within)}")
allv = [x for vals in grp.values() for x in vals]
gm = sum(allv)/len(allv)
print(f"  总体方差 = {sum((x-gm)**2 for x in allv)/len(allv):.6f}")
print(f"  ⇒ 组内方差 / 总体方差 = {tot_v/max(1,tot_w) / (sum((x-gm)**2 for x in allv)/len(allv)):.3f}"
      f"   （接近 0 ⇒ J 完全由集合大小决定，位点身份不携带信息）")
# 举例
ex = [(kk, round(sum(v)/len(v),3), len(v)) for kk,v in list(grp.items())[:12]]
print("  样例 (|A|,|B|) → 平均 J:", ex)

# ---- (5) 核心 + 私有延伸 分解 ----
print(f"\n=== (5) 结构到底是什么形状：核心 + 私有延伸 ===")
core15 = [d for d in LOCI if support[d] >= 15]
core10 = [d for d in LOCI if support[d] >= 10]
print(f"  核心（support≥15）{len(core15)} 个：{', '.join(core15)}")
print(f"  核心（support≥10）{len(core10)} 个：{', '.join(core10)}")
print(f"\n  逐厂商：核心覆盖 / 总覆盖 / 私有延伸数")
for v in sorted(V, key=lambda x: -len(sets[x])):
    c = len(sets[v] & set(core15)); tot = len(sets[v])
    ext = tot - c
    print(f"    {v:<12} {c:>2}/{tot:<3} 私有 {ext:>2}   私有位点: "
          + (", ".join(sorted(sets[v] - set(core15)))[:110] or "—"))
