#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E7：修正后的 null 对照。

★ 前几轮 null 的错误：把厂商标签重新洗牌后再取「全部配对」，
  等价于对无序配对集合做一个置换 ⇒ 配对距离的多重集根本不变 ⇒ null 退化等于实测。
  正确的 null 必须打乱「谁拥有哪个位点」的**共现关系**，同时保住两个边际：
    - 每家厂商的覆盖广度（|S_v|）不变
    - 每个位点的全局频次（support）不变
  实现：把位点按 support 加权，对每家独立重抽同样多的位点。
"""
import os
import json, glob, os, re, collections, itertools, random, math
from genome_lib import LOCI, RX

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')
RD = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding="utf-8"))
random.seed(20261118)

def jac(a, b):
    u = len(a | b); return len(a & b)/u if u else 0.0
def var(v):
    m = sum(v)/len(v); return sum((x-m)**2 for x in v)/len(v)

def analyse(sets, V, label):
    pairs = list(itertools.combinations(V, 2))
    js = [jac(sets[a], sets[b]) for a, b in pairs]
    o_var = var(js); o_max = max(js)
    nn = {v: max(jac(sets[v], sets[u]) for u in V if u != v) for v in V}
    return o_var, o_max, js, nn

def null_distributions(sets, V, support, rounds=400):
    """正确的 null：保住 |S_v| 与 support，重抽共现"""
    nv, nmx, nnn = [], [], []
    weights = [support[d] for d in LOCI]
    for _ in range(rounds):
        S2 = {}
        for v in V:
            k = len(sets[v])
            # 按 support 加权、无放回抽 k 个位点
            pool = []
            for d in LOCI:
                pool += [d] * support[d]
            S2[v] = set(random.sample(pool, k)) if k <= len(pool) else set(pool[:k])
        pairs = list(itertools.combinations(V, 2))
        js = [jac(S2[a], S2[b]) for a, b in pairs]
        nv.append(var(js)); nmx.append(max(js))
        nnn.append(sum(max(jac(S2[v], S2[u]) for u in V if u != v) for v in V)/len(V))
    nv.sort(); nmx.sort(); nnn.sort()
    return nv, nmx, nnn

# ============ 数据 1：上一轮的 26 家 × 23 维存在集 ============
G = RD["genome"]; V26 = sorted(G)
sets26 = {v: {d for d in LOCI if G[v].get(d, "absent") != "absent"} for v in V26}
sup26 = collections.Counter()
for v in V26:
    for d in sets26[v]: sup26[d] += 1

print("=== 数据集 1：26 家 × 23 维「存在集」（上一轮口径） ===")
o_var, o_max, js, nn = analyse(sets26, V26, "exists")
nv, nmx, nnn = null_distributions(sets26, V26, sup26)
print(f"  两两 J 方差：实测 {o_var:.6f}   null 中位 {nv[len(nv)//2]:.6f}   "
      f"null95 {nv[int(.95*len(nv))]:.6f}   p = {sum(1 for x in nv if x >= o_var)/len(nv):.3f}")
print(f"  最大两两 J ：实测 {o_max:.3f}      null 中位 {nmx[len(nmx)//2]:.3f}      "
      f"null95 {nmx[int(.95*len(nmx))]:.3f}      p = {sum(1 for x in nmx if x >= o_max)/len(nmx):.3f}")
print(f"  1-NN 相似度均值：实测 {sum(nn.values())/len(nn):.4f}  null 中位 {nnn[len(nnn)//2]:.4f}")

# ============ 数据集 2：15 家 × 条款级存在集（SPDeconstruction 口径） ============
print("\n=== 数据集 2：15 家 × 条款级存在集（SPDeconstruction 管线） ===")
def dim_hits(t):
    t = t.lower(); return {d for d in LOCI if RX[d].search(t)}
byv = collections.defaultdict(lambda: collections.defaultdict(set))
for f in sorted(glob.glob(os.path.join(ROOT, "*", "*.json"))):
    v = os.path.basename(os.path.dirname(f))
    for it in json.load(open(f, encoding="utf-8")):
        txt = (it.get("full_statement") or "") + " " + (it.get("anchor") or "")
        for d in dim_hits(txt): byv[v][d].add(1)
V15 = sorted(byv)
sets15 = {v: set(byv[v].keys()) for v in V15}
sup15 = collections.Counter()
for v in V15:
    for d in sets15[v]: sup15[d] += 1
o_var, o_max, js, nn = analyse(sets15, V15, "B")
nv, nmx, nnn = null_distributions(sets15, V15, sup15)
print(f"  两两 J 方差：实测 {o_var:.6f}   null 中位 {nv[len(nv)//2]:.6f}   "
      f"null95 {nv[int(.95*len(nv))]:.6f}   p = {sum(1 for x in nv if x >= o_var)/len(nv):.3f}")
print(f"  最大两两 J ：实测 {o_max:.3f}      null 中位 {nmx[len(nmx)//2]:.3f}      "
      f"null95 {nmx[int(.95*len(nmx))]:.3f}      p = {sum(1 for x in nmx if x >= o_max)/len(nmx):.3f}")
print(f"  1-NN 相似度均值：实测 {sum(nn.values())/len(nn):.4f}  null 中位 {nnn[len(nnn)//2]:.4f}")
print(f"  1-NN ≥ null95（{nnn[int(.95*len(nnn))]:.4f}）的厂商："
      f"{[v for v in V15 if nn[v] >= nnn[int(.95*len(nnn))]]}")

# ============ 数据集 3：等位编码（显式模态率向量） ============
print("\n=== 数据集 3：15 家 × 23 维「显式模态率」等位向量 ===")
prof = collections.defaultdict(dict)
for v in V15:
    per = collections.defaultdict(lambda: [0, 0])
    for f in sorted(glob.glob(os.path.join(ROOT, v, "*.json"))):
        for it in json.load(open(f, encoding="utf-8")):
            if it.get("class") != "regulative": continue
            rc = it.get("regulative_components") or {}
            txt = (it.get("full_statement") or "") + " " + (it.get("anchor") or "")
            for d in dim_hits(txt):
                per[d][0] += 1
                if (rc.get("D") or "").strip(): per[d][1] += 1
    for d in LOCI:
        n, k = per[d]
        prof[v][d] = (k/n if n else 0.0)
def cosf(a, b):
    x = [prof[a][d] for d in LOCI]; y = [prof[b][d] for d in LOCI]
    dot = sum(p*q for p, q in zip(x, y))
    nx = math.sqrt(sum(p*p for p in x)); ny = math.sqrt(sum(q*q for q in y))
    if nx == 0 or ny == 0: return 1.0
    return 1 - dot/(nx*ny)
pairs = list(itertools.combinations(V15, 2))
obs = [cosf(a, b) for a, b in pairs]
ov = var(obs)
nulls = []
for _ in range(400):
    # null：每家的 23 维向量按 support 无关地独立重抽（打乱维度共现）
    perm_sets = {v: set(random.sample([d for d in LOCI if sup15[d] > 0],
                                       len(sets15[v]))) if len(sets15[v]) <= len([d for d in LOCI if sup15[d]>0]) else set()
                 for v in V15}
    nulls.append(var([cosf(a, b) for a, b in pairs]))
nulls.sort()
print(f"  余弦距离方差：实测 {ov:.6f}  null 中位 {nulls[len(nulls)//2]:.6f}  "
      f"null95 {nulls[int(.95*400)]:.6f}  p = {sum(1 for x in nulls if x >= ov)/400:.3f}")
