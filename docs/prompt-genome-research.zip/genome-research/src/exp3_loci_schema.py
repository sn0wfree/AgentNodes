#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E3：位点表的候选口径横向比较。

问题：「位点」用什么定义，才能既跨厂商共享、又稳定？
候选口径 S0–S6，每种都算：位点数 · 跨厂商存在集 Jaccard · ≥K 家共有的位点数 · Null 对照。
"""
import os
import json, glob, os, re, collections, random, math, itertools

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')
RD = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding="utf-8"))
random.seed(20261118)

# ---------- 归一化工具 ----------
NEG = re.compile(r"^(not|never|avoid|don't|do not|doesn't|refuse to)\s+")
STOP = {"the", "a", "an", "and", "or", "to", "of", "in", "for", "with", "on", "at", "it", "its"}

def norm(s):
    if not s: return ""
    s = re.sub(r"\s+", " ", s.strip().lower())
    return s.strip(" .,:;!?\"'`()[]")

def strip_neg(s):
    s = norm(s)
    for _ in range(3):
        m = NEG.match(s)
        if m:
            s = s[m.end():].strip()
        else:
            break
    return s

def canon_verb(s):
    """去否定 + 词干化 + 归一到受控动词表"""
    s = strip_neg(s)
    s = re.sub(r"^(try to|tries to|attempt to|tries|tried)\s+", "", s)
    w = s.split()
    if not w: return ""
    v = w[0]
    # 词干
    for suf in ("ing", "es", "s", "ed"):
        if v.endswith(suf) and len(v) > len(suf) + 2:
            v = v[: -len(suf)]; break
    MAP = {
        "use": "use", "utilize": "use", "employ": "use", "apply": "use", "leverage": "use",
        "prov": "provide", "offer": "provide", "give": "provide", "present": "provide",
        "suppl": "provide", "deliver": "provide", "return": "provide",
        "includ": "include", "contain": "include", "cover": "include",
        "search": "search", "brows": "search", "quer": "search", "lookup": "search",
        "ask": "ask", "request": "ask", "clarif": "ask", "inquire": "ask",
        "answer": "answer", "respond": "answer", "reply": "answer", "repl": "answer",
        "tell": "tell", "inform": "tell", "notif": "tell", "communicate": "tell",
        "writ": "write", "produc": "write", "author": "write", "draft": "write",
        "creat": "create", "generat": "create", "make": "create", "build": "create",
        "mention": "mention", "refer": "mention", "name": "mention",
        "show": "show", "display": "show", "present": "show", "reveal": "show",
        "explain": "explain", "describ": "explain", "clarify": "explain",
        "cite": "cite", "sourc": "cite", "attribut": "cite", "quot": "cite",
        "analyz": "analyze", "analys": "analyze", "evaluat": "analyze", "assess": "analyze",
        "refus": "refuse", "decline": "refuse", "reject": "refuse",
        "suggest": "suggest", "recommend": "suggest", "propos": "suggest",
        "priorit": "prioritize", "prioritis": "prioritize",
        "maintain": "maintain", "keep": "maintain", "preserv": "maintain",
        "follow": "follow", "adher": "follow", "compli": "follow", "obey": "follow",
        "call": "call", "invoke": "call", "access": "call",
        "avoid": "avoid", "prevent": "avoid", "stop": "avoid",
        "engag": "engage", "interact": "engage", "participat": "engage",
        "send": "send", "deliver": "send", "transmit": "send",
        "treat": "treat", "handle": "treat", "address": "treat",
        "respect": "respect", "honor": "respect", "comply": "respect",
        "be": "be", "is": "be", "are": "be", "has": "be", "have": "be",
        "not": "not", "assist": "assist", "help": "assist", "support": "assist",
        "ensure": "ensure", "make": "ensure", "verify": "ensure", "check": "ensure",
        "scal": "scale", "adapt": "adapt", "adjust": "adapt",
        "note": "note", "mention": "note", "acknowledge": "acknowledge",
        "point": "point", "redirect": "redirect", "start": "start", "begin": "start",
        "give": "provide", "prefer": "prefer", "choose": "prefer", "select": "prefer",
        "perform": "perform", "do": "perform", "try": "perform",
        "discuss": "discuss", "explain": "discuss", "illustrate": "illustrate",
        "place": "place", "put": "place", "set": "place",
        "get": "get", "obtain": "get", "fetch": "get", "retrieve": "get",
        "think": "think", "reason": "think", "consider": "think",
        "identify": "identify", "detect": "identify", "recognize": "identify",
        "review": "review", "evaluat": "review",
        "reject": "reject", "disallow": "reject",
        "include": "include", "add": "include",
        "format": "format", "structur": "format",
        "assume": "assume", "presum": "assume",
        "express": "express", "state": "express", "clarify": "express",
    }
    if v in MAP: return MAP[v]
    if v.endswith("e") and v[:-1] in MAP: return MAP[v[:-1]]
    if v.endswith("y") and v[:-1] + "i" in MAP: return MAP[v[:-1]]
    return v

def obj_theme(s):
    """从 Object(B) 抽关键词做粗主题"""
    s = norm(s)
    words = [w for w in re.findall(r"[a-z][a-z\-]{2,}", s) if w not in STOP]
    return " ".join(sorted(set(words))[:3])

# ---------- 载入 ----------
per = collections.defaultdict(list)
vendors = set()
for f in sorted(glob.glob(os.path.join(ROOT, "*", "*.json"))):
    v = os.path.basename(os.path.dirname(f)); vendors.add(v)
    for it in json.load(open(f, encoding="utf-8")):
        rc = it.get("regulative_components") or {}
        per[v].append({
            "class": it.get("class"),
            "stmt": (it.get("full_statement") or ""),
            "D": norm(rc.get("D")),
            "A": norm(rc.get("A")),
            "I": norm(rc.get("I")),
            "B": norm(rc.get("B")),
            "C": norm(rc.get("C")),
        })
vendors = sorted(vendors)

# ---------- 候选口径 ----------
def loci_S0(v):  # 原始 Aim 自由文本
    return {it["I"] for it in per[v] if it["class"] == "regulative" and it["I"]}

def loci_S1(v):  # 受控动词（去否定、词干化、映射）
    return {canon_verb(it["I"]) for it in per[v] if it["class"] == "regulative" and canon_verb(it["I"])}

def loci_S2(v):  # 受控动词 × 否定位
    out = set()
    for it in per[v]:
        if it["class"] != "regulative": continue
        cv = canon_verb(it["I"])
        if not cv: continue
        neg = "N" if NEG.match(norm(it["I"])) or norm(it["I"]).startswith("not ") else "P"
        out.add(f"{cv}|{neg}")
    return out

def loci_S3(v):  # 23 维存在集（我们上一轮的先验）
    g = RD["genome"].get(v, {})
    return {d for d, st in g.items() if st != "absent"}

def loci_S4(v):  # 受控动词 × 否定 × 条件位
    out = set()
    for it in per[v]:
        if it["class"] != "regulative": continue
        cv = canon_verb(it["I"])
        if not cv: continue
        neg = "N" if NEG.match(norm(it["I"])) else "P"
        cond = "C" if it["C"] else "-"
        out.add(f"{cv}|{neg}|{cond}")
    return out

def loci_S5(v):  # 受控动词 × 条件位
    out = set()
    for it in per[v]:
        if it["class"] != "regulative": continue
        cv = canon_verb(it["I"])
        if not cv: continue
        out.add(f"{cv}|{'C' if it['C'] else '-'}")
    return out

def loci_S6(v):  # 受控动词 × 对象粗主题（首词）
    out = set()
    for it in per[v]:
        if it["class"] != "regulative": continue
        cv = canon_verb(it["I"])
        if not cv: continue
        t = obj_theme(it["B"])
        out.add(f"{cv}|{t.split()[0] if t else '-'}")
    return out

SCHEMES = [
    ("S0 原始 Aim 自由文本", loci_S0),
    ("S1 受控动词（去否定+词干）", loci_S1),
    ("S2 受控动词 × 否定", loci_S2),
    ("S3 23 维存在集（上一轮先验）", loci_S3),
    ("S4 受控动词 × 否定 × 条件", loci_S4),
    ("S5 受控动词 × 条件", loci_S5),
    ("S6 受控动词 × 对象首词", loci_S6),
]

def jac(a, b):
    u = len(a | b)
    return len(a & b) / u if u else 0.0

def eval_scheme(name, fn):
    sets = {v: fn(v) for v in vendors}
    allv = set().union(*sets.values())
    js = []
    for a, b in itertools.combinations(vendors, 2):
        js.append(jac(sets[a], sets[b]))
    # 共有位点统计
    cnt = collections.Counter()
    for v in vendors:
        for l in sets[v]: cnt[l] += 1
    ge = {k: sum(1 for l, c in cnt.items() if c >= k) for k in (3, 5, 8, 10, 12, 14)}
    # Null：打乱厂商标签（保留边际）
    nulls = []
    for _ in range(200):
        perm = vendors[:]; random.shuffle(perm)
        s2 = {v: sets[perm[i]] for i, v in enumerate(vendors)}
        nulls.append(sum(jac(s2[a], s2[b]) for a, b in itertools.combinations(vendors, 2)) / len(js))
    nulls.sort()
    obs = sum(js) / len(js)
    p = sum(1 for n in nulls if n >= obs) / len(nulls)
    return dict(name=name, loci=len(allv), mean_j=obs, med_j=sorted(js)[len(js)//2],
                max_j=max(js), null_med=nulls[len(nulls)//2], null_p95=nulls[int(.95*len(nulls))],
                p=p, ge=ge,
                per_vendor={v: len(sets[v]) for v in vendors})

print(f"厂商 {len(vendors)} 家\n")
print(f"{'口径':<28}{'位点数':>7}{'J均值':>8}{'J中位':>8}{'J最大':>8}{'Null中位':>9}{'Null95':>8}{'p':>7}  ≥K家共有")
results = []
for name, fn in SCHEMES:
    r = eval_scheme(name, fn); results.append(r)
    ge = r["ge"]
    print(f"{r['name']:<28}{r['loci']:>7}{r['mean_j']:>8.3f}{r['med_j']:>8.3f}{r['max_j']:>8.3f}"
          f"{r['null_med']:>9.3f}{r['null_p95']:>8.3f}{r['p']:>7.3f}  "
          + " ".join(f"≥{k}:{ge[k]}" for k in (3, 5, 8, 10, 12, 14)))

print("\n=== 各口径下「≥8 家共有」的位点明细 ===")
for name, fn in SCHEMES:
    sets = {v: fn(v) for v in vendors}
    cnt = collections.Counter()
    for v in vendors:
        for l in sets[v]: cnt[l] += 1
    core = [l for l, c in cnt.items() if c >= 8]
    if core:
        print(f"\n{name}  ({len(core)} 个)")
        for l in sorted(core, key=lambda x: -cnt[x])[:18]:
            print(f"    {cnt[l]:>2}家  {l[:70]}")

print("\n=== 口径内部离散度（每家位点数） ===")
for r in results:
    pv = r["per_vendor"]
    print(f"{r['name']:<28} " + " ".join(f"{v[:4]}:{n}" for v, n in pv.items()))
