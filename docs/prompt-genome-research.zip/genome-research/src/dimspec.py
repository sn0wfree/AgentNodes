# -*- coding: utf-8 -*-
"""按「章节」判定强制措辞 → 每个维度拿到 (覆盖广度 × 强制度) → 写作规范四象限"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
import os,re,json,collections,statistics
exec(open(os.path.join(HERE,'genome_lib.py')).read())
ROOT=os.environ.get('CL4R1T4S_DIR') or os.path.join(ROOT_DIR,'CL4R1T4S-main')
D=json.load(open(os.path.join(DATA_DIR, 'final_genome.json')))
LOCI=D['LOCI']; byv=D['byv']
MARK=re.compile(r"(must never|must not|MUST NOT|never\b|regardless of|under no circumstances|no exceptions|without exception|not permitted|prohibited|forbidden|highest priority|highest-priority|only from|not commands|treat as data|even if|shall not|cannot be overridden|inviolable|mandatory|always\b|required to|you must\b|do not\b)",re.I)
def sections(text):
    """切段：markdown 标题 或 语义化 XML 标签行 → [(marker_line_no, marker_text, body_lines)]"""
    lines=text.splitlines(); marks=[]
    for i,ln in enumerate(lines):
        m=re.match(r'^#{1,6}\s+(.+)$',ln)
        if m: marks.append((i,m.group(1))); continue
        for tm in re.finditer(r'<([a-z][a-z0-9_]{2,40})[ />]',ln):
            tag=tm.group(1).lower()
            if tag in HTMLISH: continue
            marks.append((i,tag.replace('_',' '))); break
    out=[]
    for k,(i,txt) in enumerate(marks):
        end=marks[k+1][0] if k+1<len(marks) else len(lines)
        out.append((i,txt,lines[i+1:end]))
    return out
# 逐文件：位点 → 是否有「强制型章节」
FILE_ENF={}
for rel,d in D['byv'].items() if False else []:
    pass
for rel in [r for v in byv for r in byv[v]]:
    t=open(os.path.join(ROOT,rel),encoding='utf-8',errors='replace').read()
    secs=sections(t); fe={}
    for b,rx in RX.items():
        struct_sec=None
        for (i,txt,body) in secs:
            if rx.search(txt.lower()):
                struct_sec=(txt,body); break
        if struct_sec is None: continue
        txt,body=struct_sec
        blob=txt+" "+" ".join(body[:80])
        if MARK.search(blob): fe[b]=True
    FILE_ENF[rel]=fe
# 厂商级：任一文件强制 ⇒ 该厂商该维度为强制
ENF={}
for v,files in byv.items():
    ENF[v]={b: any(FILE_ENF.get(f,{}).get(b,False) for f in files) for b in LOCI}
# 维度指标
SPEC=[]
for b in LOCI:
    nstruct=[v for v in byv if D['genome'][v][b]=='struct']
    ncont=[v for v in byv if D['genome'][v][b]=='content']
    covered=nstruct+ncont
    enf=[v for v in covered if ENF[v][b]]
    tier='T0' if b in D['T0'] else ('T2' if b in D['T2'] else 'T1')
    SPEC.append({'locus':b,'tier':tier,'n_struct':len(nstruct),'n_content':len(ncont),
      'n_covered':len(covered),'n_absent':len(byv)-len(covered),
      'coverage':len(covered)/len(byv),
      'n_enforced':len(enf),'enf_rate':(len(enf)/len(covered)) if covered else 0,
      'struct_v':nstruct,'enf_v':enf,'content_v':ncont})
# 四象限（覆盖 vs 强制率）
for s in SPEC:
    hi_c = s['coverage']>=0.60; hi_e = s['enf_rate']>=0.40
    s['quad'] = ('标准条款' if hi_c else '稀缺硬条款') if hi_e else ('写成了倾向' if hi_c else '无人地带')
SPEC.sort(key=lambda s:(s['tier'],-s['coverage']))
# 每家：Tier0 完整度 / 强制密度
VEND={}
for v in byv:
    t0=[b for b in D['T0'] if D['genome'][v][b]!='absent']
    t0e=[b for b in D['T0'] if ENF[v][b]]
    cov=[b for b in LOCI if D['genome'][v][b]!='absent']
    enfa=[b for b in cov if ENF[v][b]]
    VEND[v]={'t0_cov':len(t0),'t0_enforced':len(t0e),'cov':len(cov),
             'enforced':len(enfa),'enf_rate':(len(enfa)/len(cov)) if cov else 0,
             'n_files':len(byv[v])}
json.dump({'SPEC':SPEC,'ENF':ENF,'VEND':VEND,'FILE_ENF':FILE_ENF},open(os.path.join(DATA_DIR, 'dimspec.json'),'w'),ensure_ascii=False)
print("="*112); print("维度写作规范表（覆盖广度 × 强制度）"); print("="*112)
print(f"{'Tier':<5}{'维度':<22}{'成节':>4}{'正文':>4}{'缺位':>4}{'覆盖':>7}{'强制家数':>8}{'强制率':>7}  象限")
for s in sorted(SPEC,key=lambda x:(-x['coverage'])):
    print(f"{s['tier']:<5}{s['locus']:<22}{s['n_struct']:>4}{s['n_content']:>4}{s['n_absent']:>4}{s['coverage']*100:>6.0f}%{s['n_enforced']:>8}{s['enf_rate']*100:>6.0f}%  {s['quad']}")
print("\n"+"="*112); print("每家：Tier0 完整度 / 强制密度（写作质量的两条独立轴）"); print("="*112)
for v in sorted(VEND,key=lambda x:(-VEND[x]['enf_rate'])):
    d=VEND[v]
    print(f"  {v:<12} Tier0 写到 {d['t0_cov']}/5  其中强制 {d['t0_enforced']} ｜ 全维度写到 {d['cov']:>2}/23  强制 {d['enforced']:>2} ({d['enf_rate']*100:>3.0f}%)")
