# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
import json,collections,statistics,itertools,os
D=json.load(open(os.path.join(DATA_DIR, 'final_genome.json')))
LOCI=D['LOCI'];ORDER=D['ORDER'];T0=D['T0'];T1=D['T1'];T2=D['T2']
genome=D['genome'];peak=D['peak'];peakfile=D['peakfile'];byv=D['byv']
V=sorted(genome); Dp=D['DP']
cov={};t0c={};t1c={}
for v in V:
    cov[v]={'present':sum(1 for b in LOCI if genome[v][b]!='absent'),
            'struct':sum(1 for b in LOCI if genome[v][b]=='struct'),
            'peak_struct':sum(1 for b in LOCI if peak[v][b]=='struct'),
            'peak_present':sum(1 for b in LOCI if peak[v][b]!='absent'),
            'files':len(byv[v]),
            'bytes':sum(os.path.getsize(os.path.join(os.environ.get('CL4R1T4S_DIR') or os.path.join(ROOT_DIR,'CL4R1T4S-main'), r)) for r in byv[v])}
    t0c[v]=sum(1 for b in T0 if genome[v][b]!='absent')
    t1c[v]=sum(1 for b in T1 if genome[v][b]!='absent')
PRIO=[]
for b in LOCI:
    st=[v for v in V if genome[v][b]=='struct']; ab=[v for v in V if genome[v][b]=='absent']
    PRIO.append({'locus':b,'tier':'T0' if b in T0 else ('T2' if b in T2 else 'T1'),
      'n_struct':len(st),'n_content':len([v for v in V if genome[v][b]=='content']),
      'n_absent':len(ab),'impl':st,'gap':ab,
      'coverage':round(sum(1 for v in V if genome[v][b]!='absent')/len(V),4),
      'priority':len(ab)*len(st)})
PRIO.sort(key=lambda x:(-x['priority'],-x['coverage']))
NN={}
for v in V:
    nn=sorted(((Dp[v][u],u) for u in V if u!=v))[:3]
    NN[v]=[{'v':u,'d':round(d,3)} for d,u in nn]
out={'LOCI':LOCI,'ORDER':ORDER,'T0':T0,'T1':T1,'T2':T2,'seqs':D['seqs'],'pseqs':D['pseqs'],
 'genome':genome,'peak':peak,'peakfile':peakfile,'cov':cov,'t0c':t0c,'t1c':t1c,
 'consv':D['consv'],'divs':D['divs'],'alld':D['alld'],'D':D['D'],'DP':Dp,'CL':D['CL'],
 'INV':D['INV'],'ENF':D['ENF'],'uniq':D['uniq'],'PRIO':PRIO,'NN':NN,'byv':byv}
json.dump(out,open(os.path.join(DATA_DIR, 'report_data.json'),'w'),ensure_ascii=False)
print("厂商 | 文件 | 字节 | 并集覆盖(存在/成节) | 峰值文件(成节/存在) | Tier0 覆盖 | Tier1 覆盖")
for v in sorted(V,key=lambda x:-cov[x]['present']):
    c=cov[v]
    print(f"{v:<12}| {c['files']:>2} | {c['bytes']/1024:>7.0f}KB | {c['present']:>2}/23 ({c['struct']:>2}成节) | {c['peak_struct']:>2}/{c['peak_present']:>2} | {t0c[v]}/5 | {t1c[v]}/16   [{peakfile[v].split('/')[-1][:30]}]")
print("\n提案池（优先级 = 缺口家数 × 已有实现家数）:")
for p in PRIO[:14]:
    print(f"  [{p['tier']}] {p['locus']:<20} 成节{p['n_struct']:>2} 正文{p['n_content']:>2} 缺位{p['n_absent']:>2} 覆盖{p['coverage']*100:>5.1f}% 分{p['priority']:>3}  实现: {', '.join(p['impl'][:6]) or '—'}")
print("\n最近邻:")
for v in V: print(f"  {v:<12} "+", ".join(f"{x['v']}({x['d']})" for x in NN[v]))
