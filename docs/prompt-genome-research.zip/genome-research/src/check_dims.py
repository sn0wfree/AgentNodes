import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
from playwright.sync_api import sync_playwright
import json
URL='file://' + os.path.join(ROOT_DIR,'figures','03-dimension-spec','index.html')
R=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for name,vw,vh in [("desktop",1440,900),("mobile",390,844)]:
        pg=br.new_page(viewport={'width':vw,'height':vh}); errs=[]
        pg.on('console',lambda m: errs.append(f"{m.type}: {m.text}") if m.type in ('error','warning') else None)
        pg.on('pageerror',lambda ex: errs.append(f"pageerror: {ex}"))
        pg.goto(URL,wait_until='networkidle'); pg.wait_for_timeout(1200)
        r=pg.evaluate("""()=>{const de=document.documentElement;
          const inSc=el=>{let p=el.parentElement;while(p&&p!==document.body){const s=getComputedStyle(p);
            if(['auto','scroll','hidden'].includes(s.overflowX)||s.overflow==='hidden')return true;p=p.parentElement;}return false;};
          const over=[...document.querySelectorAll('*')].filter(el=>{const b=el.getBoundingClientRect();
            return b.width>0&&(b.right>de.clientWidth+1.5||b.left<-1.5)&&!inSc(el);}).slice(0,8).map(el=>el.tagName+'.'+(el.className||'').toString().slice(0,36));
          return {sw:de.scrollWidth,cw:de.clientWidth,sh:de.scrollHeight,over:[...new Set(over)],
            txt:document.body.innerText, cards:document.querySelectorAll('.dcard').length,
            circles:document.querySelectorAll('.quad circle').length, rows:document.querySelectorAll('.bench-row').length,
            scards:document.querySelectorAll('.scard').length, checks:document.querySelectorAll('.clean li').length};}""")
        txt=r.pop('txt')
        R.append({'view':name,'overflow_px':r['sw']-r['cw'],'over':r['over'],'console':errs,
                  'md':'**' in txt or '`' in txt,'cards':r['cards'],'points':r['circles'],
                  'bench':r['rows'],'struct':r['scards'],'checks':r['checks'],'h':r['sh']})
        pg.screenshot(path=os.path.join(ROOT_DIR,"figures","03-dimension-spec","_s_%s.png"%name)); pg.close()
    br.close()
print(json.dumps(R,ensure_ascii=False,indent=1))
print("\nVERDICT:", "PASS" if all(x['overflow_px']<=1 and not x['over'] and not x['console'] and not x['md'] for x in R) else "FAIL")
