#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E8：控制覆盖广度后的结构检验 + 簇的真实含义 + 共识序。

E7 结论：存在集 Jaccard 的结构是真实的（方差 p<0.001），不是伪结构。
但「J 的数值 96% 由集合大小决定」也成立（组内方差/总体方差 = 0.038）。
两者不矛盾：大小决定「相似度的量级」，位点身份决定「谁跟谁更近」。
本脚本做最严格版本：把广度差分层，只看广度相近的对，结构是否还在。
"""
import json, collections, itertools, random, math
from genome_lib import LOCI, RX

RD = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding="utf-8"))
G = RD["genome"]; V = sorted(G)
random.seed(20261118)
def jac(a, b):
    u = len(a | b); return len(a & b)/u if u else 0.0
def var(v):
    m = sum(v)/len(v); return sum((x-m)**2 for x in v)/len(v)

sets = {v: {d for d in LOCI if G[v].get(d, "absent") != "absent"} for v in V}
support = collections.Counter()
for v in V:
    for d in sets[v]: support[d] += 1
pairs = list(itertools.combinations(V, 2))
js = {(a, b): jac(sets[a], sets[b]) for a, b in pairs}

# ---------- 1. 按「广度差」分层 ----------
print("=== 1. 控制覆盖广度：只看广度相近的厂商对 ===")
print(f"{'广度差':>6}{'对数':>6}{'实测J均值':>11}{'null均值':>10}{'null95':>9}{'p':>8}")
for lo, hi in [(0, 0), (1, 1), (2, 2), (3, 5), (6, 99)]:
    sub = [(a, b) for a, b in pairs if lo <= abs(len(sets[a]) - len(sets[b])) <= hi]
    if len(sub) < 5: continue
    obs = [js[p] for p in sub]
    nulls = []
    for _ in range(300):
        S2 = {}
        for v in V:
            k = len(sets[v])
            pool = []
            for d in LOCI: pool += [d]*support[d]
            S2[v] = set(random.sample(pool, k))
        nulls.append(sum(jac(S2[a], S2[b]) for a, b in sub)/len(sub))
    nulls.sort()
    o = sum(obs)/len(obs)
    print(f"{f'{lo}-{hi}':>6}{len(sub):>6}{o:>11.3f}{nulls[len(nulls)//2]:>10.3f}"
          f"{nulls[int(.95*len(nulls))]:>9.3f}{sum(1 for x in nulls if x >= o)/len(nulls):>8.3f}")

# ---------- 2. 广度完全相同的厂商之间 ----------
print("\n=== 2. 广度完全相同的厂商组内，谁跟谁最像（纯身份信号） ===")
bysize = collections.defaultdict(list)
for v in V: bysize[len(sets[v])].append(v)
for sz in sorted(bysize, reverse=True):
    grp = bysize[sz]
    if len(grp) < 2: continue
    sub = [(a, b) for a, b in itertools.combinations(grp, 2)]
    if not sub: continue
    obs = sorted(((js[p], p) for p in sub), reverse=True)
    nulls = []
    for _ in range(200):
        S2 = {}
        for v in V:
            k = len(sets[v]); pool = []
            for d in LOCI: pool += [d]*support[d]
            S2[v] = set(random.sample(pool, k))
        nulls.append(sum(jac(S2[a], S2[b]) for a, b in sub)/len(sub))
    nulls.sort()
    o = sum(x for x, _ in obs)/len(obs)
    print(f"  广度 {sz:>2}（{len(grp)}家）实测J均值 {o:.3f}  null {nulls[len(nulls)//2]:.3f}  "
          f"p={sum(1 for x in nulls if x >= o)/len(nulls):.3f}")
    for x, (a, b) in obs[:3]:
        extra = sets[a] ^ sets[b]
        print(f"      最像 {a} ∩ {b} = {len(sets[a]&sets[b])}/{len(sets[a]|sets[b])}"
              f"   差异位点: {', '.join(sorted(extra)) or '—'}")

# ---------- 3. 上一轮 k=3 簇的真实含义 ----------
print("\n=== 3. 上一轮 k=3 簇到底按什么分开？ ===")
CL = RD["CL"]["3"]["labels"]
grp = collections.defaultdict(list)
for v, c in CL.items(): grp[c].append(v)
for c in sorted(grp):
    vs = sorted(grp[c])
    print(f"\n  簇{c}（{len(vs)}家）: {', '.join(vs)}")
    # 该簇共有的区分性位点
    allv = set(LOCI)
    for v in vs: allv &= sets[v]
    rare = sorted(allv, key=lambda d: support[d])
    print(f"     簇内全体共有 {len(allv)} 个位点；其中最稀有的 5 个："
          f"{', '.join(f'{d}({support[d]}家)' for d in rare[:5])}")
    # 该簇之外谁还共享这些稀有位点
    for d in rare[:3]:
        outside = [v for v in V if v not in vs and d in sets[v]]
        print(f"       {d} 在簇外的持有者: {', '.join(outside) if outside else '—'}")

# ---------- 4. 共识序：按支持度排序的位点骨架 ----------
print("\n=== 4. 共识序骨架（位点按跨厂商支持度排序） ===")
order = sorted(LOCI, key=lambda d: -support[d])
print("  " + " → ".join(f"{d}({support[d]})" for d in order))
print("\n  ★ 这条序不需要「成对先后归一 + 相邻交换修复」那套：")
print("    位点支持度本身就是共识度的直接度量，且可复算。")

# ---------- 5. 区分力集中在哪 ----------
print("\n=== 5. 区分力集中度：前 5 个位点解释了多少两两差异 ===")
disc = sorted(LOCI, key=lambda d: support[d])[:5]
print(f"  最稀有的 5 个位点: {', '.join(f'{d}({support[d]})' for d in disc)}")
sub_all = list(itertools.combinations(V, 2))
def jacc_on(ds):
    return sum(jac(sets[a] & set(ds), sets[b] & set(ds)) for a, b in sub_all)/len(sub_all)
allj = jacc_on(LOCI)
corej = jacc_on(disc)
print(f"  全部 23 位点上两两 J 均值 {allj:.3f}")
print(f"  只用这 5 个位点   两两 J 均值 {corej:.3f}")
print(f"  ⇒ 用 5/23 的位点保留了 {corej/allj*100:.0f}% 的两两共享信息量")
