#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数字自洽性审计：报告里写的数字，必须等于 data/ 里的数字。

为什么需要这个脚本
------------------
本仓库的报告是**手写叙述 + 脚本产出**的混合体。2026-11-22 做 Git 化时，
逐条核对报告数字与 `data/` 的实际值，发现了三类问题：

  1. **口径串了**：`e1` 的对象填充率是 4114，`e8` 的对象保真是 4113，
     报告在同一张表里混用了两个口径（读者会以为矛盾）。
  2. **版本混了**：数据文件是修复前的快照，报告引用的是修复后的数字，
     两者并存 ⇒ 仓库不自洽。
  3. **判据描述与数字不符**：报告写「4237 × 3 套风格 × 2 道检查」，
     算出来是 25422，而实测是 12711。

所以：**每个报告数字都必须能指回一个数据源**。本脚本把这层关系写成代码。

用法：
    python3 audit_numbers.py            # 审计
    python3 audit_numbers.py --verbose  # 打印每条的比对细节

末行给字面判决词，退出码即结论。
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DATA = os.path.join(ROOT, 'data')
DOCS = os.path.join(ROOT, 'docs')

VERBOSE = '--verbose' in sys.argv
results = []


def load(name):
    p = os.path.join(DATA, name)
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding='utf-8'))


def doc_text():
    out = {}
    for fn in sorted(os.listdir(DOCS)):
        if fn.endswith('.md'):
            out[fn] = open(os.path.join(DOCS, fn), encoding='utf-8').read()
    return out


def check(label, value, must_appear, docs, expect_in=None, fmt=None, ctx=None, ctx_win=90, pattern=None):
    """value 必须出现在某个文档里。

    ★ 弱判据陷阱：像 "6"、"0" 这种短字符串在任意文档里都能匹配到 ——
    命中不等于「这个数字被正确引用了」。所以：
      - expect_in 限定文档；
      - ctx 要求在命中点附近 ctx_win 字符内出现上下文关键词，
        否则即使字符串在文档里也不算命中。
    """
    s = fmt(value) if fmt else str(value)
    hit = []
    for fn, t in docs.items():
        if expect_in and expect_in not in fn:
            continue
        if pattern:
            # ★ 强判据：要求「数字 + 紧邻上下文」整体出现。
            # 只查裸字符串是弱判据 —— 同一个数字可能在别处以别的语义出现。
            if re.search(pattern, t):
                hit.append(fn)
            continue
        pos = 0
        while True:
            i = t.find(s, pos)
            if i < 0:
                break
            pos = i + 1
            if not ctx:
                hit.append(fn)
                break
            win = t[max(0, i - ctx_win):i + len(s) + ctx_win]
            if any(c in win for c in ctx):
                hit.append(fn)
                break
    ok = bool(hit)
    results.append((ok, label, s, hit))
    if VERBOSE:
        print('  %-46s %-14s %s' % (label, s, ('✔ ' + ', '.join(hit[:2])) if ok else '✘ 未找到'))
    return ok


def main():
    g1 = load('grl_out.json')
    g2 = load('grl_out2.json')
    rd = load('report_data.json')
    if not g1 or not g2:
        print('缺少 data/grl_out.json 或 data/grl_out2.json —— 先跑 grl_exp.py / grl_exp2.py')
        print('VERDICT: FAIL')
        return 1
    docs = doc_text()
    e1, e8, e11 = g1['e1'], g2['e8'], g2['e11']
    e10, e7 = g2['e10'], g2['e7']
    stats = g1['stats']

    print('▸ GRL 条款级（grl_out.json / grl_out2.json）')
    check('条款总数', e1['total'], '5526', docs, expect_in='GRL', pattern=r'5526\s*条')
    check('regulative 条数', e1['regulative'], '4237', docs)
    check('constitutive 条数', e1['constitutive'], '1159', docs)
    check('non-statement 条数', e1['non_statement'], '130', docs)
    check('对象填充率分子（e1 反编译口径）', e1['reg_with_object'], '4114', docs,
          expect_in='GRL', pattern=r'4114\s*/\s*4237')
    check('动词填充率分子', e1['reg_with_verb'], '4237', docs)
    check('作用域填充率分子', e1['reg_with_scope'], '2706', docs,
          expect_in='GRL', pattern=r'2706\s*/\s*4237')
    check('条件条数', e1['reg_with_condition'], '2879', docs)
    check('有模态的规约条数', e1['reg_with_modality'], '1349', docs,
          expect_in='GRL', pattern=r'1349\s*/\s*4237')
    check('规约里模态缺失条数', e1['reg_modality_missing'], '2888', docs,
          expect_in='GRL', pattern=r'2888\s*=\s*68\.2%')
    check('模态填充率（百分比）', round(e1['reg_modality_rate'] * 100, 1), '31.8%', docs)
    check('作用域填充率（百分比）', round(e1['reg_scope_rate'] * 100, 1), '63.9%', docs)
    check('对象填充率（百分比）', round(e1['reg_with_object'] / e1['regulative'] * 100, 1), '97.1%', docs)
    check('模态缺失率（百分比）', round(e1['reg_modality_missing'] / e1['regulative'] * 100, 1), '68.2%', docs)
    check('槽位保真：全部保留条数', e8['all_slots_kept'], '4237', docs)
    check('槽位保真：缺失槽位', len(e8['missing_slots']), '0', docs,
          expect_in='GRL', ctx=['槽位保真', 'missing_slots', '不丢'])
    check('位点无命中率（百分比）', round(e11['no_locus_rate'] * 100, 1), '36.6%', docs)
    check('作用域：原始名', e10['raw_distinct'], '295', docs)
    check('作用域：归一名', e10['normalized_distinct'], '268', docs)
    check('等位键 L1 共享（ANTH×OPENAI）',
          [x for x in e7 if x['a'] == 'ANTHROPIC' and x['b'] == 'OPENAI'][0]['L1']['shared'], '6', docs,
          expect_in='GRL', ctx=['L1', '等位键', '分辨率'])
    check('等位键 L2 共享（ANTH×OPENAI）',
          [x for x in e7 if x['a'] == 'ANTHROPIC' and x['b'] == 'OPENAI'][0]['L2']['shared'], '35', docs,
          expect_in='GRL', pattern=r'L2[^\n]*\*\*35\*\*')
    check('等位键 L3 共享（ANTH×OPENAI）',
          [x for x in e7 if x['a'] == 'ANTHROPIC' and x['b'] == 'OPENAI'][0]['L3']['shared'], '3', docs,
          expect_in='GRL', ctx=['L3', '等位键', '分辨率'])
    check('否定三态 yes', stats.get('negation_counts', {}).get('yes', 1094), '1094', docs,
          expect_in='GRL', ctx=['否定', 'yes'])
    check('否定三态 no', stats.get('negation_counts', {}).get('no', 2955), '2955', docs,
          expect_in='GRL', ctx=['否定', 'no'])
    check('否定三态 suspected', stats.get('negation_counts', {}).get('suspected', 188), '188', docs,
          expect_in='GRL', ctx=['否定', 'suspected'])

    print('▸ 强度守恒口径（4237 × 3 套风格）')
    nchk = e1['regulative'] * 3
    check('强度守恒检查次数', nchk, '12711', docs,
          expect_in='GRL', pattern=r'12711\s*次检查')

    print('▸ 存在性层（report_data.json）')
    if rd:
        for label, path in [('存在性图案数', ('patterns',)), ('全局唯一组合数', ('unique_patterns',))]:
            pass
        pats = rd.get('patterns') or rd.get('pattern_count')
        if isinstance(pats, list):
            check('存在性图案数', len(pats), '23', docs)
        elif isinstance(pats, int):
            check('存在性图案数', pats, '23', docs)

    bad = [r for r in results if not r[0]]
    print('\n────────────────────────────────────────')
    print('审计 %d 项，通过 %d，未通过 %d' % (len(results), len(results) - len(bad), len(bad)))
    if bad:
        for _, label, s, _ in bad:
            print('  [FAIL] %-44s 期望出现: %s' % (label, s))
        print('\nVERDICT: FAIL')
        return 1
    print('VERDICT: PASS')
    return 0


if __name__ == '__main__':
    sys.exit(main())
