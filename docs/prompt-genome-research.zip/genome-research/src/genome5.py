# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
import os,re,json,collections,math,itertools,statistics
exec(open(os.path.join(HERE,'genome_lib.py')).read())
ROOT=os.environ.get('CL4R1T4S_DIR') or os.path.join(ROOT_DIR,'CL4R1T4S-main')
G=json.load(open(os.path.join(DATA_DIR, 'genome.json')))
LOCI=G['LOCI']; ORDER=G['ORDER']; REP=G['rep']; V=sorted(REP)
F=json.load(open(os.path.join(DATA_DIR, 'loci_files.json')))
for rel,d in F.items():
    seen=[]
    for b in d['seq']:
        if b not in seen: seen.append(b)
    d['order']=seen; d['struct']=seen; d.setdefault('content',[])
# ① 全 80 文件的基因组
GEN={rel:{'vendor':d['vendor'],'size':d['size'],'order':d['order'],
          'allele':{b:('struct' if b in d['order'] else 'content' if b in d['content'] else 'absent') for b in LOCI}}
      for rel,d in F.items()}
# ② 时间轴（手工年代序）
CHRONO={
 'OPENAI':['GPT-4.5_02-27-25.md','ChatGPT_o3_o4-mini_04-16-2025','ChatGPT_4o_04-25-2025.txt','ChatGPT_4.1_05-15-2025.txt',
   'ChatGPT5-08-07-2025.mkd','Codex_Sep-15-2025.md','ChatGPT-4o_Sep-27-25.txt','Codex.md','Atlas_10-21-25.txt',
   'ChatKit_Docs__Oct-6-25.txt','GPT-6-Astra_Prompts.md','GPT-6-Sol_Prompts.txt','5.6-Sol_SystemPrompt.md'],
 'ANTHROPIC':['Claude_Code_03-04-24.md','Claude_Sonnet_3.5.md','Claude_Sonnet_3.7_New.txt','Claude_4.txt','Claude-4.1.txt',
   'Claude-Design-Sys-Prompt.txt','Claude_Sonnet-4.5_Sep-29-2025.txt','Claude-4.5-Opus.txt','Claude_Opus_4.6.txt',
   'Claude-Opus-4.7.txt','OPUS-5.md','Claude-Fable-5.1.md','CLAUDE-FABLE-5.md','CLAUDE-OPUS-5.5.md',
   'CLAUDE-CODE-FABLE-5.2.txt','CLAUDE-WEB-APP-FABLE-5.2.md'],
 'XAI':['Grok3.md','Grok3_updated_07-08-2025.md','Grok4-July-10-2025.md','GROK-4-NEW_Jul-13-2025',
   'Grok-Code-Fast-1_Aug-26-2025.txt','GROK-4.1_Nov-17-2025.txt','GROK-4.20.mkd'],
 'DEVIN':['Devin_2.0.md','Devin_2.0_Commands.md','Devin2_09-08-2025.md'],
 'GOOGLE':['Gemini_Diffusion.md','Gemini_Gmail_Assistant.txt','Gemini-2.5-Pro-04-18-2025.md'],
 'CURSOR':['Cursor_Prompt.md','Cursor_Tools.md','Cursor_2.0_Sys_Prompt.txt'],
 'REPLIT':['Replit_Functions.md','Replit_Initial_Code_Generation_Prompt.md','Replit_Agent.md'],
 'ZCode':['Tools.json','Prompts.md','Skills.md'],
}
def find(v,name):
    for rel in F:
        if F[rel]['vendor']==v and os.path.basename(rel)==name: return rel
    return None
TL={}
for v,names in CHRONO.items():
    rows=[]
    for n in names:
        rel=find(v,n)
        if not rel: continue
        g=GEN[rel]; rows.append({'file':rel,'name':n,'size':g['size'],
            'loci':[b for b in LOCI if g['allele'][b]!='absent'],
            'struct':[b for b in LOCI if g['allele'][b]=='struct'],
            'sig':''.join({'struct':'█','content':'▄','absent':'·'}[g['allele'][b]] for b in ORDER)})
    for i in range(1,len(rows)):
        a=set(rows[i-1]['loci']); b=set(rows[i]['loci'])
        rows[i]['gained']=sorted(b-a); rows[i]['lost']=sorted(a-b)
    TL[v]=rows
# ③ 家族：k-medoids + 距离谱找间隙
D=G['D']
allpairs=sorted((D[a][b],a,b) for a,b in itertools.combinations(V,2))
gaps=[(allpairs[i+1][0]-allpairs[i][0],allpairs[i][0],allpairs[i+1][0]) for i in range(len(allpairs)-1)]
big=sorted(gaps,reverse=True)[:4]
def kmed(k,iters=200):
    med=[allpairs[i][1] for i in range(k)]
    for _ in range(iters):
        lab={}
        for v in V:
            lab[v]=min(range(k),key=lambda i:D[v][med[i]])
        for i in range(k):
            mem=[v for v in V if lab[v]==i]
            if mem:
                best=min(itertools.combinations(mem,2),key=lambda p:D[p[0]][p[1]])[0]
                med[i]=best
        lab={v:min(range(k),key=lambda i:D[v][med[i]]) for v in V}
    return {v:lab[v] for v in V},med
CLUSTS={}
for k in (3,4,5):
    lab,med=kmed(k); CLUSTS[k]={'labels':lab,'medoids':med,
      'groups':sorted([sorted([v for v in V if lab[v]==i]) for i in range(k)],key=len,reverse=True)}
# ④ 对照组：同厂商跨版本相似度 vs 跨厂商相似度
TOK=re.compile(r'[a-z][a-z0-9_]{2,}')
STOP=set('the and for with that this are you your not but all any can will would should must may have has been was were its from they them their what when where which who how use used using more most other some such only own same than then each into out about after before between during above below off over under again further once here there because while against'.split())
def ftext(rel):
    t=open(os.path.join(ROOT,rel),encoding='utf-8',errors='replace').read()
    return [w for w in TOK.findall(t.lower()) if w not in STOP]
PROMPTS={rel:ftext(rel) for rel in F if not rel.endswith('.json') and F[rel]['size']>1500}
def cos(a,b):
    ca,cb=collections.Counter(a),collections.Counter(b)
    if not ca or not cb: return None
    common=set(ca)&set(cb)
    num=sum(ca[w]*cb[w] for w in common); na=math.sqrt(sum(x*x for x in ca.values())); nb=math.sqrt(sum(x*x for x in cb.values()))
    return num/(na*nb) if na and nb else None
within=[];across=[]
for r1,r2 in itertools.combinations(PROMPTS,2):
    s=cos(PROMPTS[r1],PROMPTS[r2])
    if s is None: continue
    (within if F[r1]['vendor']==F[r2]['vendor'] else across).append(s)
out={'GEN':GEN,'TL':TL,'CLUSTS':CLUSTS,'gaps':big,'allpairs':allpairs[:40],
     'within':{'n':len(within),'median':statistics.median(within) if within else None,
               'p90':sorted(within)[int(len(within)*0.9)] if within else None},
     'across':{'n':len(across),'median':statistics.median(across) if across else None,
               'p90':sorted(across)[int(len(across)*0.9)] if across else None},
     'chronology':CHRONO}
json.dump(out,open(os.path.join(DATA_DIR, 'genome2.json'),'w'),ensure_ascii=False)
print("="*96); print("距离谱最大间隙（决定家族数）"); print("="*96)
for g,a,b in big: print(f"  间隙 {g:.3f}  位于 {a:.3f} → {b:.3f}")
for k in (3,4,5):
    print(f"\n--- k={k} ---")
    for i,g in enumerate(CLUSTS[k]['groups'],1):
        if not g: continue
        med=CLUSTS[k]['medoids'][CLUSTS[k]['labels'][g[0]]]
        sd=statistics.mean([sum(1 for b in LOCI if GEN[REP[v]]['allele'][b]=='struct')/max(1,sum(1 for b in LOCI if GEN[REP[v]]['allele'][b]!='absent')) for v in g])
        print(f"  组{i} (n={len(g)}, medoid={med}, 平均结构化密度={sd:.2f}): "+", ".join(g))
print("\n"+"="*96); print("对照组：同厂商跨版本 vs 跨厂商 全文字符 TF 余弦"); print("="*96)
print(f"  同厂商内 (n={out['within']['n']}): 中位 {out['within']['median']:.4f}  p90 {out['within']['p90']:.4f}")
print(f"  跨厂商   (n={out['across']['n']}): 中位 {out['across']['median']:.4f}  p90 {out['across']['p90']:.4f}")
print("\n"+"="*96); print("时间轴（按年代序）"); print("="*96)
for v,rows in TL.items():
    print(f"\n### {v}")
    for r in rows:
        g=f"  +{len(r.get('gained',[]))}/-{len(r.get('lost',[]))}" if r.get('gained') is not None else ""
        print(f"  {r['name'][:34]:<34} {r['size']/1024:>6.0f}KB n={len(r['loci']):>2}{g}")
        if r.get('gained'): print(f"      + 获得: {'、'.join(x[:8] for x in r['gained'])}")
        if r.get('lost'):  print(f"      - 丢失: {'、'.join(x[:8] for x in r['lost'])}")
