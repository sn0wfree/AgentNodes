#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GRL 实测 · 第二轮：修掉第一轮暴露的两个真缺陷。

第一轮暴露：
  (a) E5 编译还原度 mean=5.4% —— 默认模板生成的是「新散文」而非还原原文
      => 度量错了。应当量【槽位保真度】与【风格可替换性】，字符还原度如实报告但改变用途。
  (b) E3/E4 等位键太细（含完整 object_key）=> 跨厂商几乎不共享，等位 diff 失去意义
      => 语法必须规定【多分辨率等位键】：族 / 种 / 个体 三层。

E7 多分辨率等位键：每层的跨厂商共享量
E8 槽位保真度：GRL -> 散文 不丢信息
E9 风格可替换性：同一 GRL 多种文风（数据驱动）
E10 作用域规范化收益
E11 位点自动归属可行性（RX 打标）
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import grl
HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(os.path.dirname(HERE), 'data')
import genome_lib

RULES, STATS = grl.load_corpus()
by_vendor = defaultdict(list)
for r in RULES:
    by_vendor[r.vendor].append(r)
OUT = {}

PAIRS = [('ANTHROPIC', 'OPENAI'), ('ANTHROPIC', 'XAI'), ('OPENAI', 'PERPLEXITY'),
         ('META', 'GOOGLE'), ('HUME', 'MISTRAL'), ('DIA', 'CLUELY'),
         ('MANUS', 'MOONSHOT'), ('MINIMAX', 'MISTRAL')]

# ─────────────────────────────────────────────────────────
# E7 多分辨率等位键
#   L0 族：位点二值存在性            （上一轮已做，26 家 -> 23 图案）
#   L1 种：scope_key + modality      （跨厂商可比的最粗语义层）
#   L2 小：scope_key + modality + verb + negation
#   L3 个：+ object_key              （精确到个体）
# ─────────────────────────────────────────────────────────
def keys_of(rules, level):
    out = set()
    for r in rules:
        if r.cls != 'regulative':
            continue
        if level == 'L1':
            out.add((r.scope_key, r.modality))
        elif level == 'L2':
            out.add((r.scope_key, r.modality, bool(r.negation), r.verb))
        elif level == 'L3':
            out.add((r.scope_key, r.modality, bool(r.negation), r.verb, r.object_key))
    return out

e7 = []
for a, b in PAIRS:
    if a not in by_vendor or b not in by_vendor:
        continue
    row = {'a': a, 'b': b}
    for lv in ('L1', 'L2', 'L3'):
        A, B = keys_of(by_vendor[a], lv), keys_of(by_vendor[b], lv)
        inter = A & B
        row[lv] = {
            'n_a': len(A), 'n_b': len(B), 'shared': len(inter),
            'jaccard': len(inter) / max(1, len(A | B)),
            'coverage_of_b': len(inter) / max(1, len(B)),
        }
    e7.append(row)
OUT['e7'] = e7

# 全厂商 L1 共享矩阵：找出「语义最通用」的 scope（scope 层 = 种层）
all_L1 = defaultdict(set)
for v, rs in by_vendor.items():
    for k in keys_of(rs, 'L1'):
        all_L1[k].add(v)
scope_univ = defaultdict(lambda: {'mods': set(), 'vendors': set()})
for (sk, mod), vs in all_L1.items():
    if not sk:
        continue
    scope_univ[sk]['mods'].add(mod)
    scope_univ[sk]['vendors'] |= vs
scope_rank = sorted(scope_univ.items(),
                    key=lambda kv: (-len(kv[1]['vendors']), kv[0]))
OUT['e7_scope_top'] = [
    {'scope_key': k, 'vendors': len(v['vendors']), 'mods': sorted(v['mods'])}
    for k, v in scope_rank[:25]
]
OUT['e7_scope_distinct'] = len(scope_univ)

# ─────────────────────────────────────────────────────────
# E8 槽位保真度：GRL -> 散文，槽位内容一个都不能丢
# ─────────────────────────────────────────────────────────
def norm_tokens(s):
    return set(t for t in re.findall(r"[a-z0-9']+", (s or '').lower()) if len(t) > 2)

e8 = {'n': 0, 'all_slots_kept': 0, 'missing_slots': Counter(), 'per_slot': Counter()}
for r in RULES:
    if r.cls != 'regulative':
        continue
    e8['n'] += 1
    comp = grl.compile_rule(r)
    ct = norm_tokens(comp)
    slots = []
    if r.object_raw:
        slots.append(('object', norm_tokens(r.object_raw)))
    if r.condition_raw:
        slots.append(('condition', norm_tokens(r.condition_raw)))
    if r.verb:
        slots.append(('verb', {r.verb}))
    if r.addressee:
        slots.append(('addressee', norm_tokens(r.addressee)))
    ok = True
    for name, toks in slots:
        if not toks:
            continue
        hit = (toks & ct) if name != 'verb' else (r.verb.lower() in comp.lower())
        if not hit:
            ok = False
            e8['missing_slots'][name] += 1
        e8['per_slot'][name] += 1
    if ok:
        e8['all_slots_kept'] += 1
e8['all_slots_kept_rate'] = e8['all_slots_kept'] / max(1, e8['n'])
e8['missing_slots'] = dict(e8['missing_slots'])
e8['per_slot'] = dict(e8['per_slot'])
OUT['e8'] = e8

# ─────────────────────────────────────────────────────────
# E9 风格可替换性：同一 GRL，多种数据驱动文风
# ─────────────────────────────────────────────────────────
STYLES = {
    'xai_policy': {
        'name': 'xai_policy', 'open': '<policy>', 'close': '</policy>',
        'modality': {'must': 'MUST', 'must_not': 'MUST NOT', 'should': 'SHOULD',
                     'may': 'MAY', 'can': 'MAY', 'unspecified': ''},
        'frame': '{body}.',
    },
    'openai_plain': {
        'name': 'openai_plain', 'open': '', 'close': '',
        'modality': {'must': 'must', 'must_not': 'must not', 'should': 'should',
                     'may': 'may', 'can': 'may', 'unspecified': 'should'},
        'frame': '{body}.',
    },
    'anthropic_effect': {
        'name': 'anthropic_effect', 'open': '', 'close': '',
        'modality': {'must': 'always', 'must_not': 'never', 'should': 'prefer',
                     'may': 'may', 'can': 'may', 'unspecified': ''},
        'frame': '{body}, because it directly affects the user.',
    },
}
sample = [r for r in by_vendor['ANTHROPIC'] if r.modality == 'must'][:6]
e9 = {'samples': [], 'distinct_outputs_per_rule': {}}
outs_by_rule = defaultdict(set)
for r in RULES:
    if r.cls != 'regulative' or len(outs_by_rule) > 3000:
        continue
    o = tuple(grl.compile_rule(r, s) for s in STYLES.values())
    outs_by_rule[r.id] = o
for r in sample:
    e9['samples'].append({
        'id': r.id,
        'grl': r.to_grl().split('\n')[4] if len(r.to_grl().split('\n')) > 4 else '',
        'orig': r.statement[:200],
        'renders': {name: grl.compile_rule(r, st)[:200] for name, st in STYLES.items()},
    })
e9['distinct_outputs_per_rule'] = dict(Counter(len(set(v)) for v in outs_by_rule.values()))
# 极性守恒自检：编译前后极性必须一致（风格表不许反转极性）
pol_bad = []
for rid, o in list(outs_by_rule.items())[:3000]:
    rr = next(x for x in RULES if x.id == rid)
    for sname, st in STYLES.items():
        ok, d = grl.check_polarity(rr, st)
        if not ok:
            pol_bad.append({'id': rid, 'style': sname, 'detail': d})
e9['polarity_violations'] = len(pol_bad)
e9['polarity_sample'] = pol_bad[:3]
e9['polarity_checked'] = min(3000, len(outs_by_rule)) * len(STYLES)
e9['n_rules'] = len(outs_by_rule)
e9['styles'] = list(STYLES.keys())
OUT['e9'] = e9

# ─────────────────────────────────────────────────────────
# E10 作用域规范化收益
# ─────────────────────────────────────────────────────────
raw_secs = Counter()
norm_secs = Counter()
for r in RULES:
    if r.scope_raw:
        raw_secs[r.scope_raw] += 1
        norm_secs[r.scope_key] += 1
e10 = {
    'raw_distinct': len(raw_secs),
    'normalized_distinct': len(norm_secs),
    'collapse_factor': len(raw_secs) / max(1, len(norm_secs)),
    'top_raw': [[k, v] for k, v in raw_secs.most_common(12)],
    'top_norm': [[k, v] for k, v in norm_secs.most_common(12)],
}
# 只靠 casefold 能归并多少
cf = Counter()
for k, v in raw_secs.items():
    cf[k.lower()] += v
e10['casefold_distinct'] = len(cf)
e10['casefold_collapse'] = len(raw_secs) / max(1, len(cf))
e10['extra_from_synonym'] = len(cf) / max(1, len(norm_secs))
OUT['e10'] = e10

# ─────────────────────────────────────────────────────────
# E11 位点自动归属可行性
# ─────────────────────────────────────────────────────────
hits = Counter()
ambig = 0
none = 0
for r in RULES:
    if r.cls != 'regulative':
        continue
    text = (r.anchor or '') + ' ' + (r.statement or '')
    scored = []
    for loc, rx in genome_lib.RX.items():
        n = len(rx.findall(text.lower()))
        if n:
            scored.append((n, loc))
    if not scored:
        none += 1
    else:
        mx = max(s for s, _ in scored)
        top = [l for s, l in scored if s == mx]
        hits[top[0]] += 1
        if len(top) > 1:
            ambig += 1
tot = sum(1 for r in RULES if r.cls == 'regulative')
OUT['e11'] = {
    'total_regulative': tot,
    'no_locus': none,
    'no_locus_rate': none / max(1, tot),
    'ambiguous_tie': ambig,
    'unique_or_tied_top': hits.total() if hasattr(hits, 'total') else sum(hits.values()),
    'per_locus': dict(hits.most_common()),
}
OUT['e11']['unique_rate'] = (sum(hits.values()) - ambig) / max(1, tot)

with open(os.path.join(DATA_DIR, 'grl_out2.json'), 'w', encoding='utf-8') as f:
    json.dump(OUT, f, ensure_ascii=False, indent=1)

print('=== E7 多分辨率等位键（跨厂商共享）===')
for x in e7:
    print('%-10s/%-10s ' % (x['a'], x['b']) + ' | '.join(
        '%s: A=%4d B=%4d shared=%3d jac=%.3f' % (lv, x[lv]['n_a'], x[lv]['n_b'], x[lv]['shared'], x[lv]['jaccard'])
        for lv in ('L1', 'L2', 'L3')))
print('\nL1 scope 种类数:', OUT['e7_scope_distinct'])
print('跨厂商最通用的 scope TOP12:')
for x in OUT['e7_scope_top'][:12]:
    print('  %-42s vendors=%2d mods=%s' % (x['scope_key'][:42], x['vendors'], x['mods']))
print('\n=== E8 槽位保真度 ===')
print(json.dumps(OUT['e8'], ensure_ascii=False))
print('\n=== E9 风格可替换 ===')
print('rules=%d  distinct-output-count分布=%s' % (e9['n_rules'], e9['distinct_outputs_per_rule']))
for s in e9['samples'][:3]:
    print('  ID', s['id'], '| 原文:', s['orig'][:110])
    for k, v in s['renders'].items():
        print('     %-18s %s' % (k, v[:110]))
print('\n=== E10 作用域规范化 ===')
print(json.dumps({k: v for k, v in OUT['e10'].items() if not k.startswith('top')}, ensure_ascii=False))
print('raw TOP6:', OUT['e10']['top_raw'][:6])
print('norm TOP6:', OUT['e10']['top_norm'][:6])
print('\n=== E11 位点自动归属 ===')
print(json.dumps({k: v for k, v in OUT['e11'].items() if k != 'per_locus'}, ensure_ascii=False))
print('per_locus:', json.dumps(OUT['e11']['per_locus'], ensure_ascii=False))
