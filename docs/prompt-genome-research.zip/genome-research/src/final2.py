# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
import os,re,json,collections,math,itertools,statistics
exec(open(os.path.join(HERE,'genome_lib.py')).read())
ROOT=os.environ.get('CL4R1T4S_DIR') or os.path.join(ROOT_DIR,'CL4R1T4S-main')
F=json.load(open(os.path.join(DATA_DIR, 'loci_files.json'))); REP=json.load(open(os.path.join(DATA_DIR, 'rep.json')))
G=json.load(open(os.path.join(DATA_DIR, 'genome.json')))
V=sorted(REP); LOCI=G['LOCI']
T0=['拒答与安全策略','危险类别枚举','未成年人保护','隐私与数据','注入防御与不可信输入']
T2=['自主性与持续推进','权限与升级请求']
T1=[b for b in LOCI if b not in T0 and b not in T2]
ORDER=T0+[b for b in G['core']+G['weak'] if b in T1]+T2
for rel,d in F.items():
    seen=[]
    for b in d['seq']:
        if b not in seen: seen.append(b)
    d['order']=seen
byv=collections.defaultdict(list)
for rel,d in F.items(): byv[d['vendor']].append(rel)
RANK={'absent':0,'content':1,'struct':2}
AL={'struct':'█','content':'▄','absent':'·'}
# ── genome = 并集（该厂商全部提示词文件）──
genome={}; spread={}; peakfile={}; peak={}
for v,files in byv.items():
    genome[v]={}; spread[v]={}
    for b in LOCI:
        best='absent'; ns=0; nc=0
        for rel in files:
            a='struct' if b in F[rel]['order'] else ('content' if b in F[rel]['content'] else 'absent')
            if a=='struct': ns+=1
            elif a=='content': nc+=1
            if RANK[a]>RANK[best]: best=a
        genome[v][b]=best; spread[v][b]=ns+nc
    pf=max(files,key=lambda r:(len(F[r]['order']),F[r]['size'])); peakfile[v]=pf
    peak[v]={b:('struct' if b in F[pf]['order'] else 'content' if b in F[pf]['content'] else 'absent') for b in LOCI}
seqs={v:''.join(AL[genome[v][b]] for b in ORDER) for v in V}
pseqs={v:''.join(AL[peak[v][b]] for b in ORDER) for v in V}
# ── 强制构造：全部文件 ──
PHR={'最高优先':['highest priority','highest-priority'],'指令源边界':['only from the user','valid instructions','instruction source'],
     '数据非命令':['data, not commands','not commands','treat as data','as data, not'],
     '无条件例外':['regardless of','under no circumstances','no exceptions','even if the user'],
     '硬禁止':['must never','MUST NOT','never reveal','shall not','cannot be overridden','inviolable']}
ENF={}
for v,files in byv.items():
    t=''.join(open(os.path.join(ROOT,r),encoding='utf-8',errors='replace').read().lower() for r in files)
    h={k:sum(t.count(p.lower()) for p in ps) for k,ps in PHR.items()}
    ENF[v]={'hits':{k:n for k,n in h.items() if n},'total':sum(h.values()),
            'files_with':[r for r in files if any(p.lower() in open(os.path.join(ROOT,r),encoding='utf-8',errors='replace').read().lower() for ps in PHR.values() for p in ps)]}
# ── 统计 ──
consv={};divs={};alld={}
for b in LOCI:
    c=collections.Counter(seqs[v][ORDER.index(b)] for v in V); n=len(V)
    alld[b]=dict(c); consv[b]=c.most_common(1)[0][1]/n
    divs[b]=-(sum((x/n)*math.log(x/n) for x in c.values() if x))
W={('█','▄'):1,('█','·'):1,('▄','·'):0.5}
def wm(a,b): return sum(W.get((x,y),W.get((y,x),0)) for x,y in zip(a,b))/len(ORDER)
D={a:{b:wm(seqs[a],seqs[b]) for b in V} for a in V}
def kmed(k,iters=400,restarts=12):
    pairs=sorted((D[a][b],a,b) for a,b in itertools.combinations(V,2))
    best=None
    import random
    for r in range(restarts):
        random.seed(1000+r)
        med=[]
        cand=[v for v in V]
        med.append(random.choice(cand)); cand.remove(med[0])
        while len(med)<k:
            d0=min(D[v][m] for m in med)
            pool=[v for v in cand if D[v][med[0]]==d0] or cand
            pick=random.choice(pool); med.append(pick); cand.remove(pick)
        for _ in range(iters):
            lab={v:min(range(k),key=lambda i:D[v][med[i]]) for v in V}
            for i in range(k):
                mem=[v for v in V if lab[v]==i]
                if len(mem)>1:
                    med[i]=min(itertools.combinations(mem,2),key=lambda p:D[p[0]][p[1]])[0]
                elif len(mem)==1: med[i]=mem[0]
        lab={v:min(range(k),key=lambda i:D[v][med[i]]) for v in V}
        obj=sum(min(D[v][med[i]] for i in range(k)) for v in V)
        nonempty=len(set(lab.values()))
        if best is None or (nonempty==k and obj<best[0]): best=(obj,dict(lab),list(med))
    obj,lab,med=best
    return lab,med
# 家族距离：用「存在集 Jaccard 距离」（基因组重叠的标准度量）
DP={a:{b:1-len({x for x in LOCI if genome[a][x]!='absent'} & {x for x in LOCI if genome[b][x]!='absent'})/
        max(1,len({x for x in LOCI if genome[a][x]!='absent'} | {x for x in LOCI if genome[b][x]!='absent'}))
        for b in V} for a in V}
CL={}
for k in (2,3,4):
    lab,med=kmed(k)
    CL[k]={'labels':lab,'medoids':med,'groups':[[v for v in V if lab[v]==i] for i in range(k)]}
# ── 不变量带审计（并集口径）──
INV={}
for b in T0:
    st=[v for v in V if genome[v][b]=='struct']; co=[v for v in V if genome[v][b]=='content']
    INV[b]={'struct':st,'content':co,'absent':[v for v in V if genome[v][b]=='absent'],
            'n_struct':len(st),'n_any':len(st)+len(co),
            'spread_mean':statistics.mean([spread[v][b] for v in st+co]) if (st+co) else 0}
# ── 表达广度 vs 峰值强度 ──
SPREAD={b:statistics.mean([spread[v][b] for v in V]) for b in LOCI}
# ── 新颖性 ──
uniq=[]
for b in LOCI:
    for v in V:
        s=genome[v][b]
        if s=='absent': continue
        if not any(genome[u][b]==s for u in V if u!=v): uniq.append((v,b,s))
# ── 锚点原文 ──
ANCH={}
def grab(v,b,k=1):
    out=[]; rx=RX[b]
    for rel in byv[v]:
        for i,ln in enumerate(open(os.path.join(ROOT,rel),encoding='utf-8',errors='replace').read().splitlines(),1):
            s=ln.strip()
            if s and rx.search(s.lower()) and len(s)>=50:
                out.append((rel,i,s[:330]))
            if len(out)>=k*3: break
        if len(out)>=k*3: break
    return out[:k]
for b in LOCI:
    ANCH[b]={v:grab(v,b,1) for v in INV.get(b,{}).get('struct',[])[:8]} if b in INV else {}
json.dump({'DP':DP,'LOCI':LOCI,'T0':T0,'T1':T1,'T2':T2,'ORDER':ORDER,'seqs':seqs,'pseqs':pseqs,
  'genome':genome,'peak':peak,'peakfile':peakfile,'spread':spread,'SPREAD_MEAN':SPREAD,
  'consv':consv,'divs':divs,'alld':alld,'D':D,'CL':CL,'INV':INV,'ENF':ENF,'uniq':uniq,
  'byv':{k:sorted(v) for k,v in byv.items()},'core':G['core'],'weak':G['weak']},
  open(os.path.join(DATA_DIR, 'final_genome.json'),'w'),ensure_ascii=False)
print("="*106); print("粗序列 v2（genome = 厂商全部提示词文件并集）｜三带 T0/T1/T2"); print("="*106)
print("  "+" "*13+"".join(str(i%10) for i in range(len(ORDER))))
for v in sorted(V,key=lambda x:sum(1 for b in ORDER if genome[x][b]!='absent'),reverse=True):
    print(f"  {v:<12}{seqs[v]}")
print("\n  带: "+"".join('0' if b in T0 else '2' if b in T2 else '1' for b in ORDER))
print("\n"+"="*106); print("Tier 0 不变量带（并集口径）"); print("="*106)
for b in T0:
    i=INV[b]; print(f"  【{b}】成节 {i['n_struct']:>2}/26 ｜仅正文 {len(i['content']):>2} ｜缺位 {len(i['absent']):>2} ｜成节方均铺开 {i['spread_mean']:.1f} 个文件")
    print(f"      成节: {', '.join(i['struct']) or '（无）'}")
    print(f"      缺位: {', '.join(i['absent'])}")
print("\n"+"="*106); print("强制构造（覆盖该厂商全部文件）"); print("="*106)
for v in sorted(V,key=lambda x:-ENF[x]['total']):
    e=ENF[v]; print(f"  {v:<12} {e['total']:>4} 次  {e['hits']}  命中文件{len(e['files_with'])}")
print("\n"+"="*106); print("家族 k-medoids"); print("="*106)
for k in (2,3,4):
    print(f"\n-- k={k} --")
    for i,g in enumerate(CL[k]['groups'],1):
        if not g: continue
        sd=statistics.mean([sum(1 for b in ORDER if genome[v][b]=='struct')/max(1,sum(1 for b in ORDER if genome[v][b]!='absent')) for v in g])
        print(f"  组{i} n={len(g):>2} medoid={CL[k]['medoids'][i-1]:<11} 结构化密度{sd:.2f}: "+", ".join(g))
print("\n唯一组合（新颖性候选）:",len(uniq))
for v,b,s in uniq[:26]: print(f"   {v:<12} {b} ({s})")
