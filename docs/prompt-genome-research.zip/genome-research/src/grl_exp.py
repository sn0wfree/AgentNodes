#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GRL 实测：这门语言到底能不能装下现有语料、能做什么别人做不到的事。

E1  反编译覆盖率：条款 -> GRL 槽位有多少无损
E2  模态枚举的 data-driven 验证：10 种原始取值 -> 6 档
E3  位点级 diff：GRL 集合差 vs 散文文本 diff 的规模对比
E4  等位引用的三态判定：相同 / 不可区分 / 不可判定  <- 核心实验
E5  编译还原度：GRL -> 散文 与原文的字符 shingle 覆盖率
E6  断言求值：⊇ / ⊥ / ≡ 在真实语料上的行为
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import grl
HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(os.path.dirname(HERE), 'data')

OUT = {}
RULES, STATS = grl.load_corpus()
OUT['stats'] = STATS

# ─────────────────────────────────────────────────────────
# E1 反编译覆盖率
# ─────────────────────────────────────────────────────────
reg = [r for r in RULES if r.cls == 'regulative']
con = [r for r in RULES if r.cls == 'constitutive']
nons = [r for r in RULES if r.cls == 'non-statement']

e1 = {
    'total': len(RULES),
    'regulative': len(reg),
    'constitutive': len(con),
    'non_statement': len(nons),
    'reg_with_verb': sum(1 for r in reg if r.verb),
    'reg_with_object': sum(1 for r in reg if r.object_key),
    'reg_with_scope': sum(1 for r in reg if r.scope_key),
    'reg_with_condition': sum(1 for r in reg if r.condition_raw),
    'reg_with_modality': sum(1 for r in reg if r.modality != 'unspecified'),
    'reg_modality_missing': sum(1 for r in reg if r.modality == 'unspecified'),
    'con_with_verb': sum(1 for r in con if r.verb),
    'con_with_object': sum(1 for r in con if r.object_key),
}
e1['reg_verb_rate'] = e1['reg_with_verb'] / max(1, e1['regulative'])
e1['reg_scope_rate'] = e1['reg_with_scope'] / max(1, e1['regulative'])
e1['reg_modality_rate'] = e1['reg_with_modality'] / max(1, e1['regulative'])
OUT['e1'] = e1

# ─────────────────────────────────────────────────────────
# E2 模态枚举：原始 D 取值 -> 归并档位，逐值可追
# ─────────────────────────────────────────────────────────
raw2mod = defaultdict(Counter)
for r in reg:
    raw = '(empty)' if r.modality == 'unspecified' else ''
    raw2mod[r.modality][raw] += 1
raw_vals = STATS['raw_D_values']
mod_of_raw = {}
for raw, cnt in raw_vals.items():
    m, _neg = grl.parse_modality(raw)
    mod_of_raw[raw] = (m, cnt)
e2 = {
    'raw_distinct': len(raw_vals),
    'modality_distinct': len(set(r.modality for r in reg)),
    'raw_to_modality': {k: {'modality': v[0], 'count': v[1]} for k, v in sorted(mod_of_raw.items(), key=lambda kv: -kv[1][1])},
    'modality_counts': dict(Counter(r.modality for r in reg)),
}
e2['unspecified_rate'] = e2['modality_counts'].get('unspecified', 0) / max(1, len(reg))
OUT['e2'] = e2

# ─────────────────────────────────────────────────────────
# E3 位点级 diff：GRL 集合差 vs 散文文本 diff
# ─────────────────────────────────────────────────────────
by_vendor = defaultdict(list)
for r in RULES:
    by_vendor[r.vendor].append(r)

def text_of(rules):
    return '\n'.join((r.statement or '') for r in rules)

pairs = [('ANTHROPIC', 'OPENAI'), ('ANTHROPIC', 'XAI'), ('OPENAI', 'PERPLEXITY'),
         ('META', 'GOOGLE'), ('HUME', 'MISTRAL'), ('DIA', 'CLUELY')]
e3 = []
for a, b in pairs:
    if a not in by_vendor or b not in by_vendor:
        continue
    ra, rb = by_vendor[a], by_vendor[b]
    only_a, only_b, shared = grl.allele_diff(ra, rb)
    chg, la, lb = grl.text_diff_stats(text_of(ra), text_of(rb))
    # 散文逐字相同的条款数
    sa = set(r.statement for r in ra if r.statement)
    sb = set(r.statement for r in rb if r.statement)
    e3.append({
        'a': a, 'b': b,
        'n_a': len(ra), 'n_b': len(rb),
        'grl_only_a': len(only_a), 'grl_only_b': len(only_b), 'grl_shared': len(shared),
        'grl_total_distinct': len(only_a) + len(only_b) + len(shared),
        'grl_diff_ratio': (len(only_a) + len(only_b)) / max(1, len(only_a) + len(only_b) + len(shared)),
        'text_lines_changed': chg, 'text_lines_a': la, 'text_lines_b': lb,
        'text_verbatim_shared': len(sa & sb),
        'verdict_lines_instead_of_rules': chg > 0,
    })
OUT['e3'] = e3

# ─────────────────────────────────────────────────────────
# E4 ★ 核心：等位比较的三态判定
#     同一家厂商内部，两条规则「模态明确相同 / 都未声明 / 一明确一未声明」
# ─────────────────────────────────────────────────────────
def compare_modality(m1, m2):
    if m1 != 'unspecified' and m2 != 'unspecified':
        return 'SAME' if m1 == m2 else 'CONFLICT'
    if m1 == 'unspecified' and m2 == 'unspecified':
        return 'UNDECLARED_BOTH'
    return 'UNDECIDABLE'

# 跨厂商匹配：对每对厂商，按「除模态外全同」的键分组，看组内模态关系
cross = []
for a, b in pairs:
    if a not in by_vendor or b not in by_vendor:
        continue
    ra, rb = by_vendor[a], by_vendor[b]
    ga = defaultdict(list)
    for r in ra:
        if r.cls != 'regulative':
            continue
        ga[(r.cls, bool(r.negation), r.verb, r.object_key)].append(r)
    gb = defaultdict(list)
    for r in rb:
        if r.cls != 'regulative':
            continue
        gb[(r.cls, bool(r.negation), r.verb, r.object_key)].append(r)
    shared_keys = set(ga) & set(gb)
    state = Counter()
    for k in shared_keys:
        # 该键下 A 的模态集合 vs B 的模态集合
        ma = set(x.modality for x in ga[k])
        mb = set(x.modality for x in gb[k])
        if ma == mb:
            state['SAME' if (len(ma) == 1 and 'unspecified' not in ma) else 'UNDECLARED_BOTH'] += 1
        elif 'unspecified' in ma or 'unspecified' in mb:
            state['UNDECIDABLE'] += 1
        else:
            state['CONFLICT'] += 1
    cross.append({
        'a': a, 'b': b,
        'shared_nonmodality_keys': len(shared_keys),
        'SAME': state.get('SAME', 0),
        'UNDECLARED_BOTH': state.get('UNDECLARED_BOTH', 0),
        'UNDECIDABLE': state.get('UNDECIDABLE', 0),
        'CONFLICT': state.get('CONFLICT', 0),
    })
OUT['e4_cross'] = cross

# 同厂商内部：一个等位键下模态声明的一致性（有多少键是「全部未声明」）
g_all = defaultdict(list)
for r in reg:
    g_all[(r.cls, bool(r.negation), r.verb, r.object_key)].append(r)
internal = Counter()
for k, rs in g_all.items():
    ms = set(x.modality for x in rs)
    if ms == {'unspecified'}:
        internal['ALL_UNDECLARED'] += 1
    elif len(ms) == 1:
        internal['ALL_DECLARED_SAME'] += 1
    else:
        internal['MIXED'] += 1
OUT['e4_internal'] = dict(internal)
OUT['e4_internal_total_keys'] = len(g_all)

# ─────────────────────────────────────────────────────────
# E5 编译还原度：GRL -> 散文 vs 原文（字符 shingle 覆盖率）
# ─────────────────────────────────────────────────────────
def shingles(text, n=120):
    s = re.sub(r'\s+', ' ', text or '').strip()
    if len(s) < n:
        return {s} if s else set()
    return {s[i:i+n] for i in range(len(s)-n+1)}

def coverage(compiled, original):
    c, o = shingles(compiled), shingles(original)
    if not o:
        return None
    return len(c & o) / len(o)

# 用默认风格编译每条，比较自身原文（round-trip 还原度）
rates = []
for r in reg[:4000]:
    c = grl.compile_rule(r)
    o = r.statement
    cv = coverage(c, o)
    if cv is not None:
        rates.append(cv)
OUT['e5'] = {
    'n': len(rates),
    'mean': sum(rates) / max(1, len(rates)),
    'median': sorted(rates)[len(rates)//2] if rates else 0,
    'p10': sorted(rates)[int(len(rates)*0.1)] if rates else 0,
    'exact_match': sum(1 for x in rates if x >= 0.999),
    'ge_0_5': sum(1 for x in rates if x >= 0.5),
}

# ─────────────────────────────────────────────────────────
# E6 断言求值
# ─────────────────────────────────────────────────────────
by_id = grl.build_by_id(RULES)
# 造一个断言：某厂商的 D01 位点（用 scope 近似）是否含一条 must 规则
anth = by_vendor['ANTHROPIC']
must_rules = [r for r in anth if r.modality == 'must']
target = must_rules[0] if must_rules else None
e6 = {}
if target:
    ok1, d1 = grl.evaluate_assertion('@' + must_rules[0].id, '⊇', '@' + target.id, RULES, by_id)
    ok2, d2 = grl.evaluate_assertion('@' + target.id, '⊥', '@' + (must_rules[1].id if len(must_rules) > 1 else target.id), RULES, by_id)
    e6 = {
        'sample_rule': target.id,
        'sample_statement': target.statement[:160],
        'subset_ok': ok1, 'subset_detail': d1,
        'disjoint_ok': ok2, 'disjoint_detail': d2,
    }
OUT['e6'] = e6

# ─────────────────────────────────────────────────────────
# 输出
# ─────────────────────────────────────────────────────────
OUT['_meta'] = {'rules': len(RULES), 'vendors': sorted(by_vendor.keys())}
with open(os.path.join(DATA_DIR, 'grl_out.json'), 'w', encoding='utf-8') as f:
    json.dump(OUT, f, ensure_ascii=False, indent=1)

print('=== E1 反编译覆盖 ===')
print(json.dumps(e1, ensure_ascii=False, indent=1))
print('\n=== E2 模态枚举 ===')
print('raw distinct %d -> modality distinct %d' % (e2['raw_distinct'], e2['modality_distinct']))
for k, v in e2['raw_to_modality'].items():
    print('  %-14r -> %-12s  %d' % (k, v['modality'], v['count']))
print('modality counts:', json.dumps(e2['modality_counts'], ensure_ascii=False))
print('unspecified rate: %.1f%%' % (e2['unspecified_rate']*100))
print('\n=== E3 位点级 diff vs 散文 diff ===')
for x in e3:
    print('%-10s/%-10s n=%4d/%-4d GRL: only_a=%3d only_b=%3d shared=%3d | 散文行变 %3d (共 %4d/%4d) | 逐字共有 %d'
          % (x['a'], x['b'], x['n_a'], x['n_b'], x['grl_only_a'], x['grl_only_b'], x['grl_shared'],
             x['text_lines_changed'], x['text_lines_a'], x['text_lines_b'], x['text_verbatim_shared']))
print('\n=== E4 等位三态（跨厂商）===')
for x in cross:
    tot = x['SAME']+x['UNDECLARED_BOTH']+x['UNDECIDABLE']+x['CONFLICT']
    print('%-10s/%-10s 共有键 %3d -> SAME %3d | 都未声明 %3d | 不可判定 %3d | 冲突 %3d'
          % (x['a'], x['b'], tot, x['SAME'], x['UNDECLARED_BOTH'], x['UNDECIDABLE'], x['CONFLICT']))
print('内部键状态:', json.dumps(OUT['e4_internal'], ensure_ascii=False), '总键数', OUT['e4_internal_total_keys'])
print('\n=== E5 编译还原度 ===')
print(json.dumps(OUT['e5'], ensure_ascii=False))
print('\n=== E6 断言 ===')
print(json.dumps(OUT['e6'], ensure_ascii=False, indent=1))
