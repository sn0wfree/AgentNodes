#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""等位归一化的共享工具：把自由文本谓词压到受控词表，并把否定/条件/模态拆成独立字段。
这是「等位编码」与「存在性编码」的分界点。"""
import re

NEG = re.compile(r"^(not|never|avoid|don't|do not|doesn't|refuse to|don't ever)\s+")
COND_HINT = re.compile(r"^(if|unless|when|whenever|except|only if|in case)\b")
STOP = {"the", "a", "an", "and", "or", "to", "of", "in", "for", "with", "on", "at",
        "it", "its", "this", "that", "these", "those", "as", "by", "from", "be", "is"}

VERB_MAP = {
    "use": "use", "utilize": "use", "employ": "use", "apply": "use", "leverage": "use",
    "provide": "provide", "offer": "provide", "give": "provide", "supply": "provide",
    "present": "provide", "deliver": "provide", "return": "provide", "produce": "provide",
    "include": "include", "contain": "include", "cover": "include", "add": "include",
    "search": "search", "browse": "search", "query": "search", "lookup": "search",
    "ask": "ask", "request": "ask", "clarify": "ask", "inquire": "ask",
    "answer": "answer", "respond": "answer", "reply": "answer",
    "tell": "tell", "inform": "tell", "notify": "tell", "communicate": "tell",
    "write": "write", "author": "write", "draft": "write",
    "create": "create", "generate": "create", "make": "create", "build": "create",
    "mention": "mention", "refer": "mention", "name": "mention",
    "show": "show", "display": "show", "reveal": "show",
    "explain": "explain", "describe": "explain",
    "cite": "cite", "source": "cite", "attribute": "cite", "quote": "cite",
    "analyze": "analyze", "analyse": "analyze", "evaluate": "analyze", "assess": "analyze",
    "refuse": "refuse", "decline": "refuse",
    "suggest": "suggest", "recommend": "suggest", "propose": "suggest",
    "prioritize": "prioritize", "prioritise": "prioritize",
    "maintain": "maintain", "keep": "maintain", "preserve": "maintain",
    "follow": "follow", "adhere": "follow", "comply": "follow", "obey": "follow",
    "call": "call", "invoke": "call", "access": "call",
    "avoid": "avoid", "prevent": "avoid", "stop": "avoid",
    "engage": "engage", "interact": "engage", "participate": "engage",
    "send": "send", "transmit": "send",
    "treat": "treat", "handle": "treat", "address": "treat",
    "respect": "respect", "honor": "respect", "comply": "respect",
    "assist": "assist", "help": "assist", "support": "assist",
    "ensure": "ensure", "verify": "ensure", "check": "ensure", "confirm": "ensure",
    "adapt": "adapt", "adjust": "adapt",
    "acknowledge": "acknowledge",
    "redirect": "redirect", "start": "start", "begin": "start",
    "prefer": "prefer", "choose": "prefer", "select": "prefer",
    "perform": "perform", "do": "perform", "try": "perform",
    "discuss": "discuss", "illustrate": "illustrate",
    "place": "place", "put": "place", "set": "place",
    "get": "get", "obtain": "get", "fetch": "get", "retrieve": "get",
    "think": "think", "reason": "think", "consider": "think",
    "identify": "identify", "detect": "identify", "recognize": "identify",
    "review": "review", "evaluate": "review",
    "reject": "reject", "disallow": "reject",
    "format": "format", "structure": "format",
    "assume": "assume", "presume": "assume",
    "express": "express", "state": "express", "clarify": "express",
    "note": "note",
    "point": "point",
    "scale": "scale",
    "reply": "answer", "respond": "answer",
}

STEM_SUF = ("ing", "es", "s", "ed")


def norm(s):
    if not s:
        return ""
    s = re.sub(r"\s+", " ", s.strip().lower())
    return s.strip(" .,:;!?\"'`()[]")


def strip_neg(s):
    s = norm(s)
    for _ in range(3):
        m = NEG.match(s)
        if not m:
            break
        s = s[m.end():].strip()
    return s


def canon_verb(s):
    """去否定 + 词干化 + 映射到受控动词表；未命中的保留原形（仍受控：只做词干化）"""
    s = strip_neg(s)
    s = re.sub(r"^(try to|tries to|attempt to|attempting|tries|tried|always|never)\s+", "", s)
    w = s.split()
    if not w:
        return ""
    v = w[0]
    for suf in STEM_SUF:
        if v.endswith(suf) and len(v) > len(suf) + 2:
            v = v[: -len(suf)]
            break
    if v in VERB_MAP:
        return VERB_MAP[v]
    if v.endswith("e") and v[:-1] in VERB_MAP:
        return VERB_MAP[v[:-1]]
    if v.endswith("y") and v[:-1] + "i" in VERB_MAP:
        return VERB_MAP[v[:-1]]
    if v.endswith("s") and v[:-1] in VERB_MAP:
        return VERB_MAP[v[:-1]]
    # 前缀回退：provides→provid、analyses→analys 等词干化后的残形
    cands = [k for k in VERB_MAP if k.startswith(v) and len(k) - len(v) <= 2]
    if cands:
        return min(cands, key=len)
    return v


def is_negated(s):
    return bool(NEG.match(norm(s)))


def obj_terms(s):
    s = norm(s)
    return [w for w in re.findall(r"[a-z][a-z\-]{2,}", s) if w not in STOP]


def modality(s):
    """模态：显式 deontic 归到受控枚举；空 = 散文"""
    s = norm(s)
    if not s:
        return ""
    for m in ("must not", "cannot", "can't", "shall not", "should not", "may not",
              "must", "should", "shall", "may", "can", "will", "would", "might"):
        if s.startswith(m) or s == m:
            return m
    return ""


def allele_key(aim, deontic, cond):
    """一个等位的键 = (受控动词, 否定位, 模态, 是否有条件)"""
    neg = "N" if is_negated(aim) else "P"
    return f"{canon_verb(aim)}|{neg}|{modality(deontic) or '-'}|{'C' if cond else '-'}"
