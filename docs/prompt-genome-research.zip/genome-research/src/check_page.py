# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import os
from playwright.sync_api import sync_playwright
import json,re
URL='file://' + os.path.join(ROOT_DIR,'figures','02-genome-sequences','index.html')
REPORT=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for name,vw,vh in [("desktop",1440,900),("mobile",390,844)]:
        pg=br.new_page(viewport={'width':vw,'height':vh})
        errs=[];pg.on('console',lambda m: errs.append(f"{m.type}: {m.text}") if m.type in ('error','warning') else None)
        pg.on('pageerror',lambda ex: errs.append(f"pageerror: {ex}"))
        pg.goto(URL,wait_until='networkidle');pg.wait_for_timeout(1200)
        r=pg.evaluate("""()=>{
          const de=document.documentElement;
          const inScroller=el=>{let p=el.parentElement;while(p&&p!==document.body){const s=getComputedStyle(p);if(s.overflowX==='auto'||s.overflowX==='scroll'||s.overflow==='hidden'||s.overflowX==='hidden')return true;p=p.parentElement;}return false;};
          const over=[...document.querySelectorAll('*')].filter(el=>{
            const b=el.getBoundingClientRect();
            return b.width>0 && (b.right>de.clientWidth+1.5||b.left<-1.5) && !inScroller(el);
          }).slice(0,8).map(el=>el.tagName+'.'+(el.className||'').toString().slice(0,40));
          return {sw:de.scrollWidth,cw:de.clientWidth,sh:de.scrollHeight,
                  over:[...new Set(over)],
                  txt:document.body.innerText,
                  cells:document.querySelectorAll('.cell:not(.head)').length,
                  rows:document.querySelectorAll('.sqrow').length,
                  hc:document.querySelectorAll('.hc').length,
                  fam:document.querySelectorAll('.arch-row').length,
                  prow:document.querySelectorAll('tbody tr').length};
        }""")
        txt=r.pop('txt')
        md = '**' in txt or '`' in txt
        REPORT.append({'view':name,'overflow_px':r['sw']-r['cw'],'page_h':r['sh'],
                       'over_elems':r['over'],'console':errs,
                       'md_residue':md,'cells':r['cells'],'rows':r['rows'],
                       'heat_cells':r['hc'],'families':r['fam'],'prio_rows':r['prow']})
        pg.screenshot(path=os.path.join(ROOT_DIR,"figures","02-genome-sequences","_shot_%s.png"%name),full_page=False)
        pg.close()
    br.close()
print(json.dumps(REPORT,ensure_ascii=False,indent=1))
ok=all(r['overflow_px']<=1 and not r['over_elems'] and not r['console'] and not r['md_residue'] for r in REPORT)
print("\nVERDICT:", "PASS" if ok else "FAIL")
