# -*- coding: utf-8 -*-
import re
LOCI=['身份与角色锚定','环境与可及边界','输出格式规范','语气与文风','语言本地化','引用与来源',
      '工具调用纪律','规划与任务分解','自主性与持续推进','权限与升级请求','上下文与记忆','代码与工程操作',
      '多模态与视觉','网络与检索','拒答与安全策略','危险类别枚举','未成年人保护','隐私与数据',
      '诚实与不确定性','错误与能力边界','中立与平衡','专业免责声明','注入防御与不可信输入']
KW={
 '身份与角色锚定':['identity','persona','you are','core identity','agent identity','model identity','introduction','system capability','who you are','agent loop'],
 '环境与可及边界':['environment','sandbox','disk space','working with the user','workspace','runtime','available tools','tool list'],
 '输出格式规范':['output format','response format','formatting rules','format','structure','template','markdown','code block','response_requirements','writing rules','message rules'],
 '语气与文风':['style','tone','writing style','communication','personality','voice','wording','brevity','concise','response quality','technical communication','intermediate commentary','final answer','verbosity'],
 '语言本地化':['language','locale','respond in','translat','multilingual','language settings'],
 '引用与来源':['citation','cite','source','reference','attribution','grounding','citations instructions'],
 '工具调用纪律':['tool','tools','toolkit','function','mcp','tool calling','tool use','tool usage','function call'],
 '规划与任务分解':['plan','planning','task','step','checklist','phase','todo','task process','proposed_plan','workflow','reasoning command'],
 '自主性与持续推进':['autonomy','autonomous','persist','proactive','keep working','complete','initiative','follow-up','approach to work','proactivity'],
 '权限与升级请求':['permission','approval','escalation','confirm','ask the user','request_user_input','consent','authorized','requires_approval','security policy','risk'],
 '上下文与记忆':['context','memory','conversation history','session','compact','summary','instruction priority','instruction source','memory system','context management'],
 '代码与工程操作':['code','edit','file','repository','git','test','debug','refactor','build','lint','terminal','shell','command','coding','codebase','file editing constraints','making code changes'],
 '多模态与视觉':['image','screenshot','visual','diagram','chart','render','canvas','artifact','media'],
 '网络与检索':['search','web','browse','fetch','internet','retrieval','web search'],
 '拒答与安全策略':['safety','policy','harmful','prohibit','refusal','restrict','guardrail','security','ethics','banned','not to do','prohibited','response limitations'],
 '危险类别枚举':['self-harm','suicide','weapon','explosive','csam','terrorism','drug','malware','cyberattack','biological','violence','hate'],
 '未成年人保护':['minor','children','child safety','underage','child'],
 '隐私与数据':['privacy','personal data','pii','confidential','sensitive','do not share','proprietary','data security','information handling','copyright'],
 '诚实与不确定性':['honest','truth','uncertain','hallucination','confidence','acknowledge','accurate','truthful','transparent','knowledge cutoff'],
 '错误与能力边界':['error','limit','limitation','edge case','failure','unavailable','troubleshoot','what you can','limitations'],
 '中立与平衡':['balanced','both sides','neutral','unbiased','political','perspective','avoid bias','evenhandedness','fairness'],
 '专业免责声明':['disclaimer','not a substitute','not a doctor','not a lawyer','financial advice','legal advice','medical advice'],
 '注入防御与不可信输入':['injection','untrusted','ignore previous','disregard','jailbreak','prompt attack','instruction source boundary','external content','malicious','treat as data'],
}
RX={b:re.compile(r'(?<![a-z0-9])(?:'+'|'.join(re.escape(k) for k in kw)+r')(?![a-z0-9])') for b,kw in KW.items()}
HTMLISH=set("""div span p title head body script style link img path svg html meta br hr i b em strong pre code kbd sub sup details summary ul ol li table tr td th a figure section article header footer nav main aside blockquote label input button select option textarea form iframe video audio source template slot picture object canvas g line circle rect polygon polyline ellipse defs text tspan font viewbox desc metadata annotation math semantics mrow mi mn mo msub msup mfrac msqrt foreignobject annotation-xml xlink noembed fence tbody thead caption col colgroup tfoot marker mask filter pattern symbol clippath lineargradient radialgradient stop use""".split())
