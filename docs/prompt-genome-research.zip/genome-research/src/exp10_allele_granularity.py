#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E10：等位键的粒度怎么定？

问题：全键「动词|否定|模态|条件」自由度太大 → 等位几乎全是私有的（相似度 0.02–0.05）。
本实验比较 6 种粒度的取舍：
  - 等位总数（词表大小）
  - 跨厂商共享等位数（能被对齐的等位有多少）
  - 厂商两两等位相似度（共享程度）
  - 区分力：存在性最接近的那几对，等位是否还能分开
  - 强度信息是否保留（模态/否定/条件三个字段各自的保留情况）
"""
import os
import json, glob, os, collections, itertools, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from allele_lib import canon_verb, modality, is_negated
from genome_lib import LOCI, RX

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')
random.seed(20261118)

EX = collections.defaultdict(set)
REC = collections.defaultdict(list)
for f in sorted(glob.glob(os.path.join(ROOT, "*", "*.json"))):
    v = os.path.basename(os.path.dirname(f))
    for it in json.load(open(f, encoding="utf-8")):
        rc = it.get("regulative_components") or {}
        txt = (it.get("full_statement") or "") + " " + (it.get("anchor") or "")
        t = txt.lower()
        aim = (rc.get("I") or "").strip().lower()
        dmod = (rc.get("D") or "").strip().lower()
        cond = bool((rc.get("C") or "").strip())
        for d in LOCI:
            if RX[d].search(t):
                EX[v].add(d)
                REC[v].append((d, aim, dmod, cond))
V = sorted(EX); DIMS = list(LOCI)
pairs = list(itertools.combinations(V, 2))

def jac(a, b):
    u = len(a | b); return len(a & b)/u if u else 0.0

# ---- 粒度方案：函数 aim,dmod,cond -> 键 ----
def k_full(a, m, c):   return f"{canon_verb(a)}|{'N' if is_negated(a) else 'P'}|{modality(m) or '-'}|{'C' if c else '-'}"
def k_noc(a, m, c):   return f"{canon_verb(a)}|{'N' if is_negated(a) else 'P'}|{modality(m) or '-'}"
def k_nom(a, m, c):   return f"{canon_verb(a)}|{modality(m) or '-'}|{'C' if c else '-'}"
def k_mod(a, m, c):   return f"{canon_verb(a)}|{modality(m) or '-'}"
def k_neg(a, m, c):   return f"{canon_verb(a)}|{'N' if is_negated(a) else 'P'}"
def k_v(a, m, c):     return canon_verb(a)

SCHEMES = [
    ("G1 动词|否定|模态|条件", k_full),
    ("G2 动词|否定|模态",       k_noc),
    ("G3 动词|模态|条件",       k_nom),
    ("G4 动词|模态",            k_mod),
    ("G5 动词|否定",            k_neg),
    ("G6 仅动词",               k_v),
]

print(f"厂商 {len(V)} 家 ｜ 条款 {sum(len(x) for x in REC.values())} 条 ｜ 厂商对 {len(pairs)}\n")
print(f"{'粒度':<24}{'等位总数':>8}{'≥2家共享':>10}{'≥3家共享':>10}{'覆盖条款%':>10}"
      f"{'两两相似度':>11}{'ANTH~OPENAI':>12}{'保留字段':>12}")
results = []
for label, fn in SCHEMES:
    AL = collections.defaultdict(lambda: collections.defaultdict(set))
    for v in V:
        for (d, aim, dm, c) in REC[v]:
            k = fn(aim, dm, c)
            if k.strip("|-"):
                AL[v][d].add(k)
    allal = collections.Counter(); share = collections.Counter()
    for v in V:
        for d in DIMS:
            for a in AL[v].get(d, set()):
                allal[a] += 1
    byal = collections.defaultdict(set)
    for v in V:
        for d in DIMS:
            for a in AL[v].get(d, set()): byal[a].add(v)
    g2 = sum(1 for a, vs in byal.items() if len(vs) >= 2)
    g3 = sum(1 for a, vs in byal.items() if len(vs) >= 3)
    tot_al = sum(len(AL[v].get(d, set())) for v in V for d in DIMS)
    cover = sum(1 for v in V for (d, aim, dm, c) in REC[v] if fn(aim, dm, c).strip("|-")) / max(1, sum(len(x) for x in REC.values()))
    sims = []
    for a, b in pairs:
        s = 0.0
        for d in DIMS:
            A, B = AL[a].get(d, set()), AL[b].get(d, set())
            if A or B: s += jac(A, B)
        sims.append(s / len(DIMS))
    an = [s for (a, b), s in zip(pairs, sims) if {a, b} == {"ANTHROPIC", "OPENAI"}][0]
    # 保留字段
    keep = []
    for tag, fnc in [("否", lambda a, m, c: is_negated(a)), ("模", lambda a, m, c: bool(modality(m))),
                     ("条", lambda a, m, c: c)]:
        vals = {fnc(a, m, c) for v in V for (d, a, m, c) in REC[v]}
        keep.append(f"{tag}{'✓' if len(vals) > 1 else '✗'}")
    print(f"{label:<24}{len(allal):>8}{g2:>10}{g3:>10}{cover*100:>9.1f}%"
          f"{sum(sims)/len(sims):>11.3f}{an:>12.3f}{''.join(keep):>12}")
    results.append((label, fn, allal, byal, sum(sims)/len(sims), an))

print("\n=== 每种粒度下 null 对照（逐单元同大小重抽） ===")
for label, fn, allal, byal, obs, an in results:
    AL = collections.defaultdict(lambda: collections.defaultdict(set))
    for v in V:
        for (d, aim, dm, c) in REC[v]:
            k = fn(aim, dm, c)
            if k.strip("|-"): AL[v][d].add(k)
    pools = {d: [a for v in V for a in AL[v].get(d, set())] for d in DIMS}
    nulls = []
    for _ in range(200):
        S2 = collections.defaultdict(dict)
        for v in V:
            for d in DIMS:
                cell = AL[v].get(d, set())
                if not cell: continue
                pool = pools[d]
                S2[v][d] = set(random.sample(pool, len(cell))) if len(pool) >= len(cell) else set(pool)
        s = 0.0
        for a, b in pairs:
            for d in DIMS:
                A, B = S2[a].get(d, set()), S2[b].get(d, set())
                if A or B: s += jac(A, B)
        nulls.append(s / len(DIMS) / len(DIMS))
    nulls.sort()
    p = sum(1 for x in nulls if x >= obs) / len(nulls)
    print(f"  {label:<24} 实测 {obs:.4f}  null 中位 {nulls[len(nulls)//2]:.4f}  "
          f"null95 {nulls[int(.95*len(nulls))]:.4f}  p={p:.3f}{'  ★ 超基线' if p<=0.05 else ''}")

print("\n=== G2（去掉条件）下的跨厂商共享等位 top 20 ===")
label, fn, allal, byal, obs, an = results[1]
shared = sorted(((len(vs), a) for a, vs in byal.items() if len(vs) >= 2), reverse=True)
print(f"  共享等位总数 {len(shared)}（≥2 家）")
for n, a in shared[:20]:
    print(f"    {n:>2}家  {a}")
