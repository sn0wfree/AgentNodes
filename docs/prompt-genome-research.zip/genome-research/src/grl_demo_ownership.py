#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GRL 表达力检验：能不能用 GRL 表达 Anthropic 官方的 ownership 提示？

官方一手源（platform.claude.com/docs/en/.../prompting-claude-fable-5-2，
经 llms-full.txt 抽取）小节 "Say who owns the code"：

  You are the owner and long-term maintainer of this codebase,
  and its design is up to you.

官方实测：合并重复代码 under 10% → about 75%；
          output tokens +70~80%；
          "A rule that limits scope doesn't cancel it."

本脚本做三件事：
  1. 用 GRL 表达这条规则（一条 Rule 对象）
  2. 用三套文风编译回散文
  3. 对照语料：26 家 80 份提示词里有多少家写了这类「所有权型锚定」
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import grl

OFFICIAL = ("You are the owner and long-term maintainer of this codebase, "
            "and its design is up to you.")

STYLES = {
    'xai_policy': {'name': 'xai_policy', 'open': '<policy>', 'close': '</policy>',
                   'modality': {'must': 'MUST', 'must_not': 'MUST NOT', 'should': 'SHOULD',
                                'may': 'MAY', 'can': 'MAY', 'unspecified': ''},
                   'frame': '{body}.'},
    'openai_plain': {'name': 'openai_plain', 'open': '', 'close': '',
                     'modality': {'must': 'must', 'must_not': 'must not', 'should': 'should',
                                  'may': 'may', 'can': 'may', 'unspecified': 'should'},
                     'frame': '{body}.'},
    'anthropic_effect': {'name': 'anthropic_effect', 'open': '', 'close': '',
                          'modality': {'must': 'always', 'must_not': 'never', 'should': 'prefer',
                                       'may': 'may', 'can': 'may', 'unspecified': ''},
                          'frame': '{body}, because it directly affects the user.'},
}

# ── 1. GRL 表达 ─────────────────────────────────────────
r = grl.Rule(
    id='R-ANTH-OWN-001',
    locus='D13',                       # 身份与角色锚定
    tier=1,                           # 行为工件（非 Tier 0 底线）
    cls='regulative',
    modality='should',                # 官方用陈述句，不是 must
    negation='no',
    scope_raw='Say who owns the code',
    scope_key='say-who-owns-the-code',
    addressee='the assistant',
    verb='own',                       # 受控动词
    object_raw='this codebase', object_key='codebase',
    condition_raw='',
    anchor=OFFICIAL,
    statement=OFFICIAL,
    body=OFFICIAL,
    vendor='ANTHROPIC', file='(official prompting guide)',
    eval_keys=['code.dedup_rate', 'code.unrequested_change_rate'],
    unmapped=[], truncated=False,
)

print('=' * 74)
print('1) GRL 表达（一条 Rule 对象）')
print('=' * 74)
print(r.to_grl())

print()
print('=' * 74)
print('2) 三套文风编译回散文')
print('=' * 74)
for name, st in STYLES.items():
    out = grl.compile_rule(r, st)
    ok, d = grl.check_polarity(r, st)
    print('  %-18s %s' % (name, out))
    print('  %-18s 强度守恒: %s  (slot=%r rank=%s)' % ('', 'PASS' if ok else 'FAIL',
                                                        d.get('slot'), d.get('got_rank')))

print()
print('=' * 74)
print('3) 与官方原句的对照')
print('=' * 74)
print('  官方原句 (%d 字符): %s' % (len(OFFICIAL), OFFICIAL))
c = grl.compile_rule(r, STYLES['anthropic_effect'])
print('  GRL 编译 (%d 字符): %s' % (len(c), c))
print('  槽位保真: %s' % all(
    (not r.object_raw) or (r.object_raw.lower() in c.lower()) for _ in [0]))

print()
print('=' * 74)
print('4) 语料对照：26 家 80 份提示词里，有多少写了「所有权型锚定」？')
print('=' * 74)
ROOT = '/workspace/research/CL4R1T4S-main'
# 词边界匹配：ownership 型（不是 "your call" 这种子串误报）
PATS = [
    r'owner and long-term maintainer',
    r'codebase is yours',
    r'this codebase is (?:yours|your)',
    r'repository is yours',
    r'this repository is (?:yours|your)',
    r'you own (?:this|the) (?:codebase|repository)',
    r'you are the owner',
    r'you(?:’|\')?re the (?:owner|maintainer)',
    r'long-term maintainer',
    r'your call and',
]
RX = re.compile('|'.join(PATS), re.I)
hits = {}
for dp, _, fs in os.walk(ROOT):
    for fn in fs:
        p = os.path.join(dp, fn)
        try:
            t = open(p, encoding='utf-8', errors='ignore').read()
        except Exception:
            continue
        ms = RX.findall(t)
        if ms:
            hits[p] = ms
files = sum(len(fs) for _, _, fs in os.walk(ROOT))
print('  语料文件总数: %d' % files)
print('  命中「所有权型锚定」的文件数: %d' % len(hits))
for p, ms in hits.items():
    print('    - %s   %s' % (p.replace(ROOT + '/', ''), ms[:2]))
if not hits:
    print('    （零命中）')
