#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""机制实验 E2：两条独立管线的交叉验证。

管线 A（上一轮）：正则/关键词 直接扫原始 CL4R1T4S 文件 → 23 维 present/struct/absent
管线 B（本轮）  ：SPDeconstruction 用 LLM 把同一批 prompt 切成 5526 条条款
                  → 同一套关键词跑条款级命中 → 逐厂商 23 维命中数

语料相同、管线不同。若两者在厂商层面给出一致的维度存在性与一致的相似结构，
则「位点存在性 → 家族结构」这条机制链得到外部验证。
"""
import os
import json, glob, os, re, collections, random, math
from genome_lib import LOCI, KW, RX

ROOT = os.environ.get('GRL_CLASSIFICATION_DIR') or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
               'lit/spd/CL4R1T4S-no-code-processed-gemini-flash-3_5/classification')
RD = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding="utf-8"))

# ---------- 关键词匹配（沿用 genome_lib 的 RX 正则 + KW 关键词） ----------
def dim_hits(text):
    """返回该文本命中的维度集合。RX 是 genome_lib 的唯一匹配规则（词边界）。"""
    t = text.lower()
    out = set()
    for d in LOCI:
        if RX[d].search(t):
            out.add(d)
    return out

# ---------- 管线 B：条款级命中 ----------
def load_B():
    per_vendor = collections.defaultdict(collections.Counter)
    nclauses = collections.Counter()
    files_per_vendor = collections.defaultdict(set)
    deontic = collections.defaultdict(collections.Counter)
    for f in sorted(glob.glob(os.path.join(ROOT, "*", "*.json"))):
        v = os.path.basename(os.path.dirname(f))
        files_per_vendor[v].add(os.path.basename(f)[:-5])
        for it in json.load(open(f, encoding="utf-8")):
            nclauses[v] += 1
            txt = (it.get("full_statement") or "") + " " + (it.get("anchor") or "")
            for d in dim_hits(txt):
                per_vendor[v][d] += 1
            if it.get("class") == "regulative":
                rc = it.get("regulative_components") or {}
                d = (rc.get("D") or "").strip().lower()
                deontic[v][d or "(空)"] += 1
    return per_vendor, nclauses, files_per_vendor, deontic

def spearman(x, y):
    def rank(a):
        idx = sorted(range(len(a)), key=lambda i: a[i])
        r = [0.0] * len(a); i = 0
        while i < len(idx):
            j = i
            while j + 1 < len(idx) and a[idx[j + 1]] == a[idx[i]]:
                j += 1
            avg = (i + j) / 2 + 1
            for k in range(i, j + 1):
                r[idx[k]] = avg
            i = j + 1
        return r
    rx, ry = rank(x), rank(y)
    n = len(x)
    mx, my = sum(rx) / n, sum(ry) / n
    num = sum((rx[i] - mx) * (ry[i] - my) for i in range(n))
    den = math.sqrt(sum((rx[i] - mx) ** 2 for i in range(n)) * sum((ry[i] - my) ** 2 for i in range(n)))
    return num / den if den else 0.0

def pearson(x, y):
    n = len(x); mx, my = sum(x) / n, sum(y) / n
    num = sum((x[i] - mx) * (y[i] - my) for i in range(n))
    den = math.sqrt(sum((x[i] - mx) ** 2 for i in range(n)) * sum((y[i] - my) ** 2 for i in range(n)))
    return num / den if den else 0.0

def main():
    B, nclauses, filesB, deontic = load_B()
    vendors = sorted(B)
    print(f"管线 B 覆盖 {len(vendors)} 家厂商，共 {sum(nclauses.values())} 条条款")
    A_v = set(RD["genome"].keys())
    print(f"管线 A 覆盖 {len(A_v)} 家厂商；共同厂商 {len(set(vendors) & A_v)} 家")

    # ---------- 语料覆盖对齐 ----------
    print("\n=== 0. 语料覆盖差异（A 按文件，B 按 SPDeconstruction 处理的文件） ===")
    byv = RD["byv"]
    for v in vendors:
        def stem(n):
            return re.sub(r"\.(md|mdk|txt|json)$", "", os.path.basename(n)).lower()
        fa = {stem(x) for x in byv.get(v, [])}
        fb = {stem(x) for x in filesB[v] if x != "UserStyle_Modes"}
        only_a = fa - fb; only_b = fb - fa
        flag = "" if not only_a else f"  ⚠ A 有 B 没有 {len(only_a)} 份"
        print(f"  {v:<11} A {len(fa):>2} 份 | B {len(fb):>2} 份 | 共同 {len(fa & fb):>2}{flag}")
        if only_a and len(only_a) <= 3:
            print(f"       A 独有: {sorted(only_a)}")

    # ---------- 1. 维度存在性一致性 ----------
    print("\n=== 1. 维度存在性一致性：A 说 absent 的，B 的条款命中数应≈0 ===")
    rows = []
    for d in LOCI:
        a_present = sum(1 for v in vendors if RD["genome"].get(v, {}).get(d) != "absent")
        b_present = sum(1 for v in vendors if B[v][d] > 0)
        a_absent_hits = sum(B[v][d] for v in vendors if RD["genome"].get(v, {}).get(d) == "absent")
        a_present_hits = sum(B[v][d] for v in vendors if RD["genome"].get(v, {}).get(d) != "absent")
        rows.append((d, a_present, b_present, a_absent_hits, a_present_hits))
    print(f"{'维度':<14}{'A覆盖':>6}{'B覆盖':>6}{'A-absent命中':>13}{'A-present命中':>13}{'一致性':>8}")
    agree = 0
    for d, ap, bp, ah, ph in rows:
        same = (ap == bp)
        agree += same
        print(f"{d:<14}{ap:>6}{bp:>6}{ah:>13}{ph:>13}{'✔' if same else '✘':>8}")
    print(f"\n  覆盖数完全一致的维度：{agree}/{len(rows)}")

    # 定量：逐厂商逐维度的二分类一致性
    tp = fp = fn = tn = 0
    for v in vendors:
        for d in LOCI:
            a = RD["genome"].get(v, {}).get(d) != "absent"
            b = B[v][d] > 0
            if a and b: tp += 1
            elif a and not b: fn += 1
            elif not a and b: fp += 1
            else: tn += 1
    po = (tp + tn) / (tp + fp + fn + tn)
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / (tp + fp + fn + tn) ** 2
    kappa = (po - pe) / (1 - pe) if pe < 1 else 0
    print(f"  厂商×维度 二分类一致率 {po*100:.1f}%  Cohen's κ = {kappa:.3f}")
    print(f"    A说无B也有(FP)={fp}  A说有B无(FN)={fn}  都说有={tp}  都说无={tn}")

    # ---------- 2. 厂商相似结构一致性 ----------
    print("\n=== 2. 厂商相似结构一致性（两份独立管线的距离矩阵相关） ===")
    # A：存在集 Jaccard（RD['D'] 就是这个）
    DA = RD["D"]
    # B：23 维条款命中率向量的 1 - Pearson
    def b_vec(v):
        n = max(1, nclauses[v])
        return [B[v][d] / n for d in LOCI]
    VB = {v: b_vec(v) for v in vendors}
    pairs = []
    for i, a in enumerate(vendors):
        for b in vendors[i+1:]:
            pairs.append((a, b, DA[a][b], 1 - pearson(VB[a], VB[b])))
    x = [p[2] for p in pairs]; y = [p[3] for p in pairs]
    rho = spearman(x, y)
    pr = pearson(x, y)
    print(f"  {len(pairs)} 对厂商：Spearman ρ = {rho:.3f}   Pearson r = {pr:.3f}")

    # Null 对照：打乱 B 的厂商标签（保留每家条款数），重算
    random.seed(20261118)
    nulls = []
    for _ in range(300):
        perm = vendors[:]
        random.shuffle(perm)
        vp = {v: VB[perm[i]] for i, v in enumerate(vendors)}
        yy = [1 - pearson(vp[a], vp[b]) for a, b, _, _ in pairs]
        nulls.append(spearman(x, yy))
    nulls.sort()
    p_ge = sum(1 for n in nulls if n >= rho)
    print(f"  Null（打乱厂商标签 300 次）：ρ 中位 {nulls[len(nulls)//2]:+.3f}，"
          f"95 分位 {nulls[int(.95*len(nulls))]:+.3f}，实测 ρ={rho:+.3f} 落在 p≤{p_ge/300:.3f}")

    # 最像与最不像的 5 对
    pairs_sorted = sorted(pairs, key=lambda p: -p[2])
    print("\n  按管线 A 距离最相似的 5 对（A距离 / B距离）：")
    for a, b, da, db in pairs_sorted[:5]:
        print(f"    {a:<11} {b:<11} A={da:.3f}  B={db:.3f}")
    pairs_sorted2 = sorted(pairs, key=lambda p: p[2])
    print("  按管线 A 距离最不相似的 3 对：")
    for a, b, da, db in pairs_sorted2[:3]:
        print(f"    {a:<11} {b:<11} A={da:.3f}  B={db:.3f}")

    # ---------- 3. 强制度交叉验证 ----------
    print("\n=== 3. 强制度：A 的强制构造计数 vs B 的显式 deontic 抽取率 ===")
    print(f"{'厂商':<12}{'A强制构造数':>12}{'A条款数':>9}{'A构造/千条':>12}{'B显式模态%':>13}{'B空值%':>9}")
    rows3 = []
    for v in vendors:
        enf = RD["ENF"].get(v, {}).get("total", 0)
        nA = RD["cov"].get(v, {}).get("files", 0)
        tot = sum(deontic[v].values()) or 1
        empty = deontic[v].get("(空)", 0)
        explicit = (tot - empty) / tot * 100
        rows3.append((v, enf, explicit))
        print(f"{v:<12}{enf:>12}{'':>9}{'':>12}{explicit:>12.1f}%{empty/tot*100:>8.1f}%")
    ea = [r[1] for r in rows3]; eb = [r[2] for r in rows3]
    print(f"\n  两口径 Spearman ρ = {spearman(ea, eb):+.3f}   Pearson r = {pearson(ea, eb):+.3f}")
    print("  ★ 口径不同：A 数的是「强制措辞构造出现次数」，B 数的是「条款带显式模态的比例」——")
    print("    后者已按条款数归一，前者未归一，故这里只看秩相关。")

if __name__ == "__main__":
    main()
