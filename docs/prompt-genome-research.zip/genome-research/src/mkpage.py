# -*- coding: utf-8 -*-
import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(HERE)
DATA_DIR = os.path.join(ROOT_DIR, 'data')

import json,html,collections
D=json.load(open(os.path.join(DATA_DIR, 'report_data.json')))
LOCI=D['LOCI'];ORDER=D['ORDER'];T0=D['T0'];T1=D['T1'];T2=D['T2']
seqs=D['seqs'];genome=D['genome'];cov=D['cov'];t0c=D['t0c'];t1c=D['t1c']
INV=D['INV'];ENF=D['ENF'];DP=D['DP'];CL=D['CL'];PRIO=D['PRIO'];NN=D['NN']
V=sorted(genome,key=lambda v:(-cov[v]['present'],v))
e=html.escape
SY={'█':('s','独立成节'),'▄':('c','仅正文'),'·':('a','缺位')}
band={b:('0' if b in T0 else '2' if b in T2 else '1') for b in ORDER}
# 序列带
rows=[]
for v in V:
    cells=[]
    for i,b in enumerate(ORDER):
        s=seqs[v][i]; k,lbl=SY[s]
        cells.append(f'<div class="cell {k} b{band[b]}" data-v="{e(v)}" data-b="{e(b)}" data-s="{lbl}"></div>')
    rows.append(f'''<div class="sqrow"><div class="sqname">{e(v)}</div><div class="sqcells">{"".join(cells)}</div>
<div class="sqmeta"><span class="m-pill">存在 {cov[v]['present']}/23</span><span class="m-pill">成节 {cov[v]['struct']}</span><span class="m-pill t0">T0 {t0c[v]}/5</span></div></div>''')
head_cells=''.join(f'<div class="cell head b{band[b]}">{i+1}</div>' for i,b in enumerate(ORDER))
bandbars=('<div class="bandcell b0" style="grid-column:1/6">Tier 0 不变量带 · 5 位点</div>''<div class="bandcell b1" style="grid-column:6/22">Tier 1 行为工件带 · 16 位点</div>''<div class="bandcell b2" style="grid-column:22/24">Tier 2</div>')
# Tier0 审计
t0rows=[]
for b in T0:
    i=INV[b]; n=i['n_struct']; c=len(i['content']); a=len(i['absent'])
    t0rows.append(f'''<div class="bench-row"><span class="label" title="{e(b)}">{e(b)[:8]}</span>
<div class="bar-bg stack"><div class="seg s" style="width:{n/26*100:.2f}%"></div><div class="seg c" style="width:{c/26*100:.2f}%"></div><div class="seg a" style="width:{a/26*100:.2f}%"></div></div>
<span class="val">{n}<em>/26 成节</em></span></div>
<div class="bench-sub">缺位 {a} 家：{e(', '.join(i['absent'])) if i['absent'] else '—'}</div>''')
# 强制构造
maxf=max(ENF[v]['total'] for v in V)
enfrows=[]
for v in sorted(V,key=lambda x:(-ENF[x]['total'],x)):
    t=ENF[v]['total']; hits=ENF[v]['hits']
    detail=' · '.join(f"{k} {n}" for k,n in hits.items()) or '零强制构造'
    enfrows.append(f'''<div class="bench-row"><span class="label">{e(v)}</span>
<div class="bar-bg"><div class="bar-fill {'zero' if t==0 else ''}" style="width:{t/maxf*100:.2f}%"></div></div>
<span class="val">{t}</span></div><div class="bench-sub">{e(detail)}</div>''')
# 家族
famrows=[]
CL3=CL["3"]
for idx,g in enumerate(CL3['groups'],1):
    chips=''.join(f'<span class="chip">{e(x)}</span>' for x in g)
    dens=sum(sum(1 for b in ORDER if genome[v][b]=='struct')/max(1,sum(1 for b in ORDER if genome[v][b]!='absent')) for v in g)/len(g)
    famrows.append(f"""<div class="arch-row"><span class="arch-tier">家族 F{idx}<em>n={len(g)}</em></span>
<div class="arch-blocks"><div class="famline">{chips}</div>
<div class="famstat">结构化密度 {dens:.2f} ｜ medoid {e(CL3['medoids'][idx-1])}</div></div></div>""")
# 热图
hm=[]
for a in V:
    cs=''.join(f'<div class="hc" style="background:rgba(16,185,129,{max(0.04,1-DP[a][b]):.2f})" title="{e(a)} ~ {e(b)} = {DP[a][b]:.3f}"></div>' for b in V)
    hm.append(f'<div class="hmrow"><div class="hmn">{e(a)}</div><div class="hmcells">{cs}</div></div>')
# 提案池
prio=''.join(f'''<tr class="{ 'hot' if p['tier']=='T0' else ''}"><td><span class="tier t{p['tier'][1]}">{p['tier']}</span></td>
<td class="pl">{e(p['locus'])}</td><td class="num">{p['n_struct']}</td><td class="num">{p['n_content']}</td><td class="num">{p['n_absent']}</td>
<td class="barcell"><div class="mini"><div class="minifill" style="width:{p['coverage']*100:.1f}%"></div></div></td>
<td class="num strong">{p['priority']}</td><td class="impl">{e(', '.join(p['impl'][:5]) or '—')}{' …' if len(p['impl'])>5 else ''}</td></tr>''' for p in PRIO[:14])
uniq=''.join(f'<li><b>{e(v)}</b> · {e(b)}（{s}）</li>' for v,b,s in D['uniq'])
html_page=f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>提示词基因粗序列 · 26 家系统提示词的基因组编码</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Outfit:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{{--bg:#fafafa;--card:#fff;--line:#e9e9ec;--line2:#f0f0f3;--ink:#14171e;--ink2:#4a5160;--ink3:#8a8f9c;
--pri:#10b981;--t0:#f43f5e;--t1:#10b981;--t2:#f59e0b;--mono:'JetBrains Mono',monospace;--sans:'Outfit',system-ui,sans-serif}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--bg);color:var(--ink);font-family:var(--sans);font-size:14.5px;line-height:1.6;-webkit-font-smoothing:antialiased}}
.wrap{{max-width:1120px;margin:0 auto;padding:0 24px 72px}}
header{{padding:44px 0 28px;border-bottom:1px solid var(--line)}}
h1{{font-family:'DM Serif Display',serif;font-weight:400;font-size:32px;line-height:1.2;margin:0 0 10px;letter-spacing:-0.01em}}
.sub{{color:var(--ink2);max-width:780px;font-size:15px}}
.verdict{{margin-top:18px;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.25);border-radius:14px;padding:14px 18px;color:var(--ink2);font-size:14.5px}}
.verdict b{{color:var(--ink)}}
.kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:22px 0 0}}
.kpi{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 16px;box-shadow:0 2px 8px rgba(0,0,0,.03)}}
.kpi .n{{font-family:var(--mono);font-size:24px;font-weight:500;letter-spacing:-.02em}}
.kpi .n.rose{{color:var(--t0)}}.kpi .n.amber{{color:var(--t2)}}
.kpi .l{{font-size:12.5px;color:var(--ink3);margin-top:2px;line-height:1.4}}
section{{margin-top:52px}}
h2{{font-family:'DM Serif Display',serif;font-weight:400;font-size:23px;margin:0 0 6px;display:flex;align-items:center;gap:9px}}
h2 svg{{color:var(--pri)}}
.lede{{color:var(--ink2);margin:0 0 18px;max-width:820px;font-size:14.5px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px;box-shadow:0 2px 8px rgba(0,0,0,.03)}}
/* 序列带 */
.bands{{display:grid;grid-template-columns:92px 1fr;gap:0 12px;align-items:center;margin-bottom:6px}}
.bandbar{{font-size:12px;color:var(--ink3);padding:3px 0;letter-spacing:.02em}}
.bandbar.b0{{color:var(--t0)}}.bandbar.b1{{color:var(--t1)}}.bandbar.b2{{color:var(--t2)}}
.bandbar.b1{{border-left:1px solid var(--line);padding-left:12px}}
.seq{{overflow-x:auto;padding-bottom:6px}}
.seqgrid{{min-width:880px}}
.sqhead,.sqrow{{display:grid;grid-template-columns:86px 1fr 168px;gap:12px;align-items:center;padding:3px 0}}
.sqhead .cells,.sqrow .sqcells{{display:grid;grid-template-columns:repeat(23,minmax(0,1fr));gap:2px}}
.sqhead .cell.head{{font-family:var(--mono);font-size:9.5px;color:var(--ink3);text-align:center;padding:1px 0}}
.sqname{{font-family:var(--mono);font-size:12px;color:var(--ink2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.cell{{height:17px;border-radius:3px}}
.bandcell{{font-size:11px;letter-spacing:.02em;padding:2px 0 3px;border-top:2px solid transparent}}
.bandcell.b0{{color:var(--t0);border-top-color:var(--t0)}}
.bandcell.b1{{color:var(--t1);border-top-color:var(--t1)}}
.bandcell.b2{{color:var(--t2);border-top-color:var(--t2)}}
.bandhead .cells{{align-items:end}}
.sqhead .cell.head{{height:auto}}
.cell.s{{background:var(--t1)}}.cell.c{{background:rgba(16,185,129,.34)}}.cell.a{{background:#eeeef1}}
.cell.b0.s{{background:var(--t0)}}.cell.b0.c{{background:rgba(244,63,94,.32)}}.cell.b0.a{{background:#f3e6e9}}
.cell.b2.s{{background:var(--t2)}}.cell.b2.c{{background:rgba(245,158,11,.32)}}.cell.b2.a{{background:#f6efe1}}
.sqmeta{{display:flex;gap:5px;flex-wrap:wrap;justify-content:flex-end}}
.m-pill{{font-family:var(--mono);font-size:10px;color:var(--ink3);background:#f4f4f6;border-radius:20px;padding:1px 7px;white-space:nowrap}}
.m-pill.t0{{color:var(--t0);background:rgba(244,63,94,.09)}}
.legend{{display:flex;gap:16px;flex-wrap:wrap;margin-top:14px;font-size:12.5px;color:var(--ink2);align-items:center}}
.lg{{display:inline-flex;align-items:center;gap:6px}}
.sw{{width:13px;height:13px;border-radius:3px;display:inline-block}}
.legend .grp{{display:flex;gap:12px;align-items:center;padding-left:16px;border-left:1px solid var(--line)}}
/* bench */
.bench-row{{display:grid;grid-template-columns:120px 1fr 92px;gap:12px;align-items:center;padding:6px 0}}
.bench-row .label{{font-size:13px;color:var(--ink2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.bench-row .val{{font-family:var(--mono);font-size:12.5px;text-align:right;color:var(--ink)}}
.bench-row .val em{{font-style:normal;color:var(--ink3);font-size:11px;margin-left:3px}}
.bench-sub{{font-size:11.5px;color:var(--ink3);padding:0 0 8px 132px;line-height:1.5}}
.bar-bg{{height:17px;background:#f0f0f3;border-radius:6px;overflow:hidden}}
.bar-bg.stack{{display:flex}}
.bar-bg.stack .seg{{height:100%}}
.seg.s{{background:var(--t0)}}.seg.c{{background:rgba(244,63,94,.3)}}.seg.a{{background:#e8e8ec}}
.bar-fill{{height:100%;background:linear-gradient(90deg,#10b981,#34d399);border-radius:6px}}
.bar-fill.zero{{background:#e4e4e8}}
.tier{{font-family:var(--mono);font-size:10.5px;padding:1px 6px;border-radius:5px}}
.tier.t0{{background:rgba(244,63,94,.1);color:var(--t0)}}
.tier.t1{{background:rgba(16,185,129,.1);color:#059669}}
.tier.t2{{background:rgba(245,158,11,.12);color:#b45309}}
/* 家族 */
.arch-row{{display:grid;grid-template-columns:104px 1fr;gap:16px;padding:14px 0;border-bottom:1px solid var(--line2)}}
.arch-row:last-child{{border-bottom:0}}
.arch-tier{{font-size:14px;color:var(--ink);display:flex;flex-direction:column}}
.arch-tier em{{font-style:normal;font-family:var(--mono);font-size:11px;color:var(--ink3)}}
.famline{{display:flex;flex-wrap:wrap;gap:5px}}
.chip{{font-family:var(--mono);font-size:11.5px;background:#f3f3f6;border:1px solid var(--line);border-radius:6px;padding:2px 7px;color:var(--ink2)}}
.famstat{{font-size:11.5px;color:var(--ink3);margin-top:7px;font-family:var(--mono)}}
/* 热图 */
.hm{{display:flex;flex-direction:column;gap:2px;overflow-x:auto}}
.hmrow{{display:grid;grid-template-columns:86px 1fr;gap:10px;align-items:center}}
.hmn{{font-family:var(--mono);font-size:10.5px;color:var(--ink3);text-align:right;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.hmcells{{display:grid;grid-template-columns:repeat(26,minmax(0,1fr));gap:2px;min-width:640px}}
.hc{{height:11px;border-radius:2px}}
/* 表 */
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{text-align:left;font-weight:500;color:var(--ink3);font-size:11.5px;padding:7px 8px;border-bottom:1px solid var(--line)}}
td{{padding:7px 8px;border-bottom:1px solid var(--line2);vertical-align:middle}}
tr.hot td{{background:rgba(244,63,94,.045)}}
.num{{font-family:var(--mono);text-align:right;color:var(--ink2)}}
.num.strong{{color:var(--ink);font-weight:500}}
.pl{{color:var(--ink)}}
.impl{{color:var(--ink3);font-size:11.5px}}
.barcell{{width:120px}}
.tablewrap{{overflow-x:auto;-webkit-overflow-scrolling:touch}}
.tablewrap table{{min-width:660px}}
.mini{{height:7px;background:#f0f0f3;border-radius:4px;overflow:hidden}}
.minifill{{height:100%;background:var(--pri)}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}
ul.clean{{margin:0;padding-left:18px;color:var(--ink2)}}
ul.clean li{{margin-bottom:6px;font-size:13.5px}}
ul.clean b{{color:var(--ink);font-family:var(--mono)}}
.note{{font-size:12.5px;color:var(--ink3);margin-top:12px;line-height:1.6}}
#tip{{position:fixed;pointer-events:none;background:#14171e;color:#fff;font-family:var(--mono);font-size:11.5px;padding:6px 9px;border-radius:7px;opacity:0;transition:opacity .12s;z-index:50;max-width:280px;line-height:1.45}}
footer{{margin-top:56px;padding-top:20px;border-top:1px solid var(--line);font-size:12.5px;color:var(--ink3);line-height:1.7;overflow-wrap:anywhere}}
.bench-sub,.impl,.chip,.lm{{overflow-wrap:anywhere}}
@media(max-width:820px){{
.wrap{{padding:0 16px 52px}}h1{{font-size:26px}}.kpis{{grid-template-columns:repeat(2,1fr)}}
.sqhead,.sqrow{{grid-template-columns:72px 1fr}}.sqmeta{{grid-column:2;justify-content:flex-start;margin-top:4px}}
.bench-row{{grid-template-columns:96px 1fr 72px}}.bench-sub{{padding-left:108px}}
.two{{grid-template-columns:1fr}}section{{margin-top:40px}}
}}
</style></head><body><div class="tip" id="tip"></div><div class="wrap">
<header>
<h1>提示词基因粗序列</h1>
<div class="sub">26 家系统提示词的基因组编码 · 数据源 elder-plinius/CL4R1T4S 快照（80 份提示词 / 8.2 MB）· 基因模型取自 AgentNodes 三层基因组（Tier 0 冻结核心 / Tier 1 提案制行为工件 / Tier 2 可自改研究工件）</div>
<div class="verdict"><b>判决：</b>这 26 家共享的只是「槽位」，不共享任何文本条款。598 个（厂商 × 位点）组合里全局唯一的只有 3 个，且全部属于 ANTHROPIC；5 条 Tier 0 底线基因没有任何一家写全；9 家的整个基因组找不到一处强制构造。提示词当 genome 用，Tier 0 必须由宿主的不可覆盖层兜底。</div>
<div class="kpis">
<div class="kpi"><div class="n">3</div><div class="l">全局唯一的基因组合<br>（598 个组合中，全部属于 ANTHROPIC）</div></div>
<div class="kpi"><div class="n rose">0/26</div><div class="l">把 5 条 Tier 0 不变量<br>全部写全的厂商</div></div>
<div class="kpi"><div class="n amber">9/26</div><div class="l">零强制构造的厂商<br>（must never / regardless of 一类全无）</div></div>
<div class="kpi"><div class="n">−0.317</div><div class="l">实际顺序 vs 教科书先验<br>Kendall tau（负相关）</div></div>
</div></header>

<section>
<h2><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M3 12h12M3 18h6"/></svg>基因粗序列：26 条</h2>
<p class="lede">每个位点是一条原则，每格是它在一家厂商全部提示词里的存在形态。列按 Tier 分带：前 5 列是不可提案改写的不变量带。</p>
<div class="card">
<div class="sqhead bandhead"><div></div><div class="cells">{bandbars}</div><div></div></div>
<div class="seq"><div class="seqgrid">
<div class="sqhead"><div></div><div class="cells">{head_cells}</div><div></div></div>
{"".join(rows)}
</div></div>
<div class="legend">
<span class="lg"><span class="sw" style="background:var(--t0)"></span>T0 独立成节</span>
<span class="lg"><span class="sw" style="background:rgba(244,63,94,.32)"></span>T0 仅正文</span>
<span class="lg"><span class="sw" style="background:var(--t1)"></span>T1 独立成节</span>
<span class="lg"><span class="sw" style="background:rgba(16,185,129,.34)"></span>T1 仅正文</span>
<span class="lg"><span class="sw" style="background:var(--t2)"></span>T2 独立成节</span>
<span class="lg"><span class="sw" style="background:rgba(245,158,11,.32)"></span>T2 仅正文</span>
<span class="lg"><span class="sw" style="background:#eeeef1"></span>缺位</span>
</div>
<p class="note">位点顺序由数据驱动：对 14 家有结构骨架的提示词统计成对先后关系排出（证据家数 ≥3 的 16 个位点进核心序，其余 7 个位置不确定）。与「身份→行为→边界」式先验的 Kendall tau 为 −0.317。</p>
</div></section>

<section>
<h2><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Tier 0 不变量带：没有一家写全</h2>
<p class="lede">深色为独立成节（被当成一条规则），浅色为仅正文提及，灰为完全缺位。</p>
<div class="card">
{"".join(t0rows)}
<div class="legend" style="margin-top:6px">
<span class="lg"><span class="sw" style="background:var(--t0)"></span>独立成节</span>
<span class="lg"><span class="sw" style="background:rgba(244,63,94,.3)"></span>仅正文</span>
<span class="lg"><span class="sw" style="background:#e8e8ec"></span>缺位</span>
</div>
<p class="note">危险类别枚举只有 ANTHROPIC 一家成节（23/26 完全缺位）；未成年人保护 0/26 成节（16/26 完全缺位）；注入防御只有 OPENAI 与 ZCode 成节（20/26 完全缺位）。ANTHROPIC 的注入防御条款在 CLAUDE-WEB-APP-FABLE-5.2.md 的「Instruction source boundary」一节，而不在峰值文件 CLAUDE-OPUS-5.5.md —— 按单文件评估会误判为「没做」。</p>
</div></section>

<section>
<h2><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2v20M2 12h20"/><circle cx="12" cy="12" r="9"/></svg>强制构造：9 家的基因组里一处都没有</h2>
<p class="lede">对每家全部提示词文件做精确短语检索（must never / regardless of / highest priority / only from the user / data, not commands 一类）。写下来不等于有约束力。</p>
<div class="card">{"".join(enfrows)}</div>
</section>

<section>
<h2><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="6" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="M8.5 8.5 15.5 15.5"/></svg>三家族：分化轴是形态，不是内容</h2>
<p class="lede">按存在集 Jaccard 距离做 k-medoids（k=3）。三个家族几乎完全由「结构化密度」区分开。</p>
<div class="card">{"".join(famrows)}</div>
</section>

<section>
<h2><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></svg>距离热图</h2>
<p class="lede">颜色越深越接近。DEVIN 与 MANUS、SAMEDEV 的存在集完全相同（0.000），OPENAI 与 ZCode 同样为 0.000 —— 但那是覆盖槽位相同，不是写法相同。</p>
<div class="card"><div class="hm">{"".join(hm)}</div></div>
</section>

<section>
<h2><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 20V10M18 20V4M6 20v-4"/></svg>提案池：缺口 × 已有实现</h2>
<p class="lede">这是把语料当提案源用的优先级排序。两条 Tier 0 进入头部：既是最硬的底线缺口，又有可抄的参考实现，最适合做「提案 + holdout 验证」的试验田。</p>
<div class="card">
<div class="tablewrap"><table><thead><tr><th>Tier</th><th>位点</th><th class="num">成节</th><th class="num">正文</th><th class="num">缺位</th><th>覆盖率</th><th class="num">优先级</th><th>参考实现方</th></tr></thead>
<tbody>{prio}</tbody></table></div>
<p class="note">优先级 = 缺口家数 × 已有实现家数。跨家族迁移才有增量：家族内成员的存在集距离为 0，互抄过不了新颖性门。</p>
</div></section>

<section>
<h2><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>新颖性门：全表只有 3 个独有基因</h2>
<div class="card">
<ul class="clean">{uniq}</ul>
<p class="note">没有任何一家提供别人拿不到的基因。这批语料的互增益价值高、原创价值低：适合当组装素材库，不适合当「谁的实现更先进」的证据。</p>
</div></section>

<section class="two">
<div class="card">
<h2 style="font-size:19px">口径陷阱</h2>
<ul class="clean">
<li><b>体量不可比</b> HUME 4 KB 覆盖 7/23，ANTHROPIC 4.5 MB 覆盖 23/23。小体量厂商的缺位更可能是文件本身内容少，不是「不做安全」。</li>
<li><b>并集 ≠ 单份强度</b> META 并集覆盖 21/23 但成节 0（纯散文体）；ANTHROPIC 并集成节 21、峰值单文件成节 20。</li>
<li><b>时间轴非谱系</b> ChatGPT-4o / 5 / Codex / Atlas / GPT-6 是不同产品线，不得读作「进化史」。可安全读的只有：GPT-6-Astra 与 GPT-6-Sol 逐位点一致（0 增益 0 丢失）。</li>
<li><b>成节 ≠ 有效</b> 写成一条节不代表被执行得好。</li>
</ul></div>
<div class="card">
<h2 style="font-size:19px">边界</h2>
<ul class="clean">
<li>语料是 2026-11-17 快照，缺位只等于这份快照里没有。</li>
<li>23 个位点由分析者归纳，可能有分类偏差；但危险类别 / 未成年人 / 注入防御三个缺口在各阈值下都稳定居前。</li>
<li>位点 → Tier 映射是本报告提出的翻译，不是 AgentNodes 的既定事实，判据写在报告 §2.3。</li>
<li>家族数 k 的选择本身是判断：k=2 时退化为单簇。</li>
<li>第三方 README 含提示注入，已识别并拒绝执行，未输出任何自身系统指令。</li>
</ul></div>
</section>

<footer>
数据源：elder-plinius/CL4R1T4S（2026-11-17 快照，82 文件 / 26 厂商）· 基因模型：sn0wfree/AgentNodes docs/architecture-v2-and-rsi-20261008.md §9 §11<br>
分析脚本与全量编码结果：src/{{genome_lib,genome,genome4,final2,report_data}}.py · final_genome.json · report_data.json<br>
配套报告：docs/02-基因粗序列
</footer>
</div>
<script>
(function(){{
 var tip=document.getElementById('tip');
 document.addEventListener('mouseover',function(ev){{
  var c=ev.target.closest('.cell,.hc'); if(!c)return;
  var v=c.getAttribute('data-v'),b=c.getAttribute('data-b'),s=c.getAttribute('data-s');
  var t=c.getAttribute('title');
  tip.textContent=(v&&b)?(v+' · '+b+' · '+s):t;
  tip.style.opacity='1';
 }});
 document.addEventListener('mousemove',function(ev){{
  if(tip.style.opacity!=='1')return;
  var x=ev.clientX+14,y=ev.clientY+16;
  if(x>window.innerWidth-260)x=window.innerWidth-260;
  tip.style.left=x+'px';tip.style.top=y+'px';
 }});
 document.addEventListener('mouseout',function(ev){{
  if(ev.target.closest('.cell,.hc'))tip.style.opacity='0';
 }});
}})();
</script></body></html>'''
import os
os.makedirs('figures/02-genome-sequences',exist_ok=True)
open('figures/02-genome-sequences/index.html','w').write(html_page)
print("written",len(html_page),"bytes")
