#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""数据脱敏：把厂商提示词的原文片段替换成 sha256 锚点。

为什么需要：CL4R1T4S 用 AGPL-3.0 覆盖了 Anthropic/OpenAI/xAI 等厂商的**专有提示词**，
维护者无权授予该许可。本仓库只发布「我们自己的分析产出」与「学术引用级短片段」，
**不复制受版权保护的语料正文**。条款级数据导出（grl_out*.json）里含原文，
用本脚本替换成可回查的 sha256 锚点。

用法：
    python3 sanitize.py                 # 处理 data/grl_out.json 与 data/grl_out2.json
    python3 sanitize.py --check         # 只检查不写入（CI 用：检出未脱敏内容即退出非 0）

脱敏规则：任何字符串值里出现的、长度 >= MIN_LEN 的连续英文文本片段，
替换为 "sha256:<16位十六进制>#len=<原长度>"。短片段（学术引用级）保留不动。
"""
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(os.path.dirname(HERE), 'data')
MIN_LEN = 40
# 连续英文文本：首字母大写，允许空格/标点/数字
LONG = re.compile(r"[A-Z][A-Za-z0-9 ,'\"\-]{%d,}" % (MIN_LEN - 1))

TARGETS = ['grl_out.json', 'grl_out2.json']


def digest(s):
    return 'sha256:' + hashlib.sha256(s.encode('utf-8')).hexdigest()[:16] + '#len=%d' % len(s)


def sanitize_obj(o, anchors):
    if isinstance(o, dict):
        return {k: sanitize_obj(v, anchors) for k, v in o.items()}
    if isinstance(o, list):
        return [sanitize_obj(v, anchors) for v in o]
    if isinstance(o, str):
        def sub(m):
            raw = m.group(0).strip()
            if len(raw) < MIN_LEN:
                return m.group(0)
            d = digest(raw)
            # 连预览都不保留：预览本身就是原文片段。回查靠 sha256 对原始语料重算。
            anchors[d] = {'sha256': d, 'length': len(raw)}
            return d
        return LONG.sub(sub, o)
    return o


def has_long_text(o):
    # 判据必须直接查「还有没有长英文片段残留」，
    # 不能拿「序列化结果 != 原文件」当脏 —— 那会把格式差异误报成未脱敏。
    if isinstance(o, dict):
        return any(has_long_text(v) for v in o.values())
    if isinstance(o, list):
        return any(has_long_text(v) for v in o)
    if isinstance(o, str):
        return bool(LONG.search(o))
    return False


def main():
    check_only = '--check' in sys.argv
    anchors = {}
    dirty = []
    for name in TARGETS:
        p = os.path.join(DATA, name)
        if not os.path.exists(p):
            continue
        raw = open(p, encoding='utf-8').read()
        obj = json.loads(raw)
        if has_long_text(obj):
            dirty.append(name)
        if not check_only:
            clean = sanitize_obj(obj, anchors)
            open(p, 'w', encoding='utf-8').write(
                json.dumps(clean, ensure_ascii=False, indent=1))
    ap = os.path.join(DATA, 'anchors.json')
    if anchors:
        if not check_only:
            open(ap, 'w', encoding='utf-8').write(
                json.dumps({'note': '原文片段的 sha256 锚点表；回查方法见 README',
                            'anchors': list(anchors.values())},
                           ensure_ascii=False, indent=1))
        print('脱敏片段 %d 处，涉及文件 %s' % (len(anchors), ', '.join(dirty) or '无'))
    else:
        print('无需脱敏（未发现长英文片段）')
        # anchors 为空说明数据已是脱敏态 —— 保留既有的 anchors.json（它是回查索引，
        # 不能因为二次运行 anchors 为空就删掉）；但要确保它本身不含 preview 字段。
    if check_only and dirty:
        print('FAIL: 以下文件仍含未脱敏的长原文片段：%s' % ', '.join(dirty))
        return 1
    print('PASS: 数据文件已脱敏' if dirty else 'PASS: 数据文件干净')
    return 0


if __name__ == '__main__':
    sys.exit(main())
