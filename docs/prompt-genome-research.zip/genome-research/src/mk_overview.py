#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成研究线全景页（讨论入口）。数字全部从实验 JSON 读，不手抄。"""
import json
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'figures', '05-grl-language', 'overview.html')
sys.path.insert(0, HERE)

rd = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'report_data.json'), encoding='utf-8'))
ds = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'dimspec.json'), encoding='utf-8'))
aa = json.load(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data', 'allele_axis.json'), encoding='utf-8'))
# 注意：grl_out.json 是第一轮实验的产物，其中模态分布是「否定全句扫描」修正前的口径
# => 存在性层/等位层数字从 report_data/dimspec/allele_axis 读（稳定），
#    条款级数字一律用【当前代码】重算，不读旧实验快照。
import grl as _grl
_R, _S = _grl.load_corpus()
_REG = [r for r in _R if r.cls == 'regulative']
modc = dict(Counter(r.modality for r in _REG))
negc = dict(Counter(r.negation for r in _REG))

# 存在性图案
seqs = rd['seqs']
groups = {}
for v, s in seqs.items():
    key = ''.join('1' if c != '·' else '0' for c in s)
    groups.setdefault(key, []).append(v)
shared = [(k, v) for k, v in groups.items() if len(v) > 1]

SPEC = ds['SPEC']
quads = Counter(s['quad'] for s in SPEC)
DIMS = aa['dims']


ROUNDS = [
    ('R1', '项目评估', '内容可用，但授权瑕疵优先于内容质量；README 含提示注入（已拒绝执行）', 'cl4r1t4s-review/'),
    ('R2', '共性原则', '「人人都在写」≠「人人当成一条规则」—— 结构级 / 内容级分列', '提示词共性原则'),
    ('R3', '基因粗序列', '23 位点 × 26 家 → 23 种存在性图案；全局唯一组合只有 3 个', 'prompt-genome/'),
    ('R4', '写作规范', '覆盖广度 × 约束强度两轴；强制措辞按章节判定不按行', 'prompt-dims/'),
    ('R5', '业界先例调研', '无直接先例但零件全齐；P4（跨 prompt 逐位点对齐 + 共识序 + 家族聚类）是真空白', 'prompt-genome-lit/'),
    ('R6', '机制实测修订 v2', '等位轴第三条轴成立；「Tier 0 没写全」是定制化的必然结果', '机制实测修订-v2'),
    ('R7', 'GRL 基因规约语', 'JSONC + 四种引用 + 5526 条上闭环 + 18 条判据全过', 'grl-language/'),
    ('R8', '讨论总纲', '本轮', '本文件'),
]

QS = [
    ('Q1', 'eval 字段挂真实评测分数', '机制已定义，一格数据都没填', '全线上唯一的「机制有、数据空」缺口 —— 决定 GRL 是描述还是基因', '中高', 1),
    ('Q5', '用 GRL 重算存在性层的 23 种图案', 'R3 用的是文件级正则，条款级没复核过', '验证 R3 核心结论是否稳健；数据都在', '低', 2),
    ('Q3', '位点自动归属怎么定', '唯一归属率仅 54.6%', '人工标注 / 多标签+置信度 / 放弃条款级 locus，三选一', '低-中', 3),
    ('Q4', '条件字段的可信度处置', '31.9% 条件被语义截断', '重跑抽取 / 保留标记并排除出比较 / 只比较有条件的子集', '低-中', 4),
    ('Q9', '授权与溯源', '维护者无权授予 AGPL', '自己 fork + 补溯源；所有对外发布的前置', '中', 5),
    ('Q7', '与 AgentNodes Tier 晋级门对接', '那边一步没执行，CI 从未跑过', '阻塞在对方侧', '中', 6),
    ('Q2', '补齐 26 家的条款级数据', 'SPDeconstruction 只跑了 15 家', '跑 LLM 抽取', '高', 7),
    ('Q6', '26 家文风表从哪来', '只有 3 套手写风格', '从各厂原文反推措辞偏好，或承认只是「文风模板」', '中', 8),
    ('Q8', '行为层验证', '一次都没测过', '有/无条款对照组 × 真实模型', '高', 9),
    ('Q10', '「不写免责声明」要不要立规', '唯一「少写为佳」维度，但模态枚举里没有反向档', '要不要加 prohibit 语义位', '低', 10),
]

ROUTES = [
    ('A', '挂评测', 'Q1', 'GRL 从描述变成基因；位点级 diff 立刻可用', 'Q1 成本中高', 1),
    ('B', '稳健性复核', 'Q5 + Q3 + Q4', '验证 R3/R6 核心结论是否稳健', '成本低，数据都在', 2),
    ('C', '接 AgentNodes', 'Q7', '机制有真实落点', '阻塞在对方侧', 3),
    ('D', '对外发布', 'Q9 + Q6', '可被外部使用', '授权前置，风险最高', 4),
]

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0f1115;--panel:#171a21;--panel2:#1d212a;--line:#2a2f3a;--fg:#e6e8ee;
 --dim:#9aa3b2;--acc:#5cc8ff;--ok:#7ee787;--warn:#ffb86b;--bad:#ff7b72;--pp:#d2a8ff}
body{background:var(--bg);color:var(--fg);font:15px/1.72 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;-webkit-font-smoothing:antialiased}
.wrap{max-width:1200px;margin:0 auto;padding:0 20px 80px}
header{padding:52px 0 30px;border-bottom:1px solid var(--line);margin-bottom:34px}
h1{font-size:32px;line-height:1.25;letter-spacing:-.5px;margin-bottom:8px}
h1 span{color:var(--acc)}
.sub{color:var(--dim);font-size:16px;max-width:780px}
.vd{display:inline-block;margin-top:16px;padding:6px 14px;border-radius:6px;background:rgba(126,231,135,.12);
 border:1px solid rgba(126,231,135,.4);color:var(--ok);font:600 12.5px/1 ui-monospace,Menlo,monospace;letter-spacing:.5px}
h2{font-size:20px;margin:40px 0 4px;padding-bottom:9px;border-bottom:1px solid var(--line)}
h2 .n{color:var(--acc);font:600 13px ui-monospace,Menlo,monospace;margin-right:9px}
h3{font-size:15px;margin:20px 0 8px;color:var(--acc)}
p{color:var(--dim);margin:8px 0}
p b{color:var(--fg)}
code{font:12.5px/1.6 ui-monospace,Menlo,monospace;background:var(--panel2);padding:1.5px 5px;border-radius:4px;color:var(--pp)}
.grid{display:grid;gap:11px}.g4{grid-template-columns:repeat(4,1fr)}.g3{grid-template-columns:repeat(3,1fr)}
.g2{grid-template-columns:repeat(2,1fr)}.g2a{grid-template-columns:1.25fr 1fr}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:13px 15px}
.card .v{font:700 24px/1.2 ui-monospace,Menlo,monospace;color:var(--acc)}
.card .v.g{color:var(--ok)}.card .v.w{color:var(--warn)}.card .v.p{color:var(--pp)}
.card .t{font-size:13px;color:var(--fg);margin-top:4px;font-weight:600}
.card .d{font-size:11.5px;color:var(--dim);margin-top:3px;line-height:1.55}
/* 时间线 */
.tl{display:grid;grid-template-columns:repeat(8,1fr);gap:8px;margin-top:14px}
.step{background:var(--panel);border:1px solid var(--line);border-radius:9px;padding:11px 11px 12px;position:relative}
.step .rid{font:700 12px ui-monospace,Menlo,monospace;color:var(--acc);margin-bottom:3px}
.step .rt{font-size:12.5px;font-weight:700;color:var(--fg);margin-bottom:5px;line-height:1.35}
.step .rd{font-size:11.5px;color:var(--dim);line-height:1.55}
.step .rp{font:11px ui-monospace,Menlo,monospace;color:var(--pp);margin-top:6px;word-break:break-all}
.step.cur{border-color:var(--acc);box-shadow:0 0 0 1px rgba(92,200,255,.28)}
/* 层图 */
.layer{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin:9px 0}
.layer .lh{font:700 13px ui-monospace,Menlo,monospace;margin-bottom:7px}
.layer .lb{font-size:12.5px;color:var(--dim);line-height:1.7}
.layer .lb b{color:var(--fg)}
.l0 .lh{color:var(--bad)}.l1 .lh{color:var(--warn)}.l2 .lh{color:var(--ok)}
/* Q 卡 */
.q{background:var(--panel);border:1px solid var(--line);border-radius:9px;padding:11px 13px;display:grid;
 grid-template-columns:44px 1fr auto;gap:11px;align-items:start}
.q .qn{font:700 13px ui-monospace,Menlo,monospace;color:var(--acc)}
.q .qt{font-size:13.5px;font-weight:700;color:var(--fg)}
.q .qd{font-size:12px;color:var(--dim);margin-top:3px;line-height:1.6}
.q .qs{font-size:11.5px;color:var(--dim);margin-top:5px;padding-left:9px;border-left:2px solid var(--line)}
.q .cost{font:600 11px ui-monospace,Menlo,monospace;padding:3px 8px;border-radius:5px;white-space:nowrap}
.c-hi{background:rgba(255,123,114,.14);color:var(--bad);border:1px solid rgba(255,123,114,.35)}
.c-mid{background:rgba(255,184,107,.14);color:var(--warn);border:1px solid rgba(255,184,107,.35)}
.c-lo{background:rgba(126,231,135,.14);color:var(--ok);border:1px solid rgba(126,231,135,.35)}
table{width:100%;border-collapse:collapse;font-size:12.5px;margin:9px 0}
th,td{padding:7px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{color:var(--dim);font-weight:600;font-size:11.5px;text-transform:uppercase;letter-spacing:.4px}
.tscroll{overflow-x:auto}
.bar{position:relative;height:20px;background:var(--panel2);border-radius:4px;min-width:120px;margin:3px 0}
.bar span{position:absolute;left:0;top:0;bottom:0;border-radius:4px;background:linear-gradient(90deg,#1f6feb,#5cc8ff)}
.bar b{position:absolute;right:7px;top:50%;transform:translateY(-50%);font:600 11.5px ui-monospace,Menlo,monospace}
.barrow{display:grid;grid-template-columns:170px 1fr;gap:10px;align-items:center;margin:4px 0}
.barrow .lbl{font-size:12px;color:var(--fg);text-align:right}
.chip{display:inline-block;padding:2px 8px;border-radius:18px;font:600 11px ui-monospace,Menlo,monospace;
 background:var(--panel2);border:1px solid var(--line);color:var(--dim)}
.chip.ok{background:rgba(126,231,135,.14);border-color:rgba(126,231,135,.4);color:var(--ok)}
.chip.no{background:rgba(255,123,114,.14);border-color:rgba(255,123,114,.4);color:var(--bad)}
.chip.c1{background:rgba(92,200,255,.12);border-color:rgba(92,200,255,.35);color:var(--acc)}
.chip.pp{background:rgba(210,168,255,.12);border-color:rgba(210,168,255,.35);color:var(--pp)}
.chip.wn{background:rgba(255,184,107,.12);border-color:rgba(255,184,107,.35);color:var(--warn)}
.note{background:rgba(255,184,107,.07);border-left:3px solid var(--warn);padding:10px 14px;border-radius:0 7px 7px 0;margin:11px 0}
.note p{margin:0;font-size:13px}.note b{color:var(--warn)}
ul{margin:7px 0 7px 19px;color:var(--dim)}li{margin:4px 0}
footer{margin-top:50px;padding-top:20px;border-top:1px solid var(--line);color:var(--dim);font-size:12px}
@media(max-width:980px){.tl{grid-template-columns:repeat(4,1fr)}.g4{grid-template-columns:repeat(2,1fr)}
 .g3,.g2,.g2a{grid-template-columns:1fr}}
@media(max-width:600px){.tl{grid-template-columns:repeat(2,1fr)}.g4{grid-template-columns:1fr}
 h1{font-size:24px}.wrap{padding:0 14px 60px}.q{grid-template-columns:36px 1fr}}
"""

H = []
A = H.append
A('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">')
A('<meta name="viewport" content="width=device-width,initial-scale=1">')
A('<title>提示词基因组研究线 · 全景与讨论入口</title>')
A('<style>%s</style></head><body><div class="wrap">' % CSS)

A('<header><h1>提示词基因组 <span>研究线全景</span></h1>')
A('<p class="sub">8 轮 · 从「一堆散文」到「可比较、可判定、可挂评测的基因序列」→ 一门专用规则语言。'
  '本页是后续讨论的入口：结论一眼看完，未决问题按优先级排好，数字带口径。</p>')
A('<div class="vd">VERDICT: PASS · 8 轮交付物已落盘 · 自检可复跑</div></header>')

# ── 时间线 ──
A('<h2><span class="n">§1</span>问题链：八轮</h2>')
A('<div class="tl">')
for rid, name, desc, path in ROUNDS:
    cur = ' cur' if rid == 'R8' else ''
    A('<div class="step%s"><div class="rid">%s</div><div class="rt">%s</div><div class="rd">%s</div>'
      '<div class="rp">%s</div></div>' % (cur, rid, name, desc, path))
A('</div>')

# ── 三层结构 ──')
A('<h2><span class="n">§2</span>三层结构（讨论时统一用词）</h2>')
A('<div class="layer l0"><div class="lh">存在性层 L0 · 「这个位点写没写」</div><div class="lb">'
  '<b>23 位点 × 26 家 → 23 种图案</b> · 全局唯一组合只有 <b>3 个</b>（全属 ANTHROPIC）· '
  'DEVIN/MANUS/SAMEDEV 三合一、OPENAI/ZCode 二合一。<br>'
  '判据：<b>覆盖广度</b>（多少家写到）× <b>约束强度</b>（多少家写成强制条款）—— 两者近乎不相关。</div></div>')
A('<div class="layer l1"><div class="lh">等位层 L1/L2/L3 · 「用哪种说法写」</div><div class="lb">'
  '等位键 = <b>模态 + 否定 + 受控动词 + 对象</b> 的组合，可有不同分辨率。'
  '第三条轴：<b>趋同比值</b> = 实测共享 ÷ 解析期望（&gt;1.25 趋同 / &lt;0.75 互斥）。<br>'
  '实测：整体 <b>0.926</b>（≈随机）· 平均私有等位 <b>71.9%</b> · 互斥型 11 个维度 —— '
  '<b>T0 底线 5 个维度 100% 互斥，零例外</b>。</div></div>')
A('<div class="layer l2"><div class="lh">编码层 · GRL 基因规约语</div><div class="lb">'
  '规则是<b>一等数据</b>，散文是它的编译产物。JSONC 语法 + 四种引用形态 + 风格表数据驱动 + 强度守恒。<br>'
  '引用：<code>#D01</code> 位点 · <code>#D01~must</code> 等位 · <code>@R-ID</code> 精确 · '
  '<code>⊇ ⊥ ≡</code> 断言。</div></div>')

# ── 数字速查 ──
A('<h2><span class="n">§3</span>数字速查</h2>')
A('<div class="grid g4">')
CARD = [
    ('5526', '条款（15 家）', '38 文件 / 15 厂商，条款级语料只覆盖 15 家', 'w'),
    ('23', '存在性图案', '26 家去重；存在性层用厂商文件并集口径', ''),
    ('%.1f%%' % (100 * modc.get('unspecified', 0) / max(1, len(_REG))),
     '条款未写模态', '%d/%d ⇒ 只读模态槽对三分之二条款无信息'
     % (modc.get('unspecified', 0), len(_REG)), 'w'),
    ('100%', '槽位保真度', '4237/4237 编译回散文不丢任何槽位', 'g'),
    ('0', '强度守恒违规', '12711 次检查（极性 + 保档）× 3 套文风', 'g'),
    ('18/18', '机检判据', '含 1 条刻意注入违规的自证靶子', 'g'),
    ('54.6%', '位点归属唯一率', '36.6% 无命中 · 8.8% 并列歧义', 'w'),
    ('25.9%', '上游 C 槽污染', '另有 31.9% 条件语义截断，已显式标记', 'w'),
]
for v, t, d, cls in CARD:
    A('<div class="card"><div class="v %s">%s</div><div class="t">%s</div><div class="d">%s</div></div>' % (cls, v, t, d))
A('</div>')

A('<div class="grid g2a">')
A('<div class="card"><div class="t" style="margin-bottom:8px">模态分布（regulative 4237 条）</div>')
mx = max(modc.values())
for m, lb in [('must', 'must 强制'), ('must_not', 'must_not 强制禁止'), ('should', 'should 建议'),
               ('may', 'may 可选'), ('can', 'can 许可'), ('unspecified', 'unspecified 未声明（散文）')]:
    v = modc.get(m, 0)
    A('<div class="barrow"><div class="lbl">%s</div><div class="bar"><span style="width:%.1f%%"></span><b>%d</b></div></div>'
      % (lb, 100 * v / mx, v))
A('</div>')
A('<div class="card"><div class="t" style="margin-bottom:8px">四象限（按覆盖广度硬阈值，数据文件口径）</div>')
for q in ['标准条款', '写成了倾向', '无人地带']:
    A('<div class="barrow"><div class="lbl">%s</div><div class="bar"><span style="width:%.1f%%"></span><b>%d 个</b></div></div>'
      % (q, 100 * quads.get(q, 0) / 23, quads.get(q, 0)))
A('<p style="font-size:11.5px;margin-top:8px">★ 两轴不可压成一类：注入防御覆盖 23%（落在「无人地带」）'
  '但强制率 33%（全表最高）。正文另有一套「稀缺硬条款」再分类，<b>两套口径不可混用</b>。</p>')
A('</div></div>')

# ── 未决问题 ──
A('<h2><span class="n">§4</span>悬而未决的问题（后续讨论入口）</h2>')
A('<p>每条给：问的是什么 / 为什么现在答不了 / 推进它需要什么。直接说编号即可继续。</p>')
for qid, title, why, need, cost, rank in sorted(QS, key=lambda x: x[5]):
    cc = 'c-hi' if cost == '高' else ('c-lo' if cost == '低' else 'c-mid')
    A('<div class="q" style="margin-bottom:8px"><div class="qn">%s</div><div><div class="qt">%s</div>'
      '<div class="qd">卡点：%s</div><div class="qs">推进：%s</div></div>'
      '<div class="cost %s">成本 %s</div></div>' % (qid, title, why, need, cc, cost))
A('</div>')

# ── 路线 ──
A('<h2><span class="n">§5</span>下一轮候选路线</h2>')
A('<div class="tscroll"><table><thead><tr><th>路线</th><th>做什么</th><th>覆盖问题</th><th>产出</th><th>前置 / 代价</th><th>排序</th></tr></thead><tbody>')
for rid, name, qs, out, cost, rank in ROUTES:
    chip = 'chip ok' if rid == 'B' else 'chip c1'
    A(f'<tr><td><b>{rid}</b> {name}</td><td>{qs}</td><td>{out}</td><td>{cost}</td>'
      f'<td><span class="{chip}">{rank}</span></td></tr>')
A('</tbody></table></div>')
A('<div class="note"><p><b>建议下一轮 = B（稳健性复核）</b>：便宜、能纠错、且不依赖任何外部条件。'
  'A（挂评测）价值最高但成本高，依赖跑模型的沙箱与稳定 judge。</p></div>')

# ── 陷阱 ──
A('<h2><span class="n">§6</span>已知口径陷阱（讨论时最容易吵起来）</h2>')
A('<div class="grid g2">')
A('<div class="card"><div class="t">容易搞混的三组</div><ul>'
  '<li><b>存在性相似 ≠ 等位相似</b>：0.913 的存在性相似 ⇏ 等位相似，不能外推</li>'
  '<li><b>覆盖广度 ≠ 约束强度</b>：身份锚定 96%/8% vs 注入防御 23%/33%</li>'
  '<li><b>四象限两套口径</b>：数据文件按覆盖广度硬分，正文另做叙述性再分类</li>'
  '<li><b>genome 口径</b>：厂商全部文件并集，不是单文件</li>'
  '<li><b>强制判定</b>：按章节，不按行；措辞扫描会漏掉字段级标记</li></ul></div>')
A('<div class="card"><div class="t">已被推翻，别重走</div><ul>'
  '<li>「Tier 0 没写全 = 缺陷」→ <b>是定制化的必然结果</b></li>'
  '<li>「共识序 = 证据门控 + 相邻交换」→ <b>共识序 = 支持度降序</b></li>'
  '<li>「等位层也建家族树」→ <b>只在存在性层建树</b></li>'
  '<li>「条件并进等位键更全」→ <b>条件位独立成字段</b></li>'
  '<li>「正编译应还原原文」→ <b>生成新散文</b>（还原度 5.4%）</li>'
  '<li>外部：APRO 查无此论文 · RePrompt 两篇都不是那篇 · Promptbreeder 官方仓库 404</li></ul></div>')
A('</div>')

A('<footer>全部交付物在 <code>docs/</code> · 总纲 <code>docs/08-讨论总纲</code> · '
  '自检 <code>python3 grl_check.py</code> · 审计 <code>python3 md_audit.py</code></footer>')
A('</div></body></html>')

os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, 'w', encoding='utf-8').write('\n'.join(H))
print('written', OUT, os.path.getsize(OUT), 'bytes')
print('quads', dict(quads), '| patterns', len(groups), '| modc', modc)
