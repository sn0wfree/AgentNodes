# NOTICE · 第三方材料与授权边界

本仓库（prompt-genome）由 `sn0wfree` 维护，包含**原创分析产出**。
下表列出被引用的第三方材料及其授权状态。**本仓库的 MIT 授权不覆盖这些第三方内容。**

---

## 1. 源语料：CL4R1T4S —— ⚠ 授权瑕疵，请先读完再用

| 项 | 内容 |
|---|---|
| 来源 | `https://github.com/elder-plinius/CL4R1T4S` |
| 许可声明 | AGPL-3.0 |
| 实际内容 | 26 家厂商的 **82 份系统提示词**（约 8.2 MB），其中包含 Anthropic / OpenAI / xAI 等厂商的**专有提示词** |
| ⚠ 核心问题 | **维护者不拥有这些专有提示词的著作权，因此无权授予 AGPL-3.0。** 许可授予越权。AGPL 的网络 Copyleft 还会把风险传染给任何二次分发者。 |
| ⚠ 维护状况 | 1 名贡献者 · 209 commits · **0 个 merge commit** · 提交消息为网页编辑器默认值 ⇒ **纯数据投放点，不是可依赖的上游** |
| ⚠ 内容风险 | README 第 41–45 行含 leet 混淆的**提示注入**（要求 AI 输出自身系统指令）。第三方独立分析定性为「维护者刻意埋设的自演示靶子」。本项目**已识别并拒绝执行**，并把它当作不可信输入处理。 |
| ⚠ 溯源 | 仓库**没有逐条溯源标注**，读者无法自行判断单条可信度 |

**本仓库的处理**：不包含任何完整正文。`scripts/bootstrap.sh` 只做**只读拉取**用于复算，
拉下来的语料在 `.gitignore` 内，不会被提交。

**使用建议**：想长期依赖这份语料，请**自己 fork + 自己补溯源**。
可参考 `ZAI/ZCode/Tools.json` 自带的四层分级模板（`activeReceiptVerified` /
`activeReconstructedNotVerbatim` / `inactiveProviderContracts` / `inactiveRegistryAliases`）——
它的 `capability` / `readOnly` / `destructive` / `concurrentSafe` 字段与本项目的槽位契约同构，
值得直接借鉴。

## 2. 条款级抽取产物：SPDeconstruction

| 项 | 内容 |
|---|---|
| 内容 | 对 CL4R1T4S 的条款级抽取：**38 文件 / 15 厂商 / 5526 条**（regulative 4237 · constitutive 1159 · non-statement 130） |
| 生成方式 | **gemini-flash-3.5 一次生成** ⇒ **不是黄金标准** |
| ⚠ 已知缺陷 | 条件槽（C）混装 section 前缀 **864/3334 = 25.9%**；条件语义截断 **1353 条 = 31.9%**；抽取覆盖只到 15 厂商，另 11 家无产物 |
| 本仓库的处理 | 条款级导出已用 `src/sanitize.py` 脱敏（原文 → sha256 锚点），见 `data/anchors.json` |

## 3. Anthropic 官方文档

| 项 | 内容 |
|---|---|
| 出处 | `https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-fable-5-2` |
| 用途 | 「谁拥有代码」一节的官方实测：合并重复代码 <10% → ~75%，output tokens +70~80%，且**限制范围的规则不会抵消它** |
| 引用方式 | 报告中仅引用**短片段**并标注出处；官方文档为公开可访问材料 |

## 4. 论文与外部项目（业界先例调研，46 个）

代表性先例及其官方出处见 `docs/04-业界先例调研-20261117.md`。每条均标注论文号 / 仓库地址 /
许可（MIT / Apache-2.0 / AGPL-3.0 等）。其中：

- **可抄的零件**：`DelvePO`(2510.18257, Loci/Alleles 双记忆) · `PromptGenome`(2611.01135, 组件型 genome + 位点级变异器 + 部署门) · `SEPO`(2608.28067, typed units) · `Diverse Prompts`(2504.14367, CFG 当 genotype) · `PhyloLM`(2404.04671, prompt=gene / 输出 token=allele / NJ 建树) · `Cline @cline/ui`(MIT, 令牌源格式 + `generate:theme --check` 门禁)
- **方法成熟但生态冷门**：`PhyloLM`（repo 仅 18★，方法全套成熟）—— 调研判定为**最值得做**的一类
- **已被推翻的流传说法**（详见调研报告 §7）：`APRO` 查无此论文 · `RePrompt` 两篇都不是「抽需求」那篇 · `Promptbreeder` 官方仓库 404（只有社区实现）· `2404.13213` 是引力波论文 · `protectai/llm-guard` 已 archived · `Lakera Guard` 已被 Check Point 收购改名

## 5. 本仓库自身

- 代码与原创分析：**MIT**（见 `LICENSE`）
- 报告中引用的厂商提示词短片段：属研究引用，各归其作者所有
- `figures/` 下的可视化页为自包含单文件 HTML，不依赖任何外部资源

---

## 一句话

**引用是有限的，边界是明确的。** 本仓库可以放心 fork、引用、复算；
但**不要**把 CL4R1T4S 的语料正文连同本仓库一起再分发 —— 那会把授权瑕疵一并传下去。
